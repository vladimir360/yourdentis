// database/migrate.js
// Ejecutar con: node database/migrate.js
'use strict';

require('dotenv').config();

const mysql  = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const fs     = require('fs');
const path   = require('path');

async function migrate() {
  console.log('\n🦷  YourDentis — Setup de Base de Datos\n');

  const conn = await mysql.createConnection({
    host:                process.env.DB_HOST     || 'localhost',
    port:                parseInt(process.env.DB_PORT) || 3306,
    user:                process.env.DB_USER     || 'root',
    password:            process.env.DB_PASSWORD || '',
    charset:             'utf8mb4',
    multipleStatements:  true,
  });

  try {
    // Crear BD si no existe
    const dbName = process.env.DB_NAME || 'yourdentis_db';
    await conn.query(
      `CREATE DATABASE IF NOT EXISTS \`${dbName}\`
       CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    await conn.query(`USE \`${dbName}\``);
    console.log(`✅  Base de datos: ${dbName}`);

    // Ejecutar schema
    const schemaPath = path.join(__dirname, 'schema.sql');
    const schemaSql  = fs.readFileSync(schemaPath, 'utf8');
    await conn.query(schemaSql);
    console.log('✅  Schema aplicado');

    // Crear datos reales de seed
    const clinicId = uuidv4();
    const adminId  = uuidv4();
    const dentistUserId = uuidv4();
    const dentistId     = uuidv4();
    const receptionistId = uuidv4();

    const rounds      = parseInt(process.env.BCRYPT_ROUNDS) || 12;
    const adminPass   = await bcrypt.hash('Admin123!',      rounds);
    const dentistPass = await bcrypt.hash('Dentist123!',    rounds);
    const recepPass   = await bcrypt.hash('Recep123!',      rounds);

    // Clínica
    await conn.query(
      `INSERT IGNORE INTO clinics
         (id, name, legal_name, address, city, phone, email, plan, status, currency)
       VALUES (?,?,?,?,?,?,?,'professional','active','DOP')`,
      [
        clinicId,
        'Clínica Dental YourDentis',
        'YourDentis S.R.L.',
        'Av. Winston Churchill 1099, Piantini',
        'Santo Domingo',
        '809-555-1234',
        'admin@yourdentis.com',
      ]
    );
    console.log('✅  Clínica creada');

    // Admin
    await conn.query(
      `INSERT IGNORE INTO users
         (id, clinic_id, email, password_hash, first_name, last_name, role, status)
       VALUES (?,?,?,?,?,?,'admin','active')`,
      [adminId, clinicId, 'admin@yourdentis.com', adminPass, 'Admin', 'Sistema']
    );

    // Odontólogo (usuario)
    await conn.query(
      `INSERT IGNORE INTO users
         (id, clinic_id, email, password_hash, first_name, last_name, role, status)
       VALUES (?,?,?,?,?,?,'dentist','active')`,
      [dentistUserId, clinicId, 'dr.garcia@yourdentis.com', dentistPass, 'Carlos', 'García']
    );

    // Recepcionista
    await conn.query(
      `INSERT IGNORE INTO users
         (id, clinic_id, email, password_hash, first_name, last_name, role, status)
       VALUES (?,?,?,?,?,?,'receptionist','active')`,
      [receptionistId, clinicId, 'recep@yourdentis.com', recepPass, 'María', 'Rodríguez']
    );

    // Perfil odontólogo
    await conn.query(
      `INSERT IGNORE INTO dentists
         (id, clinic_id, user_id, first_name, last_name, specialty, license_number, color, status)
       VALUES (?,?,?,?,?,?,?,?,'active')`,
      [dentistId, clinicId, dentistUserId, 'Carlos', 'García', 'Ortodoncia', 'COL-2024-001', '#3B82F6']
    );

    // Horario Lunes–Viernes 8:00–17:00
    for (let day = 1; day <= 5; day++) {
      await conn.query(
        `INSERT IGNORE INTO dentist_schedules
           (id, dentist_id, day_of_week, start_time, end_time, room)
         VALUES (?,?,?,'08:00','17:00','Consultorio 1')`,
        [uuidv4(), dentistId, day]
      );
    }

    console.log('✅  Usuarios y odontólogo creados');

    // Paciente de ejemplo
    const patientId = uuidv4();
    await conn.query(
      `INSERT IGNORE INTO patients
         (id, clinic_id, first_name, last_name, email, phone,
          date_of_birth, gender, blood_type, status)
       VALUES (?,?,?,?,?,?,'1990-05-15','M','O+','active')`,
      [patientId, clinicId, 'Juan', 'Pérez', 'juan@ejemplo.com', '809-555-9999']
    );

    console.log('✅  Paciente de ejemplo creado');

    console.log('\n╔══════════════════════════════════════════════╗');
    console.log('║        ✅  Setup completado                  ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  Credenciales de acceso:                     ║');
    console.log('║                                              ║');
    console.log('║  🔑 Administrador                            ║');
    console.log('║     Email:    admin@yourdentis.com           ║');
    console.log('║     Password: Admin123!                      ║');
    console.log('║                                              ║');
    console.log('║  🦷 Odontólogo                               ║');
    console.log('║     Email:    dr.garcia@yourdentis.com       ║');
    console.log('║     Password: Dentist123!                    ║');
    console.log('║                                              ║');
    console.log('║  📋 Recepcionista                            ║');
    console.log('║     Email:    recep@yourdentis.com           ║');
    console.log('║     Password: Recep123!                      ║');
    console.log('╚══════════════════════════════════════════════╝\n');
  } finally {
    await conn.end();
  }
}

migrate().catch((err) => {
  console.error('❌  Error en migración:', err.message);
  process.exit(1);
});
