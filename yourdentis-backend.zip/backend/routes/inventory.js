// routes/inventory.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query, withTransaction } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ── GET /api/inventory ────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const {
      category, status, lowStock,
      search, page = 1, limit = 50,
    } = req.query;

    const clinicId = req.user.clinicId;
    const offset   = (parseInt(page) - 1) * parseInt(limit);

    let where    = 'WHERE i.clinic_id = ? AND i.deleted_at IS NULL';
    const params = [clinicId];

    if (category)          { where += ' AND i.category = ?';               params.push(category); }
    if (status)            { where += ' AND i.status = ?';                  params.push(status); }
    if (lowStock === 'true') { where += ' AND i.current_stock <= i.min_stock'; }
    if (search) {
      where += ' AND (i.name LIKE ? OR i.sku LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    const countRows = await query(
      `SELECT COUNT(*) AS total FROM inventory_items i ${where}`,
      params
    );
    const total = countRows[0].total;

    const items = await query(
      `SELECT * FROM inventory_items i
       ${where}
       ORDER BY i.name ASC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.json({
      success: true,
      data:    items,
      pagination: { total, page: parseInt(page), limit: parseInt(limit) },
    });
  } catch (err) {
    console.error('[INVENTORY/GET_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo inventario' });
  }
});

// ── GET /api/inventory/alerts ─────────────────────────────────────────────────
router.get('/alerts', async (req, res) => {
  try {
    const items = await query(
      `SELECT id, name, category, current_stock, min_stock, unit, supplier
       FROM inventory_items
       WHERE clinic_id = ? AND current_stock <= min_stock
         AND status = 'active' AND deleted_at IS NULL
       ORDER BY (min_stock - current_stock) DESC`,
      [req.user.clinicId]
    );
    return res.json({ success: true, data: items, count: items.length });
  } catch (err) {
    console.error('[INVENTORY/ALERTS]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo alertas' });
  }
});

// ── GET /api/inventory/:id ────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const rows = await query(
      'SELECT * FROM inventory_items WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
    }

    const movements = await query(
      `SELECT m.*, CONCAT(u.first_name,' ',u.last_name) AS user_name
       FROM inventory_movements m
       LEFT JOIN users u ON u.id = m.user_id
       WHERE m.item_id = ?
       ORDER BY m.date DESC LIMIT 30`,
      [req.params.id]
    );

    rows[0].movements = movements;
    return res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error('[INVENTORY/GET_ONE]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo artículo' });
  }
});

// ── POST /api/inventory ───────────────────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'receptionist'),
  [
    body('name').notEmpty().withMessage('Nombre requerido'),
    body('currentStock').isInt({ min: 0 }).withMessage('Stock actual inválido'),
    body('minStock').isInt({ min: 0 }).withMessage('Stock mínimo inválido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        name, category = 'General', sku = '',
        currentStock, minStock, maxStock = 9999,
        unit = 'unidad', unitCost = 0, salePrice = 0,
        supplier = '', supplierContact = '',
        location = '', expirationDate = null,
      } = req.body;

      const id = uuidv4();

      await query(
        `INSERT INTO inventory_items
           (id, clinic_id, name, category, sku, current_stock, min_stock, max_stock,
            unit, unit_cost, sale_price, supplier, supplier_contact,
            location, expiration_date, last_restocked, status, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),'active',NOW())`,
        [
          id, req.user.clinicId, name, category, sku,
          currentStock, minStock, maxStock,
          unit, unitCost, salePrice, supplier, supplierContact,
          location, expirationDate,
        ]
      );

      const created = await query('SELECT * FROM inventory_items WHERE id = ?', [id]);
      return res.status(201).json({
        success: true,
        message: 'Artículo agregado al inventario',
        data:    created[0],
      });
    } catch (err) {
      console.error('[INVENTORY/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando artículo' });
    }
  }
);

// ── PUT /api/inventory/:id ────────────────────────────────────────────────────
router.put('/:id', authorize('admin', 'receptionist'), async (req, res) => {
  try {
    const {
      name, category, minStock, maxStock, unitCost,
      salePrice, supplier, supplierContact, location,
      expirationDate, status,
    } = req.body;

    await query(
      `UPDATE inventory_items SET
         name              = COALESCE(?, name),
         category          = COALESCE(?, category),
         min_stock         = COALESCE(?, min_stock),
         max_stock         = COALESCE(?, max_stock),
         unit_cost         = COALESCE(?, unit_cost),
         sale_price        = COALESCE(?, sale_price),
         supplier          = COALESCE(?, supplier),
         supplier_contact  = COALESCE(?, supplier_contact),
         location          = COALESCE(?, location),
         expiration_date   = COALESCE(?, expiration_date),
         status            = COALESCE(?, status),
         updated_at        = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [
        name, category, minStock, maxStock, unitCost,
        salePrice, supplier, supplierContact, location,
        expirationDate, status,
        req.params.id, req.user.clinicId,
      ]
    );

    const updated = await query('SELECT * FROM inventory_items WHERE id = ?', [req.params.id]);
    return res.json({ success: true, message: 'Artículo actualizado', data: updated[0] });
  } catch (err) {
    console.error('[INVENTORY/PUT]', err);
    return res.status(500).json({ success: false, message: 'Error actualizando artículo' });
  }
});

// ── POST /api/inventory/:id/movement ─────────────────────────────────────────
router.post(
  '/:id/movement',
  authorize('admin', 'dentist', 'receptionist'),
  [
    body('type').isIn(['in', 'out', 'adjustment']).withMessage('Tipo inválido'),
    body('quantity').isInt({ min: 1 }).withMessage('Cantidad mínima: 1'),
    body('reason').notEmpty().withMessage('Motivo requerido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const { type, quantity, reason } = req.body;
      const itemId = req.params.id;

      const result = await withTransaction(async (conn) => {
        const [[item]] = await conn.query(
          'SELECT * FROM inventory_items WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL FOR UPDATE',
          [itemId, req.user.clinicId]
        );

        if (!item) {
          throw Object.assign(new Error('Artículo no encontrado'), { statusCode: 404 });
        }

        let newStock;
        if (type === 'in') {
          newStock = item.current_stock + parseInt(quantity);
        } else if (type === 'out') {
          if (item.current_stock < parseInt(quantity)) {
            throw Object.assign(
              new Error(`Stock insuficiente. Disponible: ${item.current_stock} ${item.unit}`),
              { statusCode: 400 }
            );
          }
          newStock = item.current_stock - parseInt(quantity);
        } else {
          newStock = parseInt(quantity); // adjustment = valor absoluto
        }

        const updateLastRestocked = type === 'in'
          ? ', last_restocked = NOW()'
          : '';

        await conn.query(
          `UPDATE inventory_items
           SET current_stock = ?${updateLastRestocked}, updated_at = NOW()
           WHERE id = ?`,
          [newStock, itemId]
        );

        await conn.query(
          `INSERT INTO inventory_movements
             (id, item_id, type, quantity, reason, date, user_id)
           VALUES (?,?,?,?,?,NOW(),?)`,
          [uuidv4(), itemId, type, quantity, reason, req.user.id]
        );

        return { previousStock: item.current_stock, newStock };
      });

      return res.json({
        success: true,
        message: `Stock actualizado: ${result.previousStock} → ${result.newStock}`,
        data:    result,
      });
    } catch (err) {
      if (err.statusCode) {
        return res.status(err.statusCode).json({ success: false, message: err.message });
      }
      console.error('[INVENTORY/MOVEMENT]', err);
      return res.status(500).json({ success: false, message: 'Error registrando movimiento' });
    }
  }
);

// ── DELETE /api/inventory/:id ─────────────────────────────────────────────────
router.delete('/:id', authorize('admin'), async (req, res) => {
  try {
    const result = await query(
      `UPDATE inventory_items SET status = 'discontinued', deleted_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) {
      return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
    }
    return res.json({ success: true, message: 'Artículo descontinuado' });
  } catch (err) {
    console.error('[INVENTORY/DELETE]', err);
    return res.status(500).json({ success: false, message: 'Error eliminando artículo' });
  }
});

module.exports = router;
