// routes/auth.js
'use strict';

const express   = require('express');
const bcrypt    = require('bcryptjs');
const jwt       = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { query, withTransaction } = require('../config/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// ── Helpers ───────────────────────────────────────────────────────────────────
function signTokens(userId, clinicId, role) {
  const payload      = { userId, clinicId, role };
  const accessToken  = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  });
  const refreshToken = jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
  return { accessToken, refreshToken };
}

function handleValidation(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ success: false, errors: errors.array() });
    return true;
  }
  return false;
}

// ── POST /api/auth/login ──────────────────────────────────────────────────────
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().withMessage('Email inválido'),
    body('password').notEmpty().withMessage('Contraseña requerida'),
  ],
  async (req, res) => {
    if (handleValidation(req, res)) return;

    const { email, password } = req.body;

    try {
      const rows = await query(
        `SELECT u.id, u.clinic_id, u.email, u.password_hash,
                u.first_name, u.last_name, u.role, u.avatar_url,
                u.status,
                c.name  AS clinic_name,
                c.status AS clinic_status,
                c.logo_url AS clinic_logo
         FROM users u
         JOIN clinics c ON c.id = u.clinic_id
         WHERE u.email = ? AND u.deleted_at IS NULL`,
        [email]
      );

      if (!rows.length) {
        return res.status(401).json({
          success: false,
          message: 'Credenciales incorrectas',
        });
      }

      const user = rows[0];

      if (user.status !== 'active') {
        return res.status(403).json({
          success: false,
          message: 'Cuenta suspendida. Contacta al administrador.',
        });
      }

      if (user.clinic_status === 'suspended') {
        return res.status(403).json({
          success: false,
          message: 'La clínica se encuentra suspendida.',
        });
      }

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({
          success: false,
          message: 'Credenciales incorrectas',
        });
      }

      const { accessToken, refreshToken } = signTokens(
        user.id, user.clinic_id, user.role
      );

      // Registrar sesión
      await query(
        `INSERT INTO user_sessions
           (id, user_id, refresh_token, ip_address, user_agent, expires_at)
         VALUES (?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))`,
        [
          uuidv4(),
          user.id,
          refreshToken,
          req.ip,
          req.headers['user-agent'] || '',
        ]
      );

      // Actualizar último login
      await query(
        'UPDATE users SET last_login = NOW() WHERE id = ?',
        [user.id]
      );

      // Log de auditoría
      await query(
        `INSERT INTO audit_logs
           (id, clinic_id, user_id, action, entity, entity_id, ip_address)
         VALUES (?, ?, ?, 'LOGIN', 'users', ?, ?)`,
        [uuidv4(), user.clinic_id, user.id, user.id, req.ip]
      );

      return res.json({
        success: true,
        data: {
          accessToken,
          refreshToken,
          user: {
            id:         user.id,
            email:      user.email,
            firstName:  user.first_name,
            lastName:   user.last_name,
            role:       user.role,
            avatar:     user.avatar_url,
            clinicId:   user.clinic_id,
            clinicName: user.clinic_name,
            clinicLogo: user.clinic_logo,
          },
        },
      });
    } catch (err) {
      console.error('[AUTH/LOGIN]', err);
      return res.status(500).json({
        success: false,
        message: 'Error interno al iniciar sesión',
      });
    }
  }
);

// ── POST /api/auth/refresh ────────────────────────────────────────────────────
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(400).json({
      success: false,
      message: 'Refresh token requerido',
    });
  }

  try {
    const payload = jwt.verify(refreshToken, process.env.JWT_SECRET);

    const sessions = await query(
      `SELECT id FROM user_sessions
       WHERE user_id = ? AND refresh_token = ?
         AND expires_at > NOW() AND revoked_at IS NULL`,
      [payload.userId, refreshToken]
    );

    if (!sessions.length) {
      return res.status(401).json({
        success: false,
        message: 'Sesión expirada. Inicia sesión de nuevo.',
      });
    }

    const users = await query(
      'SELECT id, clinic_id, role FROM users WHERE id = ? AND status = "active"',
      [payload.userId]
    );

    if (!users.length) {
      return res.status(401).json({ success: false, message: 'Usuario no encontrado' });
    }

    const u = users[0];
    const tokens = signTokens(u.id, u.clinic_id, u.role);

    // Rotar refresh token
    await query(
      `UPDATE user_sessions
       SET refresh_token = ?, expires_at = DATE_ADD(NOW(), INTERVAL 7 DAY)
       WHERE id = ?`,
      [tokens.refreshToken, sessions[0].id]
    );

    return res.json({ success: true, data: tokens });
  } catch {
    return res.status(401).json({
      success: false,
      message: 'Refresh token inválido o expirado',
    });
  }
});

// ── POST /api/auth/logout ─────────────────────────────────────────────────────
router.post('/logout', authenticate, async (req, res) => {
  const { refreshToken } = req.body;
  try {
    if (refreshToken) {
      await query(
        `UPDATE user_sessions SET revoked_at = NOW()
         WHERE user_id = ? AND refresh_token = ?`,
        [req.user.id, refreshToken]
      );
    }

    await query(
      `INSERT INTO audit_logs
         (id, clinic_id, user_id, action, entity, entity_id, ip_address)
       VALUES (?, ?, ?, 'LOGOUT', 'users', ?, ?)`,
      [uuidv4(), req.user.clinicId, req.user.id, req.user.id, req.ip]
    );

    return res.json({ success: true, message: 'Sesión cerrada correctamente' });
  } catch (err) {
    console.error('[AUTH/LOGOUT]', err);
    return res.status(500).json({ success: false, message: 'Error al cerrar sesión' });
  }
});

// ── GET /api/auth/me ──────────────────────────────────────────────────────────
router.get('/me', authenticate, async (req, res) => {
  try {
    const rows = await query(
      `SELECT u.id, u.email, u.first_name, u.last_name, u.role,
              u.avatar_url, u.phone, u.clinic_id,
              u.created_at, u.last_login,
              c.name AS clinic_name, c.logo_url AS clinic_logo,
              c.currency, c.timezone
       FROM users u
       JOIN clinics c ON c.id = u.clinic_id
       WHERE u.id = ?`,
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });
    }

    const u = rows[0];
    return res.json({
      success: true,
      data: {
        id:          u.id,
        email:       u.email,
        firstName:   u.first_name,
        lastName:    u.last_name,
        role:        u.role,
        avatar:      u.avatar_url,
        phone:       u.phone,
        clinicId:    u.clinic_id,
        clinicName:  u.clinic_name,
        clinicLogo:  u.clinic_logo,
        currency:    u.currency,
        timezone:    u.timezone,
        lastLogin:   u.last_login,
        createdAt:   u.created_at,
      },
    });
  } catch (err) {
    console.error('[AUTH/ME]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo perfil' });
  }
});

// ── POST /api/auth/change-password ───────────────────────────────────────────
router.post(
  '/change-password',
  authenticate,
  [
    body('currentPassword').notEmpty(),
    body('newPassword')
      .isLength({ min: 8 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage(
        'Mínimo 8 caracteres, una mayúscula, una minúscula y un número'
      ),
  ],
  async (req, res) => {
    if (handleValidation(req, res)) return;

    const { currentPassword, newPassword } = req.body;
    try {
      const rows = await query(
        'SELECT password_hash FROM users WHERE id = ?',
        [req.user.id]
      );

      const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
      if (!valid) {
        return res.status(400).json({
          success: false,
          message: 'La contraseña actual es incorrecta',
        });
      }

      const rounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
      const hash   = await bcrypt.hash(newPassword, rounds);

      await query('UPDATE users SET password_hash = ? WHERE id = ?', [
        hash,
        req.user.id,
      ]);

      // Revocar todas las sesiones activas por seguridad
      await query(
        'UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ?',
        [req.user.id]
      );

      return res.json({
        success: true,
        message: 'Contraseña actualizada. Inicia sesión de nuevo.',
      });
    } catch (err) {
      console.error('[AUTH/CHANGE-PASSWORD]', err);
      return res.status(500).json({
        success: false,
        message: 'Error al cambiar contraseña',
      });
    }
  }
);

module.exports = router;
