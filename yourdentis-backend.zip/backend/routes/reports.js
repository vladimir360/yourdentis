// routes/reports.js
'use strict';

const express = require('express');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, authorize('admin', 'dentist'));

// ── GET /api/reports/dashboard ────────────────────────────────────────────────
router.get('/dashboard', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;
    const { period = 'month' } = req.query;

    const intervalMap = { week: 'INTERVAL 7 DAY', month: 'INTERVAL 1 MONTH', year: 'INTERVAL 1 YEAR' };
    const interval    = intervalMap[period] || 'INTERVAL 1 MONTH';
    const today       = new Date().toISOString().split('T')[0];

    const [
      patientsTotal,
      patientsNew,
      appointmentsStats,
      revenueStats,
      pendingInvoices,
      lowStock,
      todayAppointments,
    ] = await Promise.all([
      query('SELECT COUNT(*) AS total FROM patients WHERE clinic_id = ? AND status = "active" AND deleted_at IS NULL', [clinicId]),
      query(`SELECT COUNT(*) AS total FROM patients WHERE clinic_id = ? AND registered_at >= DATE_SUB(NOW(), ${interval}) AND deleted_at IS NULL`, [clinicId]),
      query(`SELECT COUNT(*) AS total, SUM(status='completed') AS completed, SUM(status='cancelled') AS cancelled FROM appointments WHERE clinic_id = ? AND date >= DATE_SUB(NOW(), ${interval}) AND deleted_at IS NULL`, [clinicId]),
      query(`SELECT SUM(total) AS revenue, SUM(paid) AS collected FROM invoices WHERE clinic_id = ? AND date >= DATE_SUB(NOW(), ${interval}) AND deleted_at IS NULL`, [clinicId]),
      query(`SELECT COUNT(*) AS total, SUM(total - paid) AS amount FROM invoices WHERE clinic_id = ? AND status IN ('pending','partial') AND deleted_at IS NULL`, [clinicId]),
      query(`SELECT COUNT(*) AS total FROM inventory_items WHERE clinic_id = ? AND current_stock <= min_stock AND status = 'active' AND deleted_at IS NULL`, [clinicId]),
      query(`SELECT COUNT(*) AS total FROM appointments WHERE clinic_id = ? AND date = ? AND deleted_at IS NULL`, [clinicId, today]),
    ]);

    return res.json({
      success: true,
      data: {
        period,
        patients: {
          total:  patientsTotal[0].total,
          new:    patientsNew[0].total,
        },
        appointments: {
          total:     appointmentsStats[0].total     || 0,
          completed: appointmentsStats[0].completed || 0,
          cancelled: appointmentsStats[0].cancelled || 0,
          today:     todayAppointments[0].total     || 0,
        },
        revenue: {
          billed:    revenueStats[0].revenue   || 0,
          collected: revenueStats[0].collected || 0,
          pending:   pendingInvoices[0].amount || 0,
        },
        pendingInvoices: pendingInvoices[0].total || 0,
        lowStockAlerts:  lowStock[0].total        || 0,
      },
    });
  } catch (err) {
    console.error('[REPORTS/DASHBOARD]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte' });
  }
});

// ── GET /api/reports/revenue ──────────────────────────────────────────────────
router.get('/revenue', async (req, res) => {
  try {
    const { groupBy = 'month', year = new Date().getFullYear() } = req.query;

    const formats = { day: '%Y-%m-%d', week: '%Y-%u', month: '%Y-%m' };
    const format  = formats[groupBy] || '%Y-%m';

    const rows = await query(
      `SELECT
         DATE_FORMAT(date, ?) AS period,
         SUM(total)           AS revenue,
         SUM(paid)            AS collected,
         SUM(total - paid)    AS pending,
         COUNT(*)             AS invoices
       FROM invoices
       WHERE clinic_id = ? AND YEAR(date) = ? AND deleted_at IS NULL
       GROUP BY period
       ORDER BY period`,
      [format, req.user.clinicId, year]
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error('[REPORTS/REVENUE]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte de ingresos' });
  }
});

// ── GET /api/reports/appointments ────────────────────────────────────────────
router.get('/appointments', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;

    const [byStatus, byDentist, byMonth] = await Promise.all([
      query(
        `SELECT status, COUNT(*) AS count
         FROM appointments WHERE clinic_id = ? AND deleted_at IS NULL
         GROUP BY status`,
        [clinicId]
      ),
      query(
        `SELECT
           d.id,
           CONCAT(u.first_name,' ',u.last_name) AS dentist_name,
           COUNT(*) AS total,
           SUM(a.status = 'completed') AS completed,
           SUM(a.status = 'no-show')  AS no_show
         FROM appointments a
         JOIN dentists d ON d.id = a.dentist_id
         JOIN users    u ON u.id = d.user_id
         WHERE a.clinic_id = ? AND a.deleted_at IS NULL
         GROUP BY d.id, dentist_name
         ORDER BY total DESC`,
        [clinicId]
      ),
      query(
        `SELECT DATE_FORMAT(date, '%Y-%m') AS month, COUNT(*) AS total
         FROM appointments
         WHERE clinic_id = ? AND YEAR(date) = YEAR(NOW()) AND deleted_at IS NULL
         GROUP BY month ORDER BY month`,
        [clinicId]
      ),
    ]);

    return res.json({ success: true, data: { byStatus, byDentist, byMonth } });
  } catch (err) {
    console.error('[REPORTS/APPOINTMENTS]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte de citas' });
  }
});

// ── GET /api/reports/treatments ───────────────────────────────────────────────
router.get('/treatments', async (req, res) => {
  try {
    const rows = await query(
      `SELECT
         type,
         COUNT(*) AS count,
         SUM(cost - discount) AS revenue
       FROM treatments
       WHERE clinic_id = ? AND deleted_at IS NULL
       GROUP BY type
       ORDER BY count DESC`,
      [req.user.clinicId]
    );
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error('[REPORTS/TREATMENTS]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte' });
  }
});

// ── GET /api/reports/patients/growth ─────────────────────────────────────────
router.get('/patients/growth', async (req, res) => {
  try {
    const { year = new Date().getFullYear() } = req.query;

    const rows = await query(
      `SELECT
         DATE_FORMAT(registered_at, '%Y-%m') AS month,
         COUNT(*) AS new_patients
       FROM patients
       WHERE clinic_id = ? AND YEAR(registered_at) = ? AND deleted_at IS NULL
       GROUP BY month
       ORDER BY month`,
      [req.user.clinicId, year]
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error('[REPORTS/GROWTH]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte' });
  }
});

// ── GET /api/reports/dentist/:dentistId/performance ───────────────────────────
router.get('/dentist/:dentistId/performance', async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    let where    = 'WHERE a.dentist_id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL';
    const params = [req.params.dentistId, req.user.clinicId];

    if (dateFrom) { where += ' AND a.date >= ?'; params.push(dateFrom); }
    if (dateTo)   { where += ' AND a.date <= ?'; params.push(dateTo); }

    const [appointments, revenue] = await Promise.all([
      query(
        `SELECT
           COUNT(*) AS total,
           SUM(status = 'completed') AS completed,
           SUM(status = 'cancelled') AS cancelled,
           SUM(status = 'no-show')   AS no_show
         FROM appointments a
         ${where}`,
        params
      ),
      query(
        `SELECT SUM(cost - discount) AS revenue, COUNT(*) AS treatments
         FROM treatments
         WHERE dentist_id = ? AND clinic_id = ? AND deleted_at IS NULL`,
        [req.params.dentistId, req.user.clinicId]
      ),
    ]);

    return res.json({
      success: true,
      data: {
        appointments: appointments[0],
        revenue:      revenue[0],
      },
    });
  } catch (err) {
    console.error('[REPORTS/DENTIST]', err);
    return res.status(500).json({ success: false, message: 'Error generando reporte' });
  }
});

module.exports = router;
