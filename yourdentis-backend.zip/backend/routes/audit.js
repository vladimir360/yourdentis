// routes/audit.js
'use strict';

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, authorize('admin'));

// ── GET /api/audit ────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const {
      userId, action, entity,
      dateFrom, dateTo,
      page = 1, limit = 50,
    } = req.query;

    const clinicId = req.user.clinicId;
    const offset   = (parseInt(page) - 1) * parseInt(limit);

    let where    = 'WHERE al.clinic_id = ?';
    const params = [clinicId];

    if (userId)   { where += ' AND al.user_id = ?';  params.push(userId); }
    if (action)   { where += ' AND al.action = ?';   params.push(action); }
    if (entity)   { where += ' AND al.entity = ?';   params.push(entity); }
    if (dateFrom) { where += ' AND al.timestamp >= ?'; params.push(dateFrom); }
    if (dateTo)   { where += ' AND al.timestamp <= ?'; params.push(dateTo + ' 23:59:59'); }

    const countRows = await query(
      `SELECT COUNT(*) AS total FROM audit_logs al ${where}`,
      params
    );
    const total = countRows[0].total;

    const logs = await query(
      `SELECT
         al.*,
         CONCAT(u.first_name,' ',u.last_name) AS user_name,
         u.role                                AS user_role
       FROM audit_logs al
       LEFT JOIN users u ON u.id = al.user_id
       ${where}
       ORDER BY al.timestamp DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.json({
      success: true,
      data:    logs,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / parseInt(limit)) },
    });
  } catch (err) {
    console.error('[AUDIT/GET]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo auditoría' });
  }
});

// ── GET /api/audit/summary ────────────────────────────────────────────────────
router.get('/summary', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;

    const [byAction, byUser, recent] = await Promise.all([
      query(
        `SELECT action, COUNT(*) AS count
         FROM audit_logs WHERE clinic_id = ? AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         GROUP BY action ORDER BY count DESC LIMIT 10`,
        [clinicId]
      ),
      query(
        `SELECT
           CONCAT(u.first_name,' ',u.last_name) AS user_name,
           COUNT(*) AS count
         FROM audit_logs al
         LEFT JOIN users u ON u.id = al.user_id
         WHERE al.clinic_id = ? AND al.timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         GROUP BY al.user_id, user_name
         ORDER BY count DESC LIMIT 10`,
        [clinicId]
      ),
      query(
        `SELECT al.*,
           CONCAT(u.first_name,' ',u.last_name) AS user_name
         FROM audit_logs al
         LEFT JOIN users u ON u.id = al.user_id
         WHERE al.clinic_id = ?
         ORDER BY al.timestamp DESC LIMIT 20`,
        [clinicId]
      ),
    ]);

    return res.json({ success: true, data: { byAction, byUser, recent } });
  } catch (err) {
    console.error('[AUDIT/SUMMARY]', err);
    return res.status(500).json({ success: false, message: 'Error generando resumen de auditoría' });
  }
});

// ── Middleware exportado para uso en otras rutas ───────────────────────────────
async function logAction(clinicId, userId, action, entity, entityId, details = '', ipAddress = '') {
  try {
    await query(
      `INSERT INTO audit_logs
         (id, clinic_id, user_id, action, entity, entity_id, details, ip_address, timestamp)
       VALUES (?,?,?,?,?,?,?,?,NOW())`,
      [uuidv4(), clinicId, userId, action, entity, entityId, details, ipAddress]
    );
  } catch (err) {
    console.error('[AUDIT/LOG_ACTION]', err.message);
    // No lanzar el error para no interrumpir la operación principal
  }
}

module.exports = router;
module.exports.logAction = logAction;
