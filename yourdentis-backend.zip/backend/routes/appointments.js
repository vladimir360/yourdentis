// routes/appointments.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const VALID_STATUSES = [
  'scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled', 'no-show',
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function timeToMinutes(t) {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

function calcDuration(start, end) {
  return timeToMinutes(end) - timeToMinutes(start);
}

// ── GET /api/appointments ─────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const {
      date, dateFrom, dateTo, dentistId, patientId,
      status, page = 1, limit = 100,
    } = req.query;

    const clinicId = req.user.clinicId;
    const offset   = (parseInt(page) - 1) * parseInt(limit);
    let where      = 'WHERE a.clinic_id = ? AND a.deleted_at IS NULL';
    const params   = [clinicId];

    if (date)      { where += ' AND a.date = ?';       params.push(date); }
    if (dateFrom)  { where += ' AND a.date >= ?';      params.push(dateFrom); }
    if (dateTo)    { where += ' AND a.date <= ?';      params.push(dateTo); }
    if (dentistId) { where += ' AND a.dentist_id = ?'; params.push(dentistId); }
    if (patientId) { where += ' AND a.patient_id = ?'; params.push(patientId); }
    if (status)    { where += ' AND a.status = ?';     params.push(status); }

    const appointments = await query(
      `SELECT
         a.*,
         CONCAT(p.first_name,' ',p.last_name)   AS patient_name,
         p.phone                                 AS patient_phone,
         CONCAT(u.first_name,' ',u.last_name)    AS dentist_name,
         d.color                                 AS dentist_color
       FROM appointments a
       LEFT JOIN patients p ON p.id = a.patient_id
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users    u ON u.id = d.user_id
       ${where}
       ORDER BY a.date ASC, a.start_time ASC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.json({ success: true, data: appointments });
  } catch (err) {
    console.error('[APPOINTMENTS/GET_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo citas' });
  }
});

// ── GET /api/appointments/:id ─────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const rows = await query(
      `SELECT a.*,
         CONCAT(p.first_name,' ',p.last_name) AS patient_name,
         p.phone                              AS patient_phone,
         CONCAT(u.first_name,' ',u.last_name) AS dentist_name
       FROM appointments a
       LEFT JOIN patients p ON p.id = a.patient_id
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users    u ON u.id = d.user_id
       WHERE a.id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL`,
      [req.params.id, req.user.clinicId]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Cita no encontrada' });
    }

    return res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error('[APPOINTMENTS/GET_ONE]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo cita' });
  }
});

// ── POST /api/appointments ────────────────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'dentist', 'receptionist'),
  [
    body('patientId').notEmpty().withMessage('Paciente requerido'),
    body('dentistId').notEmpty().withMessage('Odontólogo requerido'),
    body('date').isISO8601().withMessage('Fecha inválida'),
    body('startTime').matches(/^\d{2}:\d{2}$/).withMessage('Hora de inicio inválida (HH:MM)'),
    body('endTime').matches(/^\d{2}:\d{2}$/).withMessage('Hora de fin inválida (HH:MM)'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        patientId, dentistId, date, startTime, endTime,
        type  = 'Consulta General',
        notes = '', room = '', color = '#3B82F6',
      } = req.body;

      const clinicId = req.user.clinicId;

      // Validar que end > start
      if (timeToMinutes(endTime) <= timeToMinutes(startTime)) {
        return res.status(400).json({
          success: false,
          message: 'La hora de fin debe ser posterior a la hora de inicio',
        });
      }

      // Detectar conflictos de horario
      const conflicts = await query(
        `SELECT id FROM appointments
         WHERE dentist_id = ? AND date = ?
           AND status NOT IN ('cancelled','no-show')
           AND deleted_at IS NULL
           AND start_time < ? AND end_time > ?`,
        [dentistId, date, endTime, startTime]
      );

      if (conflicts.length) {
        return res.status(409).json({
          success: false,
          message: 'El odontólogo ya tiene una cita en ese horario',
        });
      }

      const id       = uuidv4();
      const duration = calcDuration(startTime, endTime);

      await query(
        `INSERT INTO appointments
           (id, clinic_id, patient_id, dentist_id, date, start_time, end_time,
            duration, type, status, notes, room, color, reminder_sent, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,'scheduled',?,?,?,0,NOW())`,
        [id, clinicId, patientId, dentistId, date, startTime, endTime,
         duration, type, notes, room, color]
      );

      const created = await query('SELECT * FROM appointments WHERE id = ?', [id]);

      return res.status(201).json({
        success: true,
        message: 'Cita programada exitosamente',
        data:    created[0],
      });
    } catch (err) {
      console.error('[APPOINTMENTS/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando cita' });
    }
  }
);

// ── PUT /api/appointments/:id ─────────────────────────────────────────────────
router.put(
  '/:id',
  authorize('admin', 'dentist', 'receptionist'),
  async (req, res) => {
    try {
      const { date, startTime, endTime, type, notes, room, color, status } = req.body;

      let duration = null;
      if (startTime && endTime) {
        if (timeToMinutes(endTime) <= timeToMinutes(startTime)) {
          return res.status(400).json({
            success: false,
            message: 'La hora de fin debe ser posterior a la hora de inicio',
          });
        }
        duration = calcDuration(startTime, endTime);
      }

      await query(
        `UPDATE appointments SET
           date       = COALESCE(?, date),
           start_time = COALESCE(?, start_time),
           end_time   = COALESCE(?, end_time),
           duration   = COALESCE(?, duration),
           type       = COALESCE(?, type),
           notes      = COALESCE(?, notes),
           room       = COALESCE(?, room),
           color      = COALESCE(?, color),
           status     = COALESCE(?, status),
           updated_at = NOW()
         WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
        [date, startTime, endTime, duration, type, notes, room, color, status,
         req.params.id, req.user.clinicId]
      );

      const updated = await query('SELECT * FROM appointments WHERE id = ?', [req.params.id]);
      return res.json({ success: true, message: 'Cita actualizada', data: updated[0] });
    } catch (err) {
      console.error('[APPOINTMENTS/PUT]', err);
      return res.status(500).json({ success: false, message: 'Error actualizando cita' });
    }
  }
);

// ── PATCH /api/appointments/:id/status ───────────────────────────────────────
router.patch(
  '/:id/status',
  authorize('admin', 'dentist', 'receptionist'),
  [body('status').isIn(VALID_STATUSES).withMessage('Estado inválido')],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const { status } = req.body;
      const confirmedAt = status === 'confirmed' ? ', confirmed_at = NOW()' : '';

      const result = await query(
        `UPDATE appointments SET status = ?${confirmedAt}, updated_at = NOW()
         WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
        [status, req.params.id, req.user.clinicId]
      );

      if (!result.affectedRows) {
        return res.status(404).json({ success: false, message: 'Cita no encontrada' });
      }

      // Actualizar last_visit del paciente al completar
      if (status === 'completed') {
        const appt = await query(
          'SELECT patient_id, date FROM appointments WHERE id = ?',
          [req.params.id]
        );
        if (appt.length) {
          await query(
            'UPDATE patients SET last_visit = ? WHERE id = ?',
            [appt[0].date, appt[0].patient_id]
          );
        }
      }

      return res.json({ success: true, message: `Cita marcada como: ${status}` });
    } catch (err) {
      console.error('[APPOINTMENTS/STATUS]', err);
      return res.status(500).json({ success: false, message: 'Error actualizando estado' });
    }
  }
);

// ── DELETE /api/appointments/:id ──────────────────────────────────────────────
router.delete(
  '/:id',
  authorize('admin', 'dentist', 'receptionist'),
  async (req, res) => {
    try {
      const result = await query(
        `UPDATE appointments SET status = 'cancelled', deleted_at = NOW()
         WHERE id = ? AND clinic_id = ?`,
        [req.params.id, req.user.clinicId]
      );

      if (!result.affectedRows) {
        return res.status(404).json({ success: false, message: 'Cita no encontrada' });
      }

      return res.json({ success: true, message: 'Cita cancelada' });
    } catch (err) {
      console.error('[APPOINTMENTS/DELETE]', err);
      return res.status(500).json({ success: false, message: 'Error cancelando cita' });
    }
  }
);

module.exports = router;
