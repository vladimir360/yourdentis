// routes/patients.js
'use strict';

const express = require('express');
const { body, query: queryParam, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query, withTransaction } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ── GET /api/patients ─────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const {
      search,
      status,
      page  = 1,
      limit = 20,
    } = req.query;

    const offset    = (parseInt(page) - 1) * parseInt(limit);
    const clinicId  = req.user.clinicId;
    const params    = [clinicId];

    let where = 'WHERE p.clinic_id = ? AND p.deleted_at IS NULL';

    if (status) {
      where += ' AND p.status = ?';
      params.push(status);
    }

    if (search) {
      where +=
        ' AND (p.first_name LIKE ? OR p.last_name LIKE ?' +
        ' OR p.email LIKE ? OR p.phone LIKE ? OR p.id_number LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
    }

    const countRows = await query(
      `SELECT COUNT(*) AS total FROM patients p ${where}`,
      params
    );
    const total = countRows[0].total;

    const patients = await query(
      `SELECT
         p.id, p.first_name, p.last_name, p.email, p.phone,
         p.date_of_birth, p.gender, p.id_number,
         p.insurance_provider, p.blood_type, p.status,
         p.balance, p.registered_at, p.last_visit, p.photo_url,
         (SELECT COUNT(*) FROM appointments a
          WHERE a.patient_id = p.id AND a.deleted_at IS NULL) AS total_appointments
       FROM patients p
       ${where}
       ORDER BY p.registered_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.json({
      success: true,
      data:    patients,
      pagination: {
        page:  parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    console.error('[PATIENTS/GET_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo pacientes' });
  }
});

// ── GET /api/patients/:id ─────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const rows = await query(
      'SELECT * FROM patients WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Paciente no encontrado' });
    }

    const patient    = rows[0];
    const allergies  = await query(
      'SELECT allergy FROM patient_allergies WHERE patient_id = ?',
      [patient.id]
    );
    const medications = await query(
      'SELECT medication FROM patient_medications WHERE patient_id = ?',
      [patient.id]
    );

    patient.allergies   = allergies.map((r) => r.allergy);
    patient.medications = medications.map((r) => r.medication);

    return res.json({ success: true, data: patient });
  } catch (err) {
    console.error('[PATIENTS/GET_ONE]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo paciente' });
  }
});

// ── GET /api/patients/:id/history ─────────────────────────────────────────────
router.get('/:id/history', async (req, res) => {
  try {
    const { id }     = req.params;
    const clinicId   = req.user.clinicId;

    // Verificar pertenencia
    const check = await query(
      'SELECT id FROM patients WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [id, clinicId]
    );
    if (!check.length) {
      return res.status(404).json({ success: false, message: 'Paciente no encontrado' });
    }

    const [appointments, treatments, invoices, notes] = await Promise.all([
      query(
        `SELECT a.*, CONCAT(u.first_name,' ',u.last_name) AS dentist_name
         FROM appointments a
         LEFT JOIN dentists  d ON d.id = a.dentist_id
         LEFT JOIN users     u ON u.id = d.user_id
         WHERE a.patient_id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL
         ORDER BY a.date DESC LIMIT 50`,
        [id, clinicId]
      ),
      query(
        `SELECT * FROM treatments
         WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL
         ORDER BY date DESC`,
        [id, clinicId]
      ),
      query(
        `SELECT id, invoice_number, date, total, paid, status
         FROM invoices
         WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL
         ORDER BY date DESC`,
        [id, clinicId]
      ),
      query(
        `SELECT cn.*, CONCAT(u.first_name,' ',u.last_name) AS dentist_name
         FROM clinical_notes cn
         LEFT JOIN dentists d ON d.id = cn.dentist_id
         LEFT JOIN users    u ON u.id = d.user_id
         WHERE cn.patient_id = ? AND cn.clinic_id = ? AND cn.deleted_at IS NULL
         ORDER BY cn.date DESC`,
        [id, clinicId]
      ),
    ]);

    return res.json({
      success: true,
      data:    { appointments, treatments, invoices, clinicalNotes: notes },
    });
  } catch (err) {
    console.error('[PATIENTS/HISTORY]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo historial' });
  }
});

// ── POST /api/patients ────────────────────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'dentist', 'receptionist'),
  [
    body('firstName').trim().notEmpty().withMessage('Nombre requerido'),
    body('lastName').trim().notEmpty().withMessage('Apellido requerido'),
    body('phone').notEmpty().withMessage('Teléfono requerido'),
    body('dateOfBirth').isISO8601().withMessage('Fecha de nacimiento inválida'),
    body('gender').isIn(['M', 'F', 'O']).withMessage('Género inválido'),
    body('email').optional({ nullable: true }).isEmail().normalizeEmail(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        firstName, lastName, email        = null, phone,
        dateOfBirth, gender,
        address     = '', city            = '', idNumber    = '',
        insuranceProvider = null, insuranceNumber = null,
        medicalHistory    = '', bloodType         = '',
        emergencyContact  = '', emergencyPhone    = '',
        notes       = '', allergies              = [],
        medications = [],
      } = req.body;

      const id       = uuidv4();
      const clinicId = req.user.clinicId;

      await withTransaction(async (conn) => {
        await conn.query(
          `INSERT INTO patients
             (id, clinic_id, first_name, last_name, email, phone,
              date_of_birth, gender, address, city, id_number,
              insurance_provider, insurance_number, medical_history,
              blood_type, emergency_contact, emergency_phone,
              notes, status, balance)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',0)`,
          [
            id, clinicId, firstName, lastName, email, phone,
            dateOfBirth, gender, address, city, idNumber,
            insuranceProvider, insuranceNumber, medicalHistory,
            bloodType, emergencyContact, emergencyPhone, notes,
          ]
        );

        if (allergies.length) {
          await conn.query(
            'INSERT INTO patient_allergies (id, patient_id, allergy) VALUES ?',
            [allergies.map((a) => [uuidv4(), id, a])]
          );
        }

        if (medications.length) {
          await conn.query(
            'INSERT INTO patient_medications (id, patient_id, medication) VALUES ?',
            [medications.map((m) => [uuidv4(), id, m])]
          );
        }
      });

      const created = await query('SELECT * FROM patients WHERE id = ?', [id]);

      return res.status(201).json({
        success: true,
        message: 'Paciente registrado exitosamente',
        data:    created[0],
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
          success: false,
          message: 'Ya existe un paciente con ese correo o número de cédula',
        });
      }
      console.error('[PATIENTS/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando paciente' });
    }
  }
);

// ── PUT /api/patients/:id ─────────────────────────────────────────────────────
router.put(
  '/:id',
  authorize('admin', 'dentist', 'receptionist'),
  async (req, res) => {
    try {
      const { id }   = req.params;
      const clinicId = req.user.clinicId;

      const existing = await query(
        'SELECT id FROM patients WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
        [id, clinicId]
      );
      if (!existing.length) {
        return res.status(404).json({ success: false, message: 'Paciente no encontrado' });
      }

      const {
        firstName, lastName, email, phone, dateOfBirth, gender,
        address, city, idNumber, insuranceProvider, insuranceNumber,
        medicalHistory, bloodType, emergencyContact, emergencyPhone,
        notes, status, allergies, medications,
      } = req.body;

      await withTransaction(async (conn) => {
        await conn.query(
          `UPDATE patients SET
             first_name         = COALESCE(?, first_name),
             last_name          = COALESCE(?, last_name),
             email              = COALESCE(?, email),
             phone              = COALESCE(?, phone),
             date_of_birth      = COALESCE(?, date_of_birth),
             gender             = COALESCE(?, gender),
             address            = COALESCE(?, address),
             city               = COALESCE(?, city),
             id_number          = COALESCE(?, id_number),
             insurance_provider = COALESCE(?, insurance_provider),
             insurance_number   = COALESCE(?, insurance_number),
             medical_history    = COALESCE(?, medical_history),
             blood_type         = COALESCE(?, blood_type),
             emergency_contact  = COALESCE(?, emergency_contact),
             emergency_phone    = COALESCE(?, emergency_phone),
             notes              = COALESCE(?, notes),
             status             = COALESCE(?, status),
             updated_at         = NOW()
           WHERE id = ?`,
          [
            firstName, lastName, email, phone, dateOfBirth, gender,
            address, city, idNumber, insuranceProvider, insuranceNumber,
            medicalHistory, bloodType, emergencyContact, emergencyPhone,
            notes, status, id,
          ]
        );

        if (Array.isArray(allergies)) {
          await conn.query('DELETE FROM patient_allergies WHERE patient_id = ?', [id]);
          if (allergies.length) {
            await conn.query(
              'INSERT INTO patient_allergies (id, patient_id, allergy) VALUES ?',
              [allergies.map((a) => [uuidv4(), id, a])]
            );
          }
        }

        if (Array.isArray(medications)) {
          await conn.query('DELETE FROM patient_medications WHERE patient_id = ?', [id]);
          if (medications.length) {
            await conn.query(
              'INSERT INTO patient_medications (id, patient_id, medication) VALUES ?',
              [medications.map((m) => [uuidv4(), id, m])]
            );
          }
        }
      });

      const updated = await query('SELECT * FROM patients WHERE id = ?', [id]);
      return res.json({
        success: true,
        message: 'Paciente actualizado',
        data:    updated[0],
      });
    } catch (err) {
      console.error('[PATIENTS/PUT]', err);
      return res.status(500).json({ success: false, message: 'Error actualizando paciente' });
    }
  }
);

// ── DELETE /api/patients/:id ──────────────────────────────────────────────────
router.delete('/:id', authorize('admin'), async (req, res) => {
  try {
    const result = await query(
      'UPDATE patients SET deleted_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ success: false, message: 'Paciente no encontrado' });
    }

    return res.json({ success: true, message: 'Paciente eliminado correctamente' });
  } catch (err) {
    console.error('[PATIENTS/DELETE]', err);
    return res.status(500).json({ success: false, message: 'Error eliminando paciente' });
  }
});

module.exports = router;
