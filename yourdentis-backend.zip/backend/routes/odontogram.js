// routes/odontogram.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query, withTransaction } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const VALID_CONDITIONS = [
  'healthy', 'cavity', 'filling', 'crown', 'extraction',
  'root-canal', 'implant', 'sealant', 'bridge', 'veneer',
  'fracture', 'absent',
];

// ── GET /api/odontogram/:patientId ────────────────────────────────────────────
// Devuelve el estado actual del odontograma (último registro por diente)
router.get('/:patientId', async (req, res) => {
  try {
    const entries = await query(
      `SELECT oe.*,
         CONCAT(u.first_name,' ',u.last_name) AS dentist_name
       FROM odontogram_entries oe
       LEFT JOIN dentists d ON d.id = oe.dentist_id
       LEFT JOIN users    u ON u.id = d.user_id
       WHERE oe.patient_id = ? AND oe.deleted_at IS NULL
       ORDER BY oe.tooth_number, oe.created_at DESC`,
      [req.params.patientId]
    );

    // Agrupar por diente → estado más reciente
    const teethMap = {};
    for (const entry of entries) {
      const tn = entry.tooth_number;
      if (!teethMap[tn]) {
        teethMap[tn] = {
          toothNumber:  tn,
          condition:    entry.condition,
          surfaces:     {},
          notes:        entry.notes,
          lastModified: entry.created_at,
          dentistName:  entry.dentist_name,
          history:      [],
        };
      }
      if (entry.surface) {
        teethMap[tn].surfaces[entry.surface] = entry.condition;
      }
      teethMap[tn].history.push({
        id:         entry.id,
        condition:  entry.condition,
        surface:    entry.surface,
        date:       entry.created_at,
        dentist:    entry.dentist_name,
        notes:      entry.notes,
      });
    }

    return res.json({
      success: true,
      data:    Object.values(teethMap).sort((a, b) => a.toothNumber - b.toothNumber),
    });
  } catch (err) {
    console.error('[ODONTOGRAM/GET]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo odontograma' });
  }
});

// ── GET /api/odontogram/:patientId/history ─────────────────────────────────────
router.get('/:patientId/history', async (req, res) => {
  try {
    const { toothNumber } = req.query;
    let where    = 'WHERE oe.patient_id = ? AND oe.deleted_at IS NULL';
    const params = [req.params.patientId];

    if (toothNumber) {
      where += ' AND oe.tooth_number = ?';
      params.push(parseInt(toothNumber));
    }

    const history = await query(
      `SELECT oe.*,
         CONCAT(u.first_name,' ',u.last_name) AS dentist_name
       FROM odontogram_entries oe
       LEFT JOIN dentists d ON d.id = oe.dentist_id
       LEFT JOIN users    u ON u.id = d.user_id
       ${where}
       ORDER BY oe.created_at DESC`,
      params
    );

    return res.json({ success: true, data: history });
  } catch (err) {
    console.error('[ODONTOGRAM/HISTORY]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo historial' });
  }
});

// ── POST /api/odontogram/:patientId ──────────────────────────────────────────
// Registrar condición en un solo diente
router.post(
  '/:patientId',
  authorize('admin', 'dentist'),
  [
    body('toothNumber').isInt({ min: 1, max: 52 }).withMessage('Número de diente inválido (1-52)'),
    body('condition').isIn(VALID_CONDITIONS).withMessage('Condición inválida'),
    body('dentistId').notEmpty().withMessage('Odontólogo requerido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        toothNumber, condition, surface = null,
        dentistId, treatmentId = null, notes = '',
      } = req.body;

      const id = uuidv4();

      await query(
        `INSERT INTO odontogram_entries
           (id, patient_id, dentist_id, tooth_number, \`condition\`,
            surface, treatment_id, notes, created_at)
         VALUES (?,?,?,?,?,?,?,?,NOW())`,
        [id, req.params.patientId, dentistId, toothNumber,
         condition, surface, treatmentId, notes]
      );

      return res.status(201).json({
        success: true,
        message: `Diente ${toothNumber} actualizado: ${condition}`,
      });
    } catch (err) {
      console.error('[ODONTOGRAM/POST]', err);
      return res.status(500).json({ success: false, message: 'Error actualizando odontograma' });
    }
  }
);

// ── POST /api/odontogram/:patientId/bulk ─────────────────────────────────────
// Guardar múltiples dientes a la vez (guardar odontograma completo)
router.post(
  '/:patientId/bulk',
  authorize('admin', 'dentist'),
  [
    body('entries').isArray({ min: 1 }).withMessage('Se requieren entradas'),
    body('dentistId').notEmpty().withMessage('Odontólogo requerido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const { entries, dentistId } = req.body;
      const patientId = req.params.patientId;

      await withTransaction(async (conn) => {
        for (const entry of entries) {
          await conn.query(
            `INSERT INTO odontogram_entries
               (id, patient_id, dentist_id, tooth_number, \`condition\`,
                surface, notes, created_at)
             VALUES (?,?,?,?,?,?,?,NOW())`,
            [
              uuidv4(), patientId, dentistId,
              entry.toothNumber, entry.condition,
              entry.surface || null, entry.notes || '',
            ]
          );
        }
      });

      return res.json({
        success: true,
        message: `${entries.length} registros guardados en odontograma`,
      });
    } catch (err) {
      console.error('[ODONTOGRAM/BULK]', err);
      return res.status(500).json({ success: false, message: 'Error guardando odontograma' });
    }
  }
);

module.exports = router;
