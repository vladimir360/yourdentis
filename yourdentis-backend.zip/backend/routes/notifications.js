// routes/notifications.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ── GET /api/notifications ────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { unreadOnly, type } = req.query;
    const clinicId = req.user.clinicId;
    const userId   = req.user.id;

    let where    = 'WHERE clinic_id = ? AND (user_id IS NULL OR user_id = ?) AND deleted_at IS NULL';
    const params = [clinicId, userId];

    if (unreadOnly === 'true') { where += ' AND read_at IS NULL'; }
    if (type)                  { where += ' AND type = ?'; params.push(type); }

    const rows = await query(
      `SELECT * FROM notifications ${where}
       ORDER BY created_at DESC LIMIT 50`,
      params
    );

    const [[{ unread }]] = await query(
      `SELECT COUNT(*) AS unread FROM notifications
       WHERE clinic_id = ? AND (user_id IS NULL OR user_id = ?)
         AND read_at IS NULL AND deleted_at IS NULL`,
      [clinicId, userId]
    );

    return res.json({ success: true, data: rows, unreadCount: unread });
  } catch (err) {
    console.error('[NOTIFICATIONS/GET]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo notificaciones' });
  }
});

// ── PATCH /api/notifications/:id/read ────────────────────────────────────────
router.patch('/:id/read', async (req, res) => {
  try {
    await query(
      'UPDATE notifications SET read_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]
    );
    return res.json({ success: true, message: 'Notificación marcada como leída' });
  } catch (err) {
    console.error('[NOTIFICATIONS/READ]', err);
    return res.status(500).json({ success: false, message: 'Error actualizando notificación' });
  }
});

// ── PATCH /api/notifications/read-all ────────────────────────────────────────
router.patch('/read-all', async (req, res) => {
  try {
    const result = await query(
      `UPDATE notifications
       SET read_at = NOW()
       WHERE clinic_id = ? AND (user_id IS NULL OR user_id = ?) AND read_at IS NULL`,
      [req.user.clinicId, req.user.id]
    );
    return res.json({
      success: true,
      message: `${result.affectedRows} notificaciones marcadas como leídas`,
    });
  } catch (err) {
    console.error('[NOTIFICATIONS/READ_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error actualizando notificaciones' });
  }
});

// ── DELETE /api/notifications/:id ─────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    await query(
      'UPDATE notifications SET deleted_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]
    );
    return res.json({ success: true, message: 'Notificación eliminada' });
  } catch (err) {
    console.error('[NOTIFICATIONS/DELETE]', err);
    return res.status(500).json({ success: false, message: 'Error eliminando notificación' });
  }
});

// ── POST /api/notifications (admin: crear notificación manual) ────────────────
router.post(
  '/',
  authorize('admin'),
  [
    body('title').notEmpty().withMessage('Título requerido'),
    body('message').notEmpty().withMessage('Mensaje requerido'),
    body('type').isIn(['appointment_reminder', 'payment_due', 'low_stock', 'system', 'marketing']),
    body('priority').optional().isIn(['low', 'medium', 'high', 'urgent']),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        title, message, type,
        priority = 'medium',
        userId   = null,
      } = req.body;

      const id = uuidv4();
      await query(
        `INSERT INTO notifications
           (id, clinic_id, user_id, type, title, message, priority, created_at)
         VALUES (?,?,?,?,?,?,?,NOW())`,
        [id, req.user.clinicId, userId, type, title, message, priority]
      );

      return res.status(201).json({ success: true, message: 'Notificación creada' });
    } catch (err) {
      console.error('[NOTIFICATIONS/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando notificación' });
    }
  }
);

module.exports = router;
