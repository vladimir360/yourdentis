// routes/treatments.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ── GET /api/treatments ───────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { patientId, dentistId, status, page = 1, limit = 50 } = req.query;
    const clinicId = req.user.clinicId;
    const offset   = (parseInt(page) - 1) * parseInt(limit);

    let where    = 'WHERE t.clinic_id = ? AND t.deleted_at IS NULL';
    const params = [clinicId];

    if (patientId) { where += ' AND t.patient_id = ?'; params.push(patientId); }
    if (dentistId) { where += ' AND t.dentist_id = ?'; params.push(dentistId); }
    if (status)    { where += ' AND t.status = ?';     params.push(status); }

    const rows = await query(
      `SELECT
         t.*,
         CONCAT(p.first_name,' ',p.last_name) AS patient_name,
         CONCAT(u.first_name,' ',u.last_name) AS dentist_name
       FROM treatments t
       LEFT JOIN patients p ON p.id = t.patient_id
       LEFT JOIN dentists d ON d.id = t.dentist_id
       LEFT JOIN users    u ON u.id = d.user_id
       ${where}
       ORDER BY t.date DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error('[TREATMENTS/GET_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo tratamientos' });
  }
});

// ── GET /api/treatments/catalog ───────────────────────────────────────────────
router.get('/catalog', async (req, res) => {
  try {
    const { q } = req.query;
    const rows  = await query(
      `SELECT * FROM treatment_catalog
       WHERE deleted_at IS NULL
         AND (clinic_id IS NULL OR clinic_id = ?)
         AND (? IS NULL OR name LIKE ? OR code LIKE ?)
       ORDER BY name
       LIMIT 30`,
      [req.user.clinicId, q || null, `%${q}%`, `%${q}%`]
    );
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error('[TREATMENTS/CATALOG]', err);
    return res.status(500).json({ success: false, message: 'Error buscando catálogo' });
  }
});

// ── GET /api/treatments/:id ───────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const rows = await query(
      'SELECT * FROM treatments WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Tratamiento no encontrado' });
    }
    return res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error('[TREATMENTS/GET_ONE]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo tratamiento' });
  }
});

// ── POST /api/treatments ──────────────────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'dentist'),
  [
    body('patientId').notEmpty().withMessage('Paciente requerido'),
    body('dentistId').notEmpty().withMessage('Odontólogo requerido'),
    body('type').notEmpty().withMessage('Tipo de tratamiento requerido'),
    body('cost').isFloat({ min: 0 }).withMessage('Costo inválido'),
    body('date').isISO8601().withMessage('Fecha inválida'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        patientId, dentistId, appointmentId = null,
        toothNumber = null, toothSurface = null,
        type, code = '', description = '',
        cost, discount = 0, date, notes = '',
      } = req.body;

      const id = uuidv4();

      await query(
        `INSERT INTO treatments
           (id, clinic_id, patient_id, dentist_id, appointment_id,
            tooth_number, tooth_surface, type, code, description,
            status, cost, discount, date, notes, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,'planned',?,?,?,?,NOW())`,
        [
          id, req.user.clinicId, patientId, dentistId, appointmentId,
          toothNumber, toothSurface, type, code, description,
          parseFloat(cost), parseFloat(discount), date, notes,
        ]
      );

      const created = await query('SELECT * FROM treatments WHERE id = ?', [id]);
      return res.status(201).json({
        success: true,
        message: 'Tratamiento registrado',
        data:    created[0],
      });
    } catch (err) {
      console.error('[TREATMENTS/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando tratamiento' });
    }
  }
);

// ── PUT /api/treatments/:id ───────────────────────────────────────────────────
router.put('/:id', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const {
      status, cost, discount, notes,
      completedDate, toothNumber, toothSurface, description,
    } = req.body;

    await query(
      `UPDATE treatments SET
         status          = COALESCE(?, status),
         cost            = COALESCE(?, cost),
         discount        = COALESCE(?, discount),
         notes           = COALESCE(?, notes),
         completed_date  = COALESCE(?, completed_date),
         tooth_number    = COALESCE(?, tooth_number),
         tooth_surface   = COALESCE(?, tooth_surface),
         description     = COALESCE(?, description),
         updated_at      = NOW()
       WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
      [status, cost, discount, notes, completedDate,
       toothNumber, toothSurface, description,
       req.params.id, req.user.clinicId]
    );

    const updated = await query('SELECT * FROM treatments WHERE id = ?', [req.params.id]);
    return res.json({ success: true, message: 'Tratamiento actualizado', data: updated[0] });
  } catch (err) {
    console.error('[TREATMENTS/PUT]', err);
    return res.status(500).json({ success: false, message: 'Error actualizando tratamiento' });
  }
});

// ── DELETE /api/treatments/:id ────────────────────────────────────────────────
router.delete('/:id', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const result = await query(
      `UPDATE treatments SET status = 'cancelled', deleted_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) {
      return res.status(404).json({ success: false, message: 'Tratamiento no encontrado' });
    }
    return res.json({ success: true, message: 'Tratamiento cancelado' });
  } catch (err) {
    console.error('[TREATMENTS/DELETE]', err);
    return res.status(500).json({ success: false, message: 'Error eliminando tratamiento' });
  }
});

module.exports = router;
