// routes/billing.js
'use strict';

const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const { query, withTransaction } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ── GET /api/billing ──────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { patientId, status, dateFrom, dateTo, page = 1, limit = 20 } = req.query;
    const clinicId = req.user.clinicId;
    const offset   = (parseInt(page) - 1) * parseInt(limit);

    let where    = 'WHERE i.clinic_id = ? AND i.deleted_at IS NULL';
    const params = [clinicId];

    if (patientId) { where += ' AND i.patient_id = ?'; params.push(patientId); }
    if (status)    { where += ' AND i.status = ?';     params.push(status); }
    if (dateFrom)  { where += ' AND i.date >= ?';      params.push(dateFrom); }
    if (dateTo)    { where += ' AND i.date <= ?';      params.push(dateTo); }

    const countRows = await query(
      `SELECT COUNT(*) AS total FROM invoices i ${where}`,
      params
    );
    const total = countRows[0].total;

    const invoices = await query(
      `SELECT
         i.*,
         CONCAT(p.first_name,' ',p.last_name) AS patient_name
       FROM invoices i
       LEFT JOIN patients p ON p.id = i.patient_id
       ${where}
       ORDER BY i.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    // Cargar items de cada factura
    for (const inv of invoices) {
      inv.items = await query(
        'SELECT * FROM invoice_items WHERE invoice_id = ?',
        [inv.id]
      );
    }

    return res.json({
      success: true,
      data:    invoices,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / parseInt(limit)) },
    });
  } catch (err) {
    console.error('[BILLING/GET_ALL]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo facturas' });
  }
});

// ── GET /api/billing/:id ──────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const rows = await query(
      `SELECT i.*,
         CONCAT(p.first_name,' ',p.last_name) AS patient_name,
         p.phone    AS patient_phone,
         p.email    AS patient_email,
         p.address  AS patient_address,
         p.id_number AS patient_id_number
       FROM invoices i
       LEFT JOIN patients p ON p.id = i.patient_id
       WHERE i.id = ? AND i.clinic_id = ? AND i.deleted_at IS NULL`,
      [req.params.id, req.user.clinicId]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'Factura no encontrada' });
    }

    const invoice  = rows[0];
    const [items, payments] = await Promise.all([
      query('SELECT * FROM invoice_items WHERE invoice_id = ?', [invoice.id]),
      query('SELECT * FROM payments WHERE invoice_id = ? ORDER BY date ASC', [invoice.id]),
    ]);

    invoice.items    = items;
    invoice.payments = payments;

    return res.json({ success: true, data: invoice });
  } catch (err) {
    console.error('[BILLING/GET_ONE]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo factura' });
  }
});

// ── POST /api/billing ─────────────────────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'dentist', 'receptionist'),
  [
    body('patientId').notEmpty().withMessage('Paciente requerido'),
    body('items').isArray({ min: 1 }).withMessage('Se requiere al menos un ítem'),
    body('items.*.description').notEmpty().withMessage('Descripción del ítem requerida'),
    body('items.*.quantity').isInt({ min: 1 }).withMessage('Cantidad inválida'),
    body('items.*.unitPrice').isFloat({ min: 0 }).withMessage('Precio unitario inválido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        patientId, items,
        taxRate  = 0,
        discount = 0,
        dueDate  = null,
        notes    = '',
      } = req.body;

      const clinicId = req.user.clinicId;

      // Calcular totales
      let subtotal = 0;
      const processedItems = items.map((item) => {
        const itemDiscount = parseFloat(item.discount || 0);
        const itemTotal    = parseFloat(
          (item.quantity * item.unitPrice * (1 - itemDiscount / 100)).toFixed(2)
        );
        subtotal += itemTotal;
        return { ...item, discount: itemDiscount, total: itemTotal };
      });

      subtotal  = parseFloat(subtotal.toFixed(2));
      const tax = parseFloat((subtotal * parseFloat(taxRate) / 100).toFixed(2));
      const total = parseFloat((subtotal + tax - parseFloat(discount)).toFixed(2));

      const id = uuidv4();

      await withTransaction(async (conn) => {
        // Número de factura secuencial por clínica
        const [[{ count }]] = await conn.query(
          'SELECT COUNT(*) AS count FROM invoices WHERE clinic_id = ?',
          [clinicId]
        );
        const invoiceNumber = `INV-${String(count + 1).padStart(5, '0')}`;

        await conn.query(
          `INSERT INTO invoices
             (id, clinic_id, patient_id, invoice_number, date, due_date,
              subtotal, tax_rate, tax, discount, total, paid, status, notes, created_at)
           VALUES (?,?,?,?,NOW(),?,?,?,?,?,?,0,'pending',?,NOW())`,
          [
            id, clinicId, patientId, invoiceNumber, dueDate,
            subtotal, taxRate, tax, discount, total, notes,
          ]
        );

        for (const item of processedItems) {
          await conn.query(
            `INSERT INTO invoice_items
               (id, invoice_id, treatment_id, description, quantity, unit_price, discount, total)
             VALUES (?,?,?,?,?,?,?,?)`,
            [
              uuidv4(), id, item.treatmentId || null,
              item.description, item.quantity, item.unitPrice,
              item.discount, item.total,
            ]
          );
        }

        // Actualizar balance del paciente
        await conn.query(
          'UPDATE patients SET balance = balance + ? WHERE id = ?',
          [total, patientId]
        );
      });

      const created = await query('SELECT * FROM invoices WHERE id = ?', [id]);
      return res.status(201).json({
        success: true,
        message: `Factura ${created[0].invoice_number} creada`,
        data:    created[0],
      });
    } catch (err) {
      console.error('[BILLING/POST]', err);
      return res.status(500).json({ success: false, message: 'Error creando factura' });
    }
  }
);

// ── POST /api/billing/:id/payments ────────────────────────────────────────────
router.post(
  '/:id/payments',
  authorize('admin', 'dentist', 'receptionist'),
  [
    body('amount').isFloat({ min: 0.01 }).withMessage('Monto inválido'),
    body('method')
      .isIn(['cash', 'card', 'transfer', 'digital', 'check'])
      .withMessage('Método de pago inválido'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const { amount, method, reference = null, notes = '' } = req.body;
      const invoiceId = req.params.id;

      await withTransaction(async (conn) => {
        const [[invoice]] = await conn.query(
          'SELECT * FROM invoices WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL FOR UPDATE',
          [invoiceId, req.user.clinicId]
        );

        if (!invoice) {
          throw Object.assign(new Error('Factura no encontrada'), { statusCode: 404 });
        }

        if (invoice.status === 'paid') {
          throw Object.assign(new Error('La factura ya está pagada completamente'), { statusCode: 400 });
        }

        const newPaid = parseFloat((invoice.paid + parseFloat(amount)).toFixed(2));
        let newStatus = 'partial';
        if (newPaid >= invoice.total) newStatus = 'paid';
        if (newPaid <= 0)            newStatus = 'pending';

        await conn.query(
          'INSERT INTO payments (id, invoice_id, date, amount, method, reference, notes, received_by, created_at) VALUES (?,?,NOW(),?,?,?,?,?,NOW())',
          [uuidv4(), invoiceId, amount, method, reference, notes, req.user.id]
        );

        await conn.query(
          'UPDATE invoices SET paid = ?, status = ?, updated_at = NOW() WHERE id = ?',
          [newPaid, newStatus, invoiceId]
        );

        // Reducir balance del paciente
        await conn.query(
          'UPDATE patients SET balance = balance - ? WHERE id = ?',
          [amount, invoice.patient_id]
        );
      });

      return res.status(201).json({
        success: true,
        message: `Pago de ${amount} registrado exitosamente`,
      });
    } catch (err) {
      if (err.statusCode) {
        return res.status(err.statusCode).json({ success: false, message: err.message });
      }
      console.error('[BILLING/PAYMENTS]', err);
      return res.status(500).json({ success: false, message: 'Error registrando pago' });
    }
  }
);

// ── GET /api/billing/payments/history ─────────────────────────────────────────
router.get('/payments/history', async (req, res) => {
  try {
    const { dateFrom, dateTo, method } = req.query;
    let where    = 'WHERE i.clinic_id = ?';
    const params = [req.user.clinicId];

    if (dateFrom) { where += ' AND p.date >= ?'; params.push(dateFrom); }
    if (dateTo)   { where += ' AND p.date <= ?'; params.push(dateTo); }
    if (method)   { where += ' AND p.method = ?'; params.push(method); }

    const payments = await query(
      `SELECT p.*, i.invoice_number,
         CONCAT(pt.first_name,' ',pt.last_name) AS patient_name
       FROM payments p
       JOIN invoices i  ON i.id  = p.invoice_id
       JOIN patients pt ON pt.id = i.patient_id
       ${where}
       ORDER BY p.date DESC LIMIT 200`,
      params
    );

    const [[{ totalAmount }]] = await query(
      `SELECT SUM(p.amount) AS totalAmount
       FROM payments p
       JOIN invoices i ON i.id = p.invoice_id
       ${where}`,
      params
    );

    return res.json({ success: true, data: payments, totalAmount });
  } catch (err) {
    console.error('[BILLING/PAYMENTS_HISTORY]', err);
    return res.status(500).json({ success: false, message: 'Error obteniendo pagos' });
  }
});

module.exports = router;
