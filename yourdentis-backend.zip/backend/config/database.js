// config/database.js
'use strict';

const mysql = require('mysql2/promise');

// ── Pool de conexiones ────────────────────────────────────────────────────────
const pool = mysql.createPool({
  host:              process.env.DB_HOST     || 'localhost',
  port:              parseInt(process.env.DB_PORT) || 3306,
  database:          process.env.DB_NAME     || 'yourdentis_db',
  user:              process.env.DB_USER     || 'root',
  password:          process.env.DB_PASSWORD || '',
  waitForConnections: true,
  connectionLimit:   parseInt(process.env.DB_CONNECTION_LIMIT) || 20,
  queueLimit:        0,
  charset:           'utf8mb4',
  timezone:          '+00:00',
  decimalNumbers:    true,
});

// ── Verificar conexión al arrancar ────────────────────────────────────────────
async function testConnection() {
  try {
    const conn = await pool.getConnection();
    console.log('✅  MySQL conectado correctamente');
    conn.release();
  } catch (err) {
    console.error('❌  Error conectando a MySQL:', err.message);
    process.exit(1);
  }
}

// ── Helper: ejecutar query con manejo de errores ──────────────────────────────
async function query(sql, params = []) {
  try {
    const [rows] = await pool.query(sql, params);
    return rows;
  } catch (err) {
    console.error('DB Query Error:', err.message, '\nSQL:', sql);
    throw err;
  }
}

// ── Helper: transacciones ─────────────────────────────────────────────────────
async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { pool, query, withTransaction, testConnection };
