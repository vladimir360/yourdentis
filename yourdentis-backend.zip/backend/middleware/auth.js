// middleware/auth.js
'use strict';

const jwt  = require('jsonwebtoken');
const { query } = require('../config/database');

// ── Verificar token JWT ───────────────────────────────────────────────────────
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization;

    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Token de autenticación requerido',
      });
    }

    const token   = header.slice(7);
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    // Comprobar que el usuario sigue activo en BD
    const rows = await query(
      `SELECT id, clinic_id, role, status
       FROM users
       WHERE id = ? AND deleted_at IS NULL`,
      [payload.userId]
    );

    if (!rows.length || rows[0].status !== 'active') {
      return res.status(401).json({
        success: false,
        message: 'Usuario no autorizado o suspendido',
      });
    }

    req.user = {
      id:       rows[0].id,
      clinicId: rows[0].clinic_id,
      role:     rows[0].role,
    };

    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token expirado. Inicia sesión de nuevo.',
        code:    'TOKEN_EXPIRED',
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Token inválido',
    });
  }
}

// ── Autorización por rol ──────────────────────────────────────────────────────
// Uso: authorize('admin', 'dentist')
function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'No autenticado' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Acceso denegado. Se requiere rol: ${roles.join(' o ')}`,
      });
    }
    next();
  };
}

// ── Aislamiento multi-clínica ─────────────────────────────────────────────────
// Asegura que el usuario solo accede a datos de su propia clínica
function sameClinic(req, res, next) {
  const clinicIdParam = req.params.clinicId || req.body?.clinicId;
  if (clinicIdParam && clinicIdParam !== req.user.clinicId) {
    return res.status(403).json({
      success: false,
      message: 'Acceso denegado a recursos de otra clínica',
    });
  }
  next();
}

module.exports = { authenticate, authorize, sameClinic };
