// server.js
'use strict';

require('dotenv').config();

const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

const { testConnection } = require('./config/database');

const app = express();

// ── 1. SEGURIDAD ──────────────────────────────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// ── 2. CORS ───────────────────────────────────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:5173',
  'http://localhost:3000',
  'http://localhost:4173',
].filter(Boolean);

app.use(cors({
  origin(origin, cb) {
    // Permitir herramientas sin origin (Postman, curl, etc.) en desarrollo
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`Origen no permitido por CORS: ${origin}`));
  },
  credentials:     true,
  methods:         ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders:  ['Content-Type', 'Authorization'],
}));

// ── 3. RATE LIMITING ──────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs:        parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:             parseInt(process.env.RATE_LIMIT_MAX)        || 200,
  standardHeaders: true,
  legacyHeaders:   false,
  message:         { success: false, message: 'Demasiadas solicitudes. Intente en unos minutos.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  message:  { success: false, message: 'Demasiados intentos. Intente en 15 minutos.' },
});

app.use('/api/', globalLimiter);

// ── 4. BODY PARSING ───────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── 5. LOGGING ────────────────────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ── 6. ARCHIVOS ESTÁTICOS ─────────────────────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── 7. RUTAS ──────────────────────────────────────────────────────────────────
const authRoute          = require('./routes/auth');
const patientsRoute      = require('./routes/patients');
const appointmentsRoute  = require('./routes/appointments');
const treatmentsRoute    = require('./routes/treatments');
const billingRoute       = require('./routes/billing');
const inventoryRoute     = require('./routes/inventory');
const odontogramRoute    = require('./routes/odontogram');
const reportsRoute       = require('./routes/reports');
const notificationsRoute = require('./routes/notifications');
const auditRoute         = require('./routes/audit');

app.use('/api/auth',          authLimiter, authRoute);
app.use('/api/patients',      patientsRoute);
app.use('/api/appointments',  appointmentsRoute);
app.use('/api/treatments',    treatmentsRoute);
app.use('/api/billing',       billingRoute);
app.use('/api/inventory',     inventoryRoute);
app.use('/api/odontogram',    odontogramRoute);
app.use('/api/reports',       reportsRoute);
app.use('/api/notifications', notificationsRoute);
app.use('/api/audit',         auditRoute);

// ── 8. HEALTH CHECK ───────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({
    success:   true,
    service:   'YourDentis API',
    version:   '1.0.0',
    timestamp: new Date().toISOString(),
    env:       process.env.NODE_ENV || 'development',
  });
});

// ── 9. 404 ────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Ruta no encontrada: ${req.method} ${req.originalUrl}`,
  });
});

// ── 10. GLOBAL ERROR HANDLER ──────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);

  if (err.message?.includes('CORS')) {
    return res.status(403).json({ success: false, message: err.message });
  }

  const status  = err.status || err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production'
    ? 'Error interno del servidor'
    : err.message;

  return res.status(status).json({ success: false, message });
});

// ── 11. ARRANQUE ──────────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 3001;

async function bootstrap() {
  await testConnection();

  app.listen(PORT, () => {
    console.log('\n╔══════════════════════════════════════════════╗');
    console.log('║         🦷  YourDentis API  v1.0.0           ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log(`║  Puerto  : ${PORT.toString().padEnd(35)}║`);
    console.log(`║  Entorno : ${(process.env.NODE_ENV || 'development').padEnd(35)}║`);
    console.log(`║  Health  : http://localhost:${PORT}/api/health${''.padEnd(6)}║`);
    console.log('╚══════════════════════════════════════════════╝\n');
  });
}

bootstrap().catch((err) => {
  console.error('❌  Error al iniciar el servidor:', err.message);
  process.exit(1);
});

module.exports = app;
