# 🦷 YourDentis - Backend API REST

Backend completo en **Node.js + Express + MySQL** para el sistema de gestión odontológica YourDentis.

---

## 🏗️ Estructura del Proyecto

```
yourdentis-backend/
├── src/
│   ├── app.js                    # Punto de entrada
│   ├── routes/
│   │   ├── auth.js               # Login, logout, refresh, cambio de contraseña
│   │   ├── clinics.js            # Datos de la clínica
│   │   ├── users.js              # Gestión de usuarios
│   │   ├── patients.js           # CRUD pacientes + historial
│   │   ├── dentists.js           # Odontólogos + disponibilidad
│   │   ├── appointments.js       # Agenda y citas
│   │   ├── treatments.js         # Tratamientos + catálogo
│   │   ├── odontogram.js         # Odontograma por paciente
│   │   ├── invoices.js           # Facturación + pagos
│   │   ├── payments.js           # Historial de pagos
│   │   ├── inventory.js          # Inventario + movimientos de stock
│   │   ├── clinicalNotes.js      # Notas clínicas
│   │   ├── reports.js            # Reportes y estadísticas
│   │   ├── notifications.js      # Notificaciones
│   │   ├── settings.js           # Configuración de la clínica
│   │   └── dashboard.js          # Stats del dashboard
│   ├── middleware/
│   │   └── auth.js               # JWT + control de roles
│   └── utils/
│       └── setupDatabase.js      # Script de instalación BD
└── config/
    └── database.js               # Pool de conexiones MySQL
```

---

## ⚡ Instalación Rápida

### 1. Instalar dependencias
```bash
cd yourdentis-backend
npm install
```

### 2. Configurar variables de entorno
```bash
cp .env.example .env
nano .env   # Edita con tus datos de MySQL y JWT
```

### 3. Crear la base de datos
```bash
npm run db:setup
```
Esto crea todas las tablas y un usuario admin de ejemplo.

### 4. Iniciar el servidor
```bash
npm start          # Producción
npm run dev        # Desarrollo con hot-reload (requiere nodemon)
```

---

## 🌐 Endpoints de la API

Todos los endpoints requieren `Authorization: Bearer <token>` excepto login.

### 🔐 Autenticación
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/auth/login` | Iniciar sesión |
| POST | `/api/auth/logout` | Cerrar sesión |
| POST | `/api/auth/refresh` | Renovar token |
| GET  | `/api/auth/me` | Perfil del usuario actual |
| POST | `/api/auth/change-password` | Cambiar contraseña |

### 👥 Pacientes
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/patients` | Listar (con búsqueda y paginación) |
| POST | `/api/patients` | Crear paciente |
| GET | `/api/patients/:id` | Ver paciente |
| PUT | `/api/patients/:id` | Actualizar |
| DELETE | `/api/patients/:id` | Eliminar (soft) |
| GET | `/api/patients/:id/history` | Historial completo |

### 📅 Citas
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/appointments` | Listar (filtros: date, dentistId, status) |
| POST | `/api/appointments` | Crear cita |
| PUT | `/api/appointments/:id` | Editar cita |
| PATCH | `/api/appointments/:id/status` | Cambiar estado |
| DELETE | `/api/appointments/:id` | Cancelar |

### 🦷 Odontograma
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/odontogram/:patientId` | Estado actual |
| POST | `/api/odontogram/:patientId` | Registrar condición |
| POST | `/api/odontogram/:patientId/bulk` | Guardar múltiples |
| GET | `/api/odontogram/:patientId/history` | Historial |

### 💊 Tratamientos
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/treatments` | Listar |
| POST | `/api/treatments` | Crear |
| PUT | `/api/treatments/:id` | Actualizar |
| DELETE | `/api/treatments/:id` | Cancelar |
| GET | `/api/treatments/catalog/search?q=` | Buscar en catálogo |

### 💰 Facturación
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/invoices` | Listar facturas |
| POST | `/api/invoices` | Crear factura |
| GET | `/api/invoices/:id` | Ver detalle |
| POST | `/api/invoices/:id/payments` | Registrar pago |

### 📦 Inventario
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/inventory` | Listar (filtro lowStock=true) |
| POST | `/api/inventory` | Agregar artículo |
| PUT | `/api/inventory/:id` | Actualizar |
| POST | `/api/inventory/:id/movement` | Entrada/salida/ajuste |

### 📊 Reportes
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/reports/dashboard-summary` | KPIs del período |
| GET | `/api/reports/revenue` | Ingresos por período |
| GET | `/api/reports/appointments-stats` | Stats de citas |
| GET | `/api/reports/treatments-stats` | Stats de tratamientos |
| GET | `/api/reports/patient-growth` | Crecimiento de pacientes |

### 🏠 Dashboard
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/dashboard/stats` | Stats del día + alertas |

---

## 🔒 Seguridad

- **JWT** con expiración de 8h y refresh tokens de 7 días
- **Bcrypt** para contraseñas (rounds configurables)
- **Rate limiting**: 100 req/15min general, 10 req/15min en login
- **Helmet** para headers HTTP seguros
- **CORS** configurado para el dominio del frontend
- **Multi-tenant**: cada usuario solo accede a datos de su clínica
- **Soft deletes**: los datos nunca se borran físicamente
- **Roles**: `admin` > `dentist` > `receptionist`

---

## 🔧 Integrar con el Frontend (React)

En tu frontend, cambia el contexto para consumir la API:

```javascript
// Ejemplo de login
const response = await fetch('https://tu-dominio.com/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});
const { data } = await response.json();
localStorage.setItem('token', data.accessToken);

// Ejemplo de petición autenticada
const patients = await fetch('/api/patients', {
  headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
});
```

---

## 🚀 Despliegue en VPS

```bash
# Instalar PM2
npm install -g pm2

# Iniciar con PM2
pm2 start src/app.js --name yourdentis-api

# Autostart al reiniciar
pm2 startup
pm2 save
```

Nginx config (reverse proxy):
```nginx
location /api/ {
    proxy_pass http://localhost:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_cache_bypass $http_upgrade;
}
```

---

## 🧪 Credenciales de ejemplo (tras npm run db:setup)

| Rol | Email | Password |
|-----|-------|----------|
| Admin | admin@yourdentis.com | Admin123! |
| Odontólogo | dr.garcia@yourdentis.com | Dentist123! |
