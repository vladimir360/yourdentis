// src/utils/setupDatabase.js
// Ejecutar con: node src/utils/setupDatabase.js
require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

async function setup() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    charset: 'utf8mb4',
    multipleStatements: true,
  });

  console.log('🦷 YourDentis - Configurando base de datos...\n');

  // Crear BD
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME || 'yourdentis_db'}\`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await conn.query(`USE \`${process.env.DB_NAME || 'yourdentis_db'}\``);
  await conn.query(`SET FOREIGN_KEY_CHECKS = 0`);

  // ============================================================
  // TABLAS
  // ============================================================
  const tables = [
    // CLINICS
    `CREATE TABLE IF NOT EXISTS clinics (
      id              CHAR(36)     NOT NULL,
      name            VARCHAR(200) NOT NULL,
      legal_name      VARCHAR(200) NULL,
      tax_id          VARCHAR(50)  NULL,
      address         VARCHAR(500) NOT NULL DEFAULT '',
      city            VARCHAR(100) NOT NULL DEFAULT '',
      state           VARCHAR(100) NULL,
      country         VARCHAR(100) NOT NULL DEFAULT 'República Dominicana',
      postal_code     VARCHAR(20)  NULL,
      phone           VARCHAR(30)  NOT NULL DEFAULT '',
      email           VARCHAR(255) NOT NULL,
      website         VARCHAR(255) NULL,
      logo_url        VARCHAR(500) NULL,
      plan            ENUM('trial','basic','professional','enterprise') NOT NULL DEFAULT 'trial',
      status          ENUM('active','suspended','cancelled','trial') NOT NULL DEFAULT 'trial',
      trial_ends_at   DATETIME     NULL,
      max_users       INT          NOT NULL DEFAULT 10,
      max_patients    INT          NOT NULL DEFAULT 500,
      timezone        VARCHAR(50)  NOT NULL DEFAULT 'America/Santo_Domingo',
      locale          VARCHAR(10)  NOT NULL DEFAULT 'es',
      currency        VARCHAR(3)   NOT NULL DEFAULT 'DOP',
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_clinic_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // USERS
    `CREATE TABLE IF NOT EXISTS users (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      email           VARCHAR(255) NOT NULL,
      password_hash   VARCHAR(255) NOT NULL,
      first_name      VARCHAR(100) NOT NULL,
      last_name       VARCHAR(100) NOT NULL,
      phone           VARCHAR(30)  NULL,
      avatar_url      VARCHAR(500) NULL,
      role            ENUM('admin','dentist','receptionist','patient') NOT NULL DEFAULT 'receptionist',
      status          ENUM('active','inactive','blocked') NOT NULL DEFAULT 'active',
      last_login      DATETIME     NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_user_email (email),
      KEY idx_users_clinic (clinic_id),
      CONSTRAINT fk_users_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // USER SESSIONS
    `CREATE TABLE IF NOT EXISTS user_sessions (
      id              CHAR(36)     NOT NULL,
      user_id         CHAR(36)     NOT NULL,
      refresh_token   VARCHAR(500) NOT NULL,
      ip_address      VARCHAR(45)  NULL,
      user_agent      VARCHAR(500) NULL,
      expires_at      DATETIME     NOT NULL,
      revoked_at      DATETIME     NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_sessions_user (user_id),
      CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // DENTISTS
    `CREATE TABLE IF NOT EXISTS dentists (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      user_id         CHAR(36)     NULL,
      first_name      VARCHAR(100) NOT NULL,
      last_name       VARCHAR(100) NOT NULL,
      specialty       VARCHAR(200) NOT NULL DEFAULT 'Odontología General',
      license_number  VARCHAR(100) NULL,
      email           VARCHAR(255) NULL,
      phone           VARCHAR(30)  NULL,
      color           VARCHAR(7)   NOT NULL DEFAULT '#3B82F6',
      avatar_url      VARCHAR(500) NULL,
      status          ENUM('active','inactive') NOT NULL DEFAULT 'active',
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_dentists_clinic (clinic_id),
      CONSTRAINT fk_dentists_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id),
      CONSTRAINT fk_dentists_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // DENTIST SCHEDULES
    `CREATE TABLE IF NOT EXISTS dentist_schedules (
      id              CHAR(36)     NOT NULL,
      dentist_id      CHAR(36)     NOT NULL,
      day_of_week     TINYINT      NOT NULL COMMENT '0=Dom,1=Lun,...,6=Sab',
      start_time      TIME         NOT NULL,
      end_time        TIME         NOT NULL,
      room            VARCHAR(100) NULL,
      PRIMARY KEY (id),
      KEY idx_schedules_dentist (dentist_id),
      CONSTRAINT fk_schedules_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // PATIENTS
    `CREATE TABLE IF NOT EXISTS patients (
      id                  CHAR(36)     NOT NULL,
      clinic_id           CHAR(36)     NOT NULL,
      first_name          VARCHAR(100) NOT NULL,
      last_name           VARCHAR(100) NOT NULL,
      email               VARCHAR(255) NULL,
      phone               VARCHAR(30)  NOT NULL,
      date_of_birth       DATE         NOT NULL,
      gender              ENUM('M','F','O') NOT NULL DEFAULT 'O',
      address             VARCHAR(500) NULL,
      city                VARCHAR(100) NULL,
      id_number           VARCHAR(50)  NULL,
      insurance_provider  VARCHAR(200) NULL,
      insurance_number    VARCHAR(100) NULL,
      medical_history     TEXT         NULL,
      blood_type          VARCHAR(5)   NULL,
      emergency_contact   VARCHAR(200) NULL,
      emergency_phone     VARCHAR(30)  NULL,
      notes               TEXT         NULL,
      status              ENUM('active','inactive') NOT NULL DEFAULT 'active',
      balance             DECIMAL(12,2) NOT NULL DEFAULT 0,
      registered_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      last_visit          DATE         NULL,
      photo_url           VARCHAR(500) NULL,
      created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at          DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at          DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_patients_clinic (clinic_id),
      KEY idx_patients_email (email),
      CONSTRAINT fk_patients_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // PATIENT ALLERGIES
    `CREATE TABLE IF NOT EXISTS patient_allergies (
      id          CHAR(36)     NOT NULL,
      patient_id  CHAR(36)     NOT NULL,
      allergy     VARCHAR(200) NOT NULL,
      PRIMARY KEY (id),
      KEY idx_allergies_patient (patient_id),
      CONSTRAINT fk_allergies_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // PATIENT MEDICATIONS
    `CREATE TABLE IF NOT EXISTS patient_medications (
      id          CHAR(36)     NOT NULL,
      patient_id  CHAR(36)     NOT NULL,
      medication  VARCHAR(200) NOT NULL,
      PRIMARY KEY (id),
      KEY idx_meds_patient (patient_id),
      CONSTRAINT fk_meds_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // APPOINTMENTS
    `CREATE TABLE IF NOT EXISTS appointments (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      patient_id      CHAR(36)     NOT NULL,
      dentist_id      CHAR(36)     NOT NULL,
      date            DATE         NOT NULL,
      start_time      TIME         NOT NULL,
      end_time        TIME         NOT NULL,
      duration        INT          NOT NULL DEFAULT 30,
      type            VARCHAR(200) NOT NULL DEFAULT 'Consulta General',
      status          ENUM('scheduled','confirmed','in-progress','completed','cancelled','no-show') NOT NULL DEFAULT 'scheduled',
      notes           TEXT         NULL,
      room            VARCHAR(100) NULL,
      color           VARCHAR(7)   NOT NULL DEFAULT '#3B82F6',
      reminder_sent   TINYINT(1)   NOT NULL DEFAULT 0,
      confirmed_at    DATETIME     NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_appts_clinic (clinic_id),
      KEY idx_appts_patient (patient_id),
      KEY idx_appts_dentist (dentist_id),
      KEY idx_appts_date (date),
      CONSTRAINT fk_appts_clinic   FOREIGN KEY (clinic_id)  REFERENCES clinics(id),
      CONSTRAINT fk_appts_patient  FOREIGN KEY (patient_id) REFERENCES patients(id),
      CONSTRAINT fk_appts_dentist  FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // TREATMENT CATALOG
    `CREATE TABLE IF NOT EXISTS treatment_catalog (
      id          CHAR(36)     NOT NULL,
      clinic_id   CHAR(36)     NULL COMMENT 'NULL = catálogo global',
      code        VARCHAR(50)  NOT NULL,
      name        VARCHAR(300) NOT NULL,
      description TEXT         NULL,
      default_price DECIMAL(10,2) NOT NULL DEFAULT 0,
      category    VARCHAR(100) NULL,
      deleted_at  DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_catalog_code (code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // TREATMENTS
    `CREATE TABLE IF NOT EXISTS treatments (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      patient_id      CHAR(36)     NOT NULL,
      dentist_id      CHAR(36)     NOT NULL,
      appointment_id  CHAR(36)     NULL,
      tooth_number    TINYINT      NULL,
      tooth_surface   VARCHAR(20)  NULL,
      type            VARCHAR(300) NOT NULL,
      code            VARCHAR(50)  NULL,
      description     TEXT         NULL,
      status          ENUM('planned','in-progress','completed','cancelled') NOT NULL DEFAULT 'planned',
      cost            DECIMAL(12,2) NOT NULL DEFAULT 0,
      discount        DECIMAL(12,2) NOT NULL DEFAULT 0,
      date            DATE         NOT NULL,
      completed_date  DATE         NULL,
      notes           TEXT         NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_treatments_clinic (clinic_id),
      KEY idx_treatments_patient (patient_id),
      CONSTRAINT fk_treatments_clinic  FOREIGN KEY (clinic_id)  REFERENCES clinics(id),
      CONSTRAINT fk_treatments_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
      CONSTRAINT fk_treatments_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // ODONTOGRAM ENTRIES
    `CREATE TABLE IF NOT EXISTS odontogram_entries (
      id              CHAR(36)     NOT NULL,
      patient_id      CHAR(36)     NOT NULL,
      dentist_id      CHAR(36)     NOT NULL,
      tooth_number    TINYINT      NOT NULL,
      \`condition\`  VARCHAR(50)  NOT NULL DEFAULT 'healthy',
      surface         VARCHAR(20)  NULL,
      date            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      treatment_id    CHAR(36)     NULL,
      notes           TEXT         NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_odonto_patient (patient_id),
      KEY idx_odonto_tooth (tooth_number),
      CONSTRAINT fk_odonto_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
      CONSTRAINT fk_odonto_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // INVOICES
    `CREATE TABLE IF NOT EXISTS invoices (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      patient_id      CHAR(36)     NOT NULL,
      invoice_number  VARCHAR(30)  NOT NULL,
      date            DATE         NOT NULL,
      due_date        DATE         NULL,
      subtotal        DECIMAL(12,2) NOT NULL DEFAULT 0,
      tax_rate        DECIMAL(5,2)  NOT NULL DEFAULT 0,
      tax             DECIMAL(12,2) NOT NULL DEFAULT 0,
      discount        DECIMAL(12,2) NOT NULL DEFAULT 0,
      total           DECIMAL(12,2) NOT NULL DEFAULT 0,
      paid            DECIMAL(12,2) NOT NULL DEFAULT 0,
      status          ENUM('pending','partial','paid','overdue','cancelled') NOT NULL DEFAULT 'pending',
      notes           TEXT         NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_invoice_number (clinic_id, invoice_number),
      KEY idx_invoices_clinic (clinic_id),
      KEY idx_invoices_patient (patient_id),
      CONSTRAINT fk_invoices_clinic  FOREIGN KEY (clinic_id)  REFERENCES clinics(id),
      CONSTRAINT fk_invoices_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // INVOICE ITEMS
    `CREATE TABLE IF NOT EXISTS invoice_items (
      id              CHAR(36)     NOT NULL,
      invoice_id      CHAR(36)     NOT NULL,
      treatment_id    CHAR(36)     NULL,
      description     VARCHAR(500) NOT NULL,
      quantity        INT          NOT NULL DEFAULT 1,
      unit_price      DECIMAL(12,2) NOT NULL DEFAULT 0,
      discount        DECIMAL(5,2)  NOT NULL DEFAULT 0,
      total           DECIMAL(12,2) NOT NULL DEFAULT 0,
      PRIMARY KEY (id),
      KEY idx_items_invoice (invoice_id),
      CONSTRAINT fk_items_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // PAYMENTS
    `CREATE TABLE IF NOT EXISTS payments (
      id          CHAR(36)     NOT NULL,
      invoice_id  CHAR(36)     NOT NULL,
      date        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      amount      DECIMAL(12,2) NOT NULL,
      method      ENUM('cash','card','transfer','digital','check') NOT NULL DEFAULT 'cash',
      reference   VARCHAR(200) NULL,
      notes       TEXT         NULL,
      received_by CHAR(36)     NULL,
      created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      deleted_at  DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_payments_invoice (invoice_id),
      CONSTRAINT fk_payments_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // CLINICAL NOTES
    `CREATE TABLE IF NOT EXISTS clinical_notes (
      id              CHAR(36)     NOT NULL,
      clinic_id       CHAR(36)     NOT NULL,
      patient_id      CHAR(36)     NOT NULL,
      dentist_id      CHAR(36)     NOT NULL,
      appointment_id  CHAR(36)     NULL,
      date            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      chief_complaint TEXT         NULL,
      diagnosis       TEXT         NULL,
      treatment_plan  TEXT         NULL,
      evolution       TEXT         NULL,
      private_notes   TEXT         NULL,
      vital_signs     JSON         NULL,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at      DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_notes_clinic (clinic_id),
      KEY idx_notes_patient (patient_id),
      CONSTRAINT fk_notes_clinic  FOREIGN KEY (clinic_id)  REFERENCES clinics(id),
      CONSTRAINT fk_notes_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
      CONSTRAINT fk_notes_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // INVENTORY ITEMS
    `CREATE TABLE IF NOT EXISTS inventory_items (
      id                  CHAR(36)     NOT NULL,
      clinic_id           CHAR(36)     NOT NULL,
      name                VARCHAR(300) NOT NULL,
      category            VARCHAR(100) NOT NULL DEFAULT 'General',
      sku                 VARCHAR(100) NULL,
      current_stock       INT          NOT NULL DEFAULT 0,
      min_stock           INT          NOT NULL DEFAULT 0,
      max_stock           INT          NOT NULL DEFAULT 9999,
      unit                VARCHAR(50)  NOT NULL DEFAULT 'unidad',
      unit_cost           DECIMAL(12,2) NOT NULL DEFAULT 0,
      sale_price          DECIMAL(12,2) NOT NULL DEFAULT 0,
      supplier            VARCHAR(300) NULL,
      supplier_contact    VARCHAR(300) NULL,
      location            VARCHAR(200) NULL,
      expiration_date     DATE         NULL,
      last_restocked      DATETIME     NULL,
      status              ENUM('active','discontinued') NOT NULL DEFAULT 'active',
      created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at          DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
      deleted_at          DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_inventory_clinic (clinic_id),
      CONSTRAINT fk_inventory_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // INVENTORY MOVEMENTS
    `CREATE TABLE IF NOT EXISTS inventory_movements (
      id        CHAR(36)     NOT NULL,
      item_id   CHAR(36)     NOT NULL,
      type      ENUM('in','out','adjustment') NOT NULL,
      quantity  INT          NOT NULL,
      reason    VARCHAR(500) NOT NULL,
      date      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      user_id   CHAR(36)     NULL,
      PRIMARY KEY (id),
      KEY idx_movements_item (item_id),
      CONSTRAINT fk_movements_item FOREIGN KEY (item_id) REFERENCES inventory_items(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // NOTIFICATIONS
    `CREATE TABLE IF NOT EXISTS notifications (
      id          CHAR(36)     NOT NULL,
      clinic_id   CHAR(36)     NOT NULL,
      user_id     CHAR(36)     NULL,
      type        ENUM('appointment_reminder','payment_due','low_stock','system','marketing') NOT NULL DEFAULT 'system',
      title       VARCHAR(300) NOT NULL,
      message     TEXT         NOT NULL,
      priority    ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
      read_at     DATETIME     NULL,
      created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      deleted_at  DATETIME     NULL,
      PRIMARY KEY (id),
      KEY idx_notif_clinic (clinic_id),
      KEY idx_notif_user (user_id),
      CONSTRAINT fk_notif_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // CLINIC SETTINGS
    `CREATE TABLE IF NOT EXISTS clinic_settings (
      id            CHAR(36)     NOT NULL,
      clinic_id     CHAR(36)     NOT NULL,
      settings_json LONGTEXT     NOT NULL,
      updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_settings_clinic (clinic_id),
      CONSTRAINT fk_settings_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // AUDIT LOGS
    `CREATE TABLE IF NOT EXISTS audit_logs (
      id          CHAR(36)     NOT NULL,
      clinic_id   CHAR(36)     NOT NULL,
      user_id     CHAR(36)     NULL,
      action      VARCHAR(100) NOT NULL,
      entity      VARCHAR(100) NOT NULL,
      entity_id   CHAR(36)     NULL,
      details     TEXT         NULL,
      ip_address  VARCHAR(45)  NULL,
      timestamp   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_audit_clinic (clinic_id),
      KEY idx_audit_timestamp (timestamp)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  ];

  for (const sql of tables) {
    try {
      const tableName = sql.match(/CREATE TABLE IF NOT EXISTS (\w+)/)?.[1];
      await conn.query(sql);
      console.log(`  ✅ Tabla: ${tableName}`);
    } catch (err) {
      console.error(`  ❌ Error: ${err.message}`);
    }
  }

  await conn.query(`SET FOREIGN_KEY_CHECKS = 1`);

  // ============================================================
  // DATOS DE EJEMPLO
  // ============================================================
  console.log('\n📦 Creando datos de ejemplo...');

  const clinicId = uuidv4();
  const adminId = uuidv4();
  const dentistUserId = uuidv4();
  const dentistId = uuidv4();
  const adminHash = await bcrypt.hash('Admin123!', 12);
  const dentistHash = await bcrypt.hash('Dentist123!', 12);

  // Clínica
  await conn.query(
    `INSERT IGNORE INTO clinics (id, name, address, city, phone, email, plan, status, currency)
     VALUES (?, 'Clínica Dental YourDentis', 'Av. Winston Churchill 1099', 'Santo Domingo', '809-555-1234', 'admin@yourdentis.com', 'professional', 'active', 'DOP')`,
    [clinicId]
  );

  // Admin
  await conn.query(
    `INSERT IGNORE INTO users (id, clinic_id, email, password_hash, first_name, last_name, role, status)
     VALUES (?, ?, 'admin@yourdentis.com', ?, 'Admin', 'Sistema', 'admin', 'active')`,
    [adminId, clinicId, adminHash]
  );

  // Dentist user
  await conn.query(
    `INSERT IGNORE INTO users (id, clinic_id, email, password_hash, first_name, last_name, role, status)
     VALUES (?, ?, 'dr.garcia@yourdentis.com', ?, 'Carlos', 'García', 'dentist', 'active')`,
    [dentistUserId, clinicId, dentistHash]
  );

  // Dentist profile
  await conn.query(
    `INSERT IGNORE INTO dentists (id, clinic_id, user_id, first_name, last_name, specialty, license_number, color)
     VALUES (?, ?, ?, 'Carlos', 'García', 'Ortodoncia', 'COL-2024-001', '#3B82F6')`,
    [dentistId, clinicId, dentistUserId]
  );

  // Horario del dentista (Lunes a Viernes 8am - 5pm)
  for (let day = 1; day <= 5; day++) {
    await conn.query(
      `INSERT IGNORE INTO dentist_schedules (id, dentist_id, day_of_week, start_time, end_time, room)
       VALUES (?, ?, ?, '08:00', '17:00', 'Consultorio 1')`,
      [uuidv4(), dentistId, day]
    );
  }

  console.log(`\n✅ Base de datos configurada exitosamente!`);
  console.log(`\n📋 CREDENCIALES DE ACCESO:`);
  console.log(`   🔑 Administrador:`);
  console.log(`      Email:    admin@yourdentis.com`);
  console.log(`      Password: Admin123!`);
  console.log(`   🦷 Odontólogo:`);
  console.log(`      Email:    dr.garcia@yourdentis.com`);
  console.log(`      Password: Dentist123!`);
  console.log(`\n🚀 Ahora puedes iniciar el servidor con: npm start\n`);

  await conn.end();
}

setup().catch(err => {
  console.error('❌ Error en setup:', err.message);
  process.exit(1);
});
