// src/app.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();

// ---- SEGURIDAD ----
app.use(helmet());

// ---- CORS ----
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:5173',
  'http://localhost:3000',
].filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    callback(new Error('No permitido por CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ---- RATE LIMITING ----
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Demasiadas solicitudes. Intente en unos minutos.' },
});
app.use('/api/', limiter);

// Límite más estricto para login
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Demasiados intentos de login. Intente en 15 minutos.' },
});

// ---- BODY PARSING ----
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ---- LOGGING ----
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('combined'));
}

// ---- ARCHIVOS ESTÁTICOS (uploads) ----
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ---- RUTAS ----
const authRoutes       = require('./routes/auth');
const clinicRoutes     = require('./routes/clinics');
const userRoutes       = require('./routes/users');
const patientRoutes    = require('./routes/patients');
const dentistRoutes    = require('./routes/dentists');
const appointmentRoutes = require('./routes/appointments');
const treatmentRoutes  = require('./routes/treatments');
const odontogramRoutes = require('./routes/odontogram');
const invoiceRoutes    = require('./routes/invoices');
const paymentRoutes    = require('./routes/payments');
const inventoryRoutes  = require('./routes/inventory');
const clinicalNoteRoutes = require('./routes/clinicalNotes');
const reportRoutes     = require('./routes/reports');
const notificationRoutes = require('./routes/notifications');
const settingsRoutes   = require('./routes/settings');
const dashboardRoutes  = require('./routes/dashboard');

app.use('/api/auth',          authLimiter, authRoutes);
app.use('/api/clinics',       clinicRoutes);
app.use('/api/users',         userRoutes);
app.use('/api/patients',      patientRoutes);
app.use('/api/dentists',      dentistRoutes);
app.use('/api/appointments',  appointmentRoutes);
app.use('/api/treatments',    treatmentRoutes);
app.use('/api/odontogram',    odontogramRoutes);
app.use('/api/invoices',      invoiceRoutes);
app.use('/api/payments',      paymentRoutes);
app.use('/api/inventory',     inventoryRoutes);
app.use('/api/clinical-notes', clinicalNoteRoutes);
app.use('/api/reports',       reportRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/settings',      settingsRoutes);
app.use('/api/dashboard',     dashboardRoutes);

// ---- HEALTH CHECK ----
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'YourDentis API funcionando', version: '1.0.0', timestamp: new Date().toISOString() });
});

// ---- 404 ----
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Ruta no encontrada: ${req.method} ${req.originalUrl}` });
});

// ---- ERROR HANDLER ----
app.use((err, req, res, next) => {
  console.error('Error:', err);
  if (err.name === 'ValidationError') {
    return res.status(400).json({ success: false, message: err.message });
  }
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ success: false, message: 'Token inválido o expirado' });
  }
  res.status(err.status || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Error interno del servidor' : err.message,
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n🦷 YourDentis API corriendo en puerto ${PORT}`);
  console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}`);
  console.log(`📡 Health check: http://localhost:${PORT}/api/health\n`);
});

module.exports = app;
