// src/routes/clinics.js
const express = require('express');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

router.get('/me', async (req, res) => {
  try {
    const [[clinic]] = await pool.query('SELECT * FROM clinics WHERE id = ?', [req.user.clinicId]);
    if (!clinic) return res.status(404).json({ success: false, message: 'Clínica no encontrada' });
    res.json({ success: true, data: clinic });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo clínica' });
  }
});

router.put('/me', authorize('admin'), async (req, res) => {
  try {
    const { name, address, phone, email, website, timezone, currency, locale } = req.body;
    await pool.query(
      `UPDATE clinics SET
        name = COALESCE(?, name), address = COALESCE(?, address),
        phone = COALESCE(?, phone), email = COALESCE(?, email),
        website = COALESCE(?, website), timezone = COALESCE(?, timezone),
        currency = COALESCE(?, currency), locale = COALESCE(?, locale),
        updated_at = NOW()
       WHERE id = ?`,
      [name, address, phone, email, website, timezone, currency, locale, req.user.clinicId]
    );
    res.json({ success: true, message: 'Clínica actualizada' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando clínica' });
  }
});

module.exports = router;
