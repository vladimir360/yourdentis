// src/routes/users.js
const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, authorize('admin'));

// GET /api/users
router.get('/', async (req, res) => {
  try {
    const [users] = await pool.query(
      `SELECT id, email, first_name, last_name, role, phone, avatar_url, status, last_login, created_at
       FROM users WHERE clinic_id = ? AND deleted_at IS NULL ORDER BY created_at DESC`,
      [req.user.clinicId]
    );
    res.json({ success: true, data: users });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo usuarios' });
  }
});

// POST /api/users
router.post('/', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('firstName').notEmpty(),
  body('lastName').notEmpty(),
  body('role').isIn(['admin', 'dentist', 'receptionist']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const { email, password, firstName, lastName, role, phone = null } = req.body;
    const hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    const id = uuidv4();

    await pool.query(
      `INSERT INTO users (id, clinic_id, email, password_hash, first_name, last_name, role, phone, status, created_at)
       VALUES (?,?,?,?,?,?,?,?,'active',NOW())`,
      [id, req.user.clinicId, email, hash, firstName, lastName, role, phone]
    );

    res.status(201).json({ success: true, message: 'Usuario creado exitosamente', data: { id, email, role } });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ success: false, message: 'El correo ya está registrado' });
    }
    res.status(500).json({ success: false, message: 'Error creando usuario' });
  }
});

// PUT /api/users/:id
router.put('/:id', async (req, res) => {
  try {
    const { firstName, lastName, phone, role, status } = req.body;
    await pool.query(
      `UPDATE users SET
        first_name = COALESCE(?, first_name),
        last_name = COALESCE(?, last_name),
        phone = COALESCE(?, phone),
        role = COALESCE(?, role),
        status = COALESCE(?, status),
        updated_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [firstName, lastName, phone, role, status, req.params.id, req.user.clinicId]
    );
    res.json({ success: true, message: 'Usuario actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando usuario' });
  }
});

// DELETE /api/users/:id (soft delete)
router.delete('/:id', async (req, res) => {
  if (req.params.id === req.user.id) {
    return res.status(400).json({ success: false, message: 'No puedes eliminar tu propia cuenta' });
  }
  try {
    await pool.query(
      'UPDATE users SET status = "inactive", deleted_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]
    );
    res.json({ success: true, message: 'Usuario eliminado' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error eliminando usuario' });
  }
});

module.exports = router;
