// src/routes/payments.js
const express = require('express');
const pool = require('../../config/database');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

// GET /api/payments - Historial de pagos de la clínica
router.get('/', async (req, res) => {
  try {
    const { dateFrom, dateTo, method, page = 1, limit = 50 } = req.query;
    const clinicId = req.user.clinicId;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where = 'WHERE i.clinic_id = ? AND p.deleted_at IS NULL';
    const params = [clinicId];
    if (dateFrom) { where += ' AND p.date >= ?'; params.push(dateFrom); }
    if (dateTo) { where += ' AND p.date <= ?'; params.push(dateTo); }
    if (method) { where += ' AND p.method = ?'; params.push(method); }

    const [payments] = await pool.query(
      `SELECT p.*, i.invoice_number, CONCAT(pat.first_name, ' ', pat.last_name) as patient_name
       FROM payments p
       JOIN invoices i ON i.id = p.invoice_id
       JOIN patients pat ON pat.id = i.patient_id
       ${where}
       ORDER BY p.date DESC, p.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    const [[{ total, totalAmount }]] = await pool.query(
      `SELECT COUNT(*) as total, SUM(p.amount) as totalAmount
       FROM payments p JOIN invoices i ON i.id = p.invoice_id ${where}`,
      params
    );

    res.json({ success: true, data: payments, summary: { total, totalAmount } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo pagos' });
  }
});

module.exports = router;
