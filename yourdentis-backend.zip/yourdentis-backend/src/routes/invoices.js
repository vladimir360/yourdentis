// src/routes/invoices.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/invoices
router.get('/', async (req, res) => {
  try {
    const { patientId, status, dateFrom, dateTo, page = 1, limit = 20 } = req.query;
    const clinicId = req.user.clinicId;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where = 'WHERE i.clinic_id = ? AND i.deleted_at IS NULL';
    const params = [clinicId];

    if (patientId) { where += ' AND i.patient_id = ?'; params.push(patientId); }
    if (status) { where += ' AND i.status = ?'; params.push(status); }
    if (dateFrom) { where += ' AND i.date >= ?'; params.push(dateFrom); }
    if (dateTo) { where += ' AND i.date <= ?'; params.push(dateTo); }

    const [invoices] = await pool.query(
      `SELECT i.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name
       FROM invoices i
       LEFT JOIN patients p ON p.id = i.patient_id
       ${where}
       ORDER BY i.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    // Cargar items de cada factura
    for (const inv of invoices) {
      const [items] = await pool.query('SELECT * FROM invoice_items WHERE invoice_id = ?', [inv.id]);
      inv.items = items;
    }

    const [[{ total }]] = await pool.query(`SELECT COUNT(*) as total FROM invoices i ${where}`, params);

    res.json({ success: true, data: invoices, pagination: { total, page: parseInt(page), limit: parseInt(limit) } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo facturas' });
  }
});

// GET /api/invoices/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT i.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name, p.phone as patient_phone,
              p.email as patient_email, p.address as patient_address
       FROM invoices i
       LEFT JOIN patients p ON p.id = i.patient_id
       WHERE i.id = ? AND i.clinic_id = ? AND i.deleted_at IS NULL`,
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Factura no encontrada' });

    const invoice = rows[0];
    const [items] = await pool.query('SELECT * FROM invoice_items WHERE invoice_id = ?', [invoice.id]);
    const [payments] = await pool.query('SELECT * FROM payments WHERE invoice_id = ? ORDER BY date ASC', [invoice.id]);

    invoice.items = items;
    invoice.payments = payments;

    res.json({ success: true, data: invoice });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo factura' });
  }
});

// POST /api/invoices
router.post('/', authorize('admin', 'dentist', 'receptionist'), [
  body('patientId').notEmpty(),
  body('items').isArray({ min: 1 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { patientId, items, taxRate = 0, discount = 0, dueDate, notes = '' } = req.body;
    const clinicId = req.user.clinicId;

    // Calcular totales
    let subtotal = 0;
    for (const item of items) {
      const itemTotal = (item.quantity * item.unitPrice) * (1 - (item.discount || 0) / 100);
      item.total = parseFloat(itemTotal.toFixed(2));
      subtotal += item.total;
    }
    const tax = parseFloat((subtotal * taxRate / 100).toFixed(2));
    const total = parseFloat((subtotal + tax - discount).toFixed(2));

    // Generar número de factura secuencial
    const [[{ count }]] = await conn.query('SELECT COUNT(*) as count FROM invoices WHERE clinic_id = ?', [clinicId]);
    const invoiceNumber = `INV-${String(count + 1).padStart(5, '0')}`;

    const id = uuidv4();
    await conn.query(
      `INSERT INTO invoices (id, clinic_id, patient_id, invoice_number, date, due_date,
        subtotal, tax_rate, tax, discount, total, paid, status, notes, created_at)
       VALUES (?,?,?,?,NOW(),?,?,?,?,?,?,0,'pending',?,NOW())`,
      [id, clinicId, patientId, invoiceNumber, dueDate || null, subtotal, taxRate, tax, discount, total, notes]
    );

    for (const item of items) {
      await conn.query(
        `INSERT INTO invoice_items (id, invoice_id, treatment_id, description, quantity, unit_price, discount, total)
         VALUES (?,?,?,?,?,?,?,?)`,
        [uuidv4(), id, item.treatmentId || null, item.description, item.quantity, item.unitPrice, item.discount || 0, item.total]
      );
    }

    await conn.commit();
    const [created] = await pool.query('SELECT * FROM invoices WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0], message: `Factura ${invoiceNumber} creada` });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creando factura' });
  } finally {
    conn.release();
  }
});

// POST /api/invoices/:id/payments
router.post('/:id/payments', authorize('admin', 'dentist', 'receptionist'), [
  body('amount').isFloat({ min: 0.01 }),
  body('method').isIn(['cash', 'card', 'transfer', 'digital', 'check']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { amount, method, reference = null, notes = '' } = req.body;
    const invoiceId = req.params.id;

    const [[invoice]] = await conn.query(
      'SELECT * FROM invoices WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [invoiceId, req.user.clinicId]
    );
    if (!invoice) return res.status(404).json({ success: false, message: 'Factura no encontrada' });

    const newPaid = parseFloat((invoice.paid + parseFloat(amount)).toFixed(2));
    let newStatus = invoice.status;
    if (newPaid >= invoice.total) newStatus = 'paid';
    else if (newPaid > 0) newStatus = 'partial';

    const payId = uuidv4();
    await conn.query(
      `INSERT INTO payments (id, invoice_id, date, amount, method, reference, notes, received_by, created_at)
       VALUES (?,?,NOW(),?,?,?,?,?,NOW())`,
      [payId, invoiceId, amount, method, reference, notes, req.user.id]
    );

    await conn.query(
      'UPDATE invoices SET paid = ?, status = ?, updated_at = NOW() WHERE id = ?',
      [newPaid, newStatus, invoiceId]
    );

    // Actualizar balance del paciente
    await conn.query(
      'UPDATE patients SET balance = balance - ? WHERE id = ?',
      [amount, invoice.patient_id]
    );

    await conn.commit();
    res.status(201).json({ success: true, message: `Pago de ${amount} registrado. Estado: ${newStatus}` });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Error registrando pago' });
  } finally {
    conn.release();
  }
});

module.exports = router;
