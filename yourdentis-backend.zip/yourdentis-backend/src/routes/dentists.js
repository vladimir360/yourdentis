// src/routes/dentists.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/dentists
router.get('/', async (req, res) => {
  try {
    const [dentists] = await pool.query(
      `SELECT d.*, CONCAT(u.first_name, ' ', u.last_name) as full_name, u.email, u.avatar_url
       FROM dentists d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.clinic_id = ? AND d.deleted_at IS NULL AND d.status = 'active'
       ORDER BY full_name`,
      [req.user.clinicId]
    );

    for (const d of dentists) {
      const [schedules] = await pool.query(
        'SELECT * FROM dentist_schedules WHERE dentist_id = ? ORDER BY day_of_week', [d.id]);
      d.schedule = schedules;
    }

    res.json({ success: true, data: dentists });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo odontólogos' });
  }
});

// GET /api/dentists/:id
router.get('/:id', async (req, res) => {
  try {
    const [[d]] = await pool.query(
      `SELECT d.*, CONCAT(u.first_name, ' ', u.last_name) as full_name, u.email, u.avatar_url
       FROM dentists d LEFT JOIN users u ON u.id = d.user_id
       WHERE d.id = ? AND d.clinic_id = ? AND d.deleted_at IS NULL`,
      [req.params.id, req.user.clinicId]
    );
    if (!d) return res.status(404).json({ success: false, message: 'Odontólogo no encontrado' });

    const [schedules] = await pool.query('SELECT * FROM dentist_schedules WHERE dentist_id = ?', [d.id]);
    d.schedule = schedules;

    res.json({ success: true, data: d });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo odontólogo' });
  }
});

// GET /api/dentists/:id/availability?date=YYYY-MM-DD
router.get('/:id/availability', async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) return res.status(400).json({ success: false, message: 'Parámetro date requerido' });

    const dayOfWeek = new Date(date).getDay();

    const [[schedule]] = await pool.query(
      'SELECT * FROM dentist_schedules WHERE dentist_id = ? AND day_of_week = ?',
      [req.params.id, dayOfWeek]
    );

    if (!schedule) {
      return res.json({ success: true, data: { available: false, message: 'No trabaja este día', slots: [] } });
    }

    const [appointments] = await pool.query(
      `SELECT start_time, end_time FROM appointments
       WHERE dentist_id = ? AND date = ? AND status NOT IN ('cancelled', 'no-show') AND deleted_at IS NULL`,
      [req.params.id, date]
    );

    const slots = generateSlots(schedule.start_time, schedule.end_time, 30);
    const available = slots.filter(slot => !appointments.some(a =>
      timeToMin(a.start_time) < timeToMin(slot) + 30 && timeToMin(a.end_time) > timeToMin(slot)
    ));

    res.json({ success: true, data: { available: true, slots: available, bookedSlots: appointments } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo disponibilidad' });
  }
});

function timeToMin(t) {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

function generateSlots(start, end, stepMin = 30) {
  const slots = [];
  let cur = timeToMin(start);
  const endMin = timeToMin(end);
  while (cur + stepMin <= endMin) {
    slots.push(`${String(Math.floor(cur / 60)).padStart(2, '0')}:${String(cur % 60).padStart(2, '0')}`);
    cur += stepMin;
  }
  return slots;
}

module.exports = router;
