// src/routes/reports.js
const express = require('express');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, authorize('admin', 'dentist'));

// GET /api/reports/dashboard-summary
router.get('/dashboard-summary', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;
    const { period = 'month' } = req.query;

    const dateFilter = period === 'week' ? 'INTERVAL 7 DAY' :
                       period === 'year' ? 'INTERVAL 1 YEAR' : 'INTERVAL 1 MONTH';

    const [[{ totalPatients }]] = await pool.query(
      'SELECT COUNT(*) as totalPatients FROM patients WHERE clinic_id = ? AND deleted_at IS NULL', [clinicId]);

    const [[{ newPatients }]] = await pool.query(
      `SELECT COUNT(*) as newPatients FROM patients WHERE clinic_id = ? AND registered_at >= DATE_SUB(NOW(), ${dateFilter}) AND deleted_at IS NULL`, [clinicId]);

    const [[{ totalAppointments, completed, cancelled }]] = await pool.query(
      `SELECT COUNT(*) as totalAppointments,
        SUM(status = 'completed') as completed,
        SUM(status = 'cancelled') as cancelled
       FROM appointments WHERE clinic_id = ? AND date >= DATE_SUB(NOW(), ${dateFilter}) AND deleted_at IS NULL`, [clinicId]);

    const [[{ revenue, collected }]] = await pool.query(
      `SELECT SUM(total) as revenue, SUM(paid) as collected
       FROM invoices WHERE clinic_id = ? AND date >= DATE_SUB(NOW(), ${dateFilter}) AND deleted_at IS NULL`, [clinicId]);

    const [[{ pendingInvoices }]] = await pool.query(
      `SELECT COUNT(*) as pendingInvoices FROM invoices WHERE clinic_id = ? AND status IN ('pending','partial') AND deleted_at IS NULL`, [clinicId]);

    const [[{ lowStockItems }]] = await pool.query(
      `SELECT COUNT(*) as lowStockItems FROM inventory_items WHERE clinic_id = ? AND current_stock <= min_stock AND deleted_at IS NULL`, [clinicId]);

    res.json({
      success: true,
      data: {
        totalPatients, newPatients, totalAppointments: totalAppointments || 0,
        completed: completed || 0, cancelled: cancelled || 0,
        revenue: revenue || 0, collected: collected || 0,
        pendingInvoices, lowStockItems,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error generando resumen' });
  }
});

// GET /api/reports/revenue
router.get('/revenue', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;
    const { groupBy = 'month', year = new Date().getFullYear() } = req.query;

    const format = groupBy === 'day' ? '%Y-%m-%d' : groupBy === 'week' ? '%Y-%u' : '%Y-%m';

    const [rows] = await pool.query(
      `SELECT DATE_FORMAT(date, ?) as period, SUM(total) as amount, SUM(paid) as collected, COUNT(*) as invoices
       FROM invoices WHERE clinic_id = ? AND YEAR(date) = ? AND deleted_at IS NULL
       GROUP BY period ORDER BY period`,
      [format, clinicId, year]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error generando reporte de ingresos' });
  }
});

// GET /api/reports/appointments-stats
router.get('/appointments-stats', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;
    const [byStatus] = await pool.query(
      `SELECT status, COUNT(*) as count FROM appointments WHERE clinic_id = ? AND deleted_at IS NULL GROUP BY status`,
      [clinicId]
    );

    const [byDentist] = await pool.query(
      `SELECT d.id, CONCAT(u.first_name, ' ', u.last_name) as dentist_name,
        COUNT(*) as total, SUM(a.status = 'completed') as completed
       FROM appointments a
       JOIN dentists d ON d.id = a.dentist_id
       JOIN users u ON u.id = d.user_id
       WHERE a.clinic_id = ? AND a.deleted_at IS NULL
       GROUP BY d.id, dentist_name`,
      [clinicId]
    );

    res.json({ success: true, data: { byStatus, byDentist } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo estadísticas de citas' });
  }
});

// GET /api/reports/treatments-stats
router.get('/treatments-stats', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT type, COUNT(*) as count, SUM(cost - discount) as revenue
       FROM treatments WHERE clinic_id = ? AND deleted_at IS NULL
       GROUP BY type ORDER BY count DESC`,
      [req.user.clinicId]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo estadísticas de tratamientos' });
  }
});

// GET /api/reports/patient-growth
router.get('/patient-growth', async (req, res) => {
  try {
    const { year = new Date().getFullYear() } = req.query;
    const [rows] = await pool.query(
      `SELECT DATE_FORMAT(registered_at, '%Y-%m') as period, COUNT(*) as newPatients
       FROM patients WHERE clinic_id = ? AND YEAR(registered_at) = ? AND deleted_at IS NULL
       GROUP BY period ORDER BY period`,
      [req.user.clinicId, year]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo crecimiento de pacientes' });
  }
});

module.exports = router;
