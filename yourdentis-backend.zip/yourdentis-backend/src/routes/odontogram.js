// src/routes/odontogram.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const VALID_CONDITIONS = ['healthy', 'cavity', 'filling', 'crown', 'extraction', 'root-canal',
  'implant', 'sealant', 'bridge', 'veneer', 'fracture', 'absent'];

// GET /api/odontogram/:patientId
// Devuelve el estado actual del odontograma del paciente (agrupado por diente)
router.get('/:patientId', async (req, res) => {
  try {
    const [entries] = await pool.query(
      `SELECT oe.*,
        CONCAT(u.first_name, ' ', u.last_name) as dentist_name
       FROM odontogram_entries oe
       LEFT JOIN dentists d ON d.id = oe.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE oe.patient_id = ? AND oe.deleted_at IS NULL
       ORDER BY oe.tooth_number, oe.date DESC`,
      [req.params.patientId]
    );

    // Agrupar por diente para obtener el estado más reciente
    const teeth = {};
    for (const entry of entries) {
      const tn = entry.tooth_number;
      if (!teeth[tn]) {
        teeth[tn] = {
          toothNumber: tn,
          condition: entry.condition,
          surfaces: {},
          notes: entry.notes,
          lastModified: entry.date,
          history: [],
        };
      }
      if (entry.surface) {
        teeth[tn].surfaces[entry.surface] = entry.condition;
      }
      teeth[tn].history.push(entry);
    }

    res.json({ success: true, data: Object.values(teeth) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo odontograma' });
  }
});

// POST /api/odontogram/:patientId
// Registrar condición en un diente
router.post('/:patientId', authorize('admin', 'dentist'), [
  body('toothNumber').isInt({ min: 1, max: 52 }),
  body('condition').isIn(VALID_CONDITIONS),
  body('dentistId').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const { toothNumber, condition, surface = null, dentistId, treatmentId = null, notes = '' } = req.body;
    const id = uuidv4();

    await pool.query(
      `INSERT INTO odontogram_entries (id, patient_id, dentist_id, tooth_number, condition, surface,
        date, treatment_id, notes, created_at)
       VALUES (?,?,?,?,?,?,NOW(),?,?,NOW())`,
      [id, req.params.patientId, dentistId, toothNumber, condition, surface, treatmentId, notes]
    );

    res.status(201).json({ success: true, message: `Diente ${toothNumber} actualizado: ${condition}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando odontograma' });
  }
});

// POST /api/odontogram/:patientId/bulk
// Actualización masiva (guardar odontograma completo)
router.post('/:patientId/bulk', authorize('admin', 'dentist'), async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { entries, dentistId } = req.body;
    if (!Array.isArray(entries) || !dentistId) {
      return res.status(400).json({ success: false, message: 'entries y dentistId son requeridos' });
    }

    for (const entry of entries) {
      await conn.query(
        `INSERT INTO odontogram_entries (id, patient_id, dentist_id, tooth_number, condition, surface, date, notes, created_at)
         VALUES (?,?,?,?,?,?,NOW(),?,NOW())`,
        [uuidv4(), req.params.patientId, dentistId, entry.toothNumber, entry.condition, entry.surface || null, entry.notes || '']
      );
    }

    await conn.commit();
    res.json({ success: true, message: `${entries.length} entradas guardadas en odontograma` });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Error guardando odontograma' });
  } finally {
    conn.release();
  }
});

// GET /api/odontogram/:patientId/history
// Historial completo de cambios en el odontograma
router.get('/:patientId/history', async (req, res) => {
  try {
    const { toothNumber } = req.query;
    let where = 'WHERE oe.patient_id = ? AND oe.deleted_at IS NULL';
    const params = [req.params.patientId];

    if (toothNumber) { where += ' AND oe.tooth_number = ?'; params.push(toothNumber); }

    const [history] = await pool.query(
      `SELECT oe.*, CONCAT(u.first_name, ' ', u.last_name) as dentist_name
       FROM odontogram_entries oe
       LEFT JOIN dentists d ON d.id = oe.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       ${where}
       ORDER BY oe.date DESC`,
      params
    );

    res.json({ success: true, data: history });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo historial' });
  }
});

module.exports = router;
