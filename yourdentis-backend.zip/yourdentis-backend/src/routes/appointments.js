// src/routes/appointments.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const VALID_STATUSES = ['scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled', 'no-show'];

// ---- GET /api/appointments ----
// Soporta filtros: date, dateFrom, dateTo, dentistId, patientId, status
router.get('/', async (req, res) => {
  try {
    const { date, dateFrom, dateTo, dentistId, patientId, status, page = 1, limit = 50 } = req.query;
    const clinicId = req.user.clinicId;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where = 'WHERE a.clinic_id = ? AND a.deleted_at IS NULL';
    const params = [clinicId];

    if (date) { where += ' AND a.date = ?'; params.push(date); }
    if (dateFrom) { where += ' AND a.date >= ?'; params.push(dateFrom); }
    if (dateTo) { where += ' AND a.date <= ?'; params.push(dateTo); }
    if (dentistId) { where += ' AND a.dentist_id = ?'; params.push(dentistId); }
    if (patientId) { where += ' AND a.patient_id = ?'; params.push(patientId); }
    if (status) { where += ' AND a.status = ?'; params.push(status); }

    const [appointments] = await pool.query(
      `SELECT a.*,
        CONCAT(p.first_name, ' ', p.last_name) as patient_name, p.phone as patient_phone,
        CONCAT(d_u.first_name, ' ', d_u.last_name) as dentist_name, d.color as dentist_color
       FROM appointments a
       LEFT JOIN patients p ON p.id = a.patient_id
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users d_u ON d_u.id = d.user_id
       ${where}
       ORDER BY a.date ASC, a.start_time ASC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    res.json({ success: true, data: appointments });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error obteniendo citas' });
  }
});

// ---- GET /api/appointments/:id ----
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT a.*,
        CONCAT(p.first_name, ' ', p.last_name) as patient_name,
        CONCAT(d_u.first_name, ' ', d_u.last_name) as dentist_name
       FROM appointments a
       LEFT JOIN patients p ON p.id = a.patient_id
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users d_u ON d_u.id = d.user_id
       WHERE a.id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL`,
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Cita no encontrada' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo cita' });
  }
});

// ---- POST /api/appointments ----
router.post('/', authorize('admin', 'dentist', 'receptionist'), [
  body('patientId').notEmpty(),
  body('dentistId').notEmpty(),
  body('date').isISO8601(),
  body('startTime').matches(/^\d{2}:\d{2}$/),
  body('endTime').matches(/^\d{2}:\d{2}$/),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const { patientId, dentistId, date, startTime, endTime, type = 'Consulta General',
            notes = '', room = '', color = '#3B82F6' } = req.body;
    const clinicId = req.user.clinicId;

    // Verificar conflictos de horario
    const [conflicts] = await pool.query(
      `SELECT id FROM appointments
       WHERE dentist_id = ? AND date = ? AND status NOT IN ('cancelled', 'no-show')
         AND deleted_at IS NULL
         AND ((start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?))`,
      [dentistId, date, endTime, startTime, endTime, startTime]
    );

    if (conflicts.length) {
      return res.status(409).json({ success: false, message: 'El odontólogo ya tiene una cita en ese horario' });
    }

    const id = uuidv4();
    const duration = calcDuration(startTime, endTime);

    await pool.query(
      `INSERT INTO appointments (id, clinic_id, patient_id, dentist_id, date, start_time, end_time,
        duration, type, status, notes, room, color, reminder_sent, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,'scheduled',?,?,?,0,NOW())`,
      [id, clinicId, patientId, dentistId, date, startTime, endTime, duration, type, notes, room, color]
    );

    const [created] = await pool.query('SELECT * FROM appointments WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0], message: 'Cita programada exitosamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creando cita' });
  }
});

// ---- PATCH /api/appointments/:id/status ----
router.patch('/:id/status', authorize('admin', 'dentist', 'receptionist'), [
  body('status').isIn(VALID_STATUSES),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const { status } = req.body;
    const confirmedAt = status === 'confirmed' ? ', confirmed_at = NOW()' : '';

    const [result] = await pool.query(
      `UPDATE appointments SET status = ?${confirmedAt}, updated_at = NOW()
       WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
      [status, req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Cita no encontrada' });

    // Actualizar last_visit del paciente si se completa
    if (status === 'completed') {
      const [[appt]] = await pool.query('SELECT patient_id, date FROM appointments WHERE id = ?', [req.params.id]);
      await pool.query('UPDATE patients SET last_visit = ? WHERE id = ?', [appt.date, appt.patient_id]);
    }

    res.json({ success: true, message: `Cita marcada como: ${status}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando estado de cita' });
  }
});

// ---- PUT /api/appointments/:id ----
router.put('/:id', authorize('admin', 'dentist', 'receptionist'), async (req, res) => {
  try {
    const { date, startTime, endTime, type, notes, room, color, status } = req.body;
    const duration = startTime && endTime ? calcDuration(startTime, endTime) : null;

    await pool.query(
      `UPDATE appointments SET
        date = COALESCE(?, date),
        start_time = COALESCE(?, start_time),
        end_time = COALESCE(?, end_time),
        duration = COALESCE(?, duration),
        type = COALESCE(?, type),
        notes = COALESCE(?, notes),
        room = COALESCE(?, room),
        color = COALESCE(?, color),
        status = COALESCE(?, status),
        updated_at = NOW()
       WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
      [date, startTime, endTime, duration, type, notes, room, color, status, req.params.id, req.user.clinicId]
    );

    const [updated] = await pool.query('SELECT * FROM appointments WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando cita' });
  }
});

// ---- DELETE /api/appointments/:id ----
router.delete('/:id', authorize('admin', 'dentist', 'receptionist'), async (req, res) => {
  try {
    const [result] = await pool.query(
      `UPDATE appointments SET status = 'cancelled', deleted_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Cita no encontrada' });
    res.json({ success: true, message: 'Cita cancelada' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error cancelando cita' });
  }
});

function calcDuration(start, end) {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  return (eh * 60 + em) - (sh * 60 + sm);
}

module.exports = router;
