// src/routes/dashboard.js
const express = require('express');
const pool = require('../../config/database');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

router.get('/stats', async (req, res) => {
  try {
    const clinicId = req.user.clinicId;
    const today = new Date().toISOString().split('T')[0];

    const [[todayAppts]] = await pool.query(
      `SELECT COUNT(*) as total,
        SUM(status = 'completed') as completed,
        SUM(status = 'scheduled') as scheduled,
        SUM(status = 'confirmed') as confirmed,
        SUM(status = 'cancelled') as cancelled
       FROM appointments WHERE clinic_id = ? AND date = ? AND deleted_at IS NULL`,
      [clinicId, today]
    );

    const [[patients]] = await pool.query(
      'SELECT COUNT(*) as total FROM patients WHERE clinic_id = ? AND status = "active" AND deleted_at IS NULL',
      [clinicId]
    );

    const [[monthRevenue]] = await pool.query(
      `SELECT SUM(total) as revenue, SUM(paid) as collected
       FROM invoices WHERE clinic_id = ? AND MONTH(date) = MONTH(NOW()) AND YEAR(date) = YEAR(NOW()) AND deleted_at IS NULL`,
      [clinicId]
    );

    const [upcomingAppts] = await pool.query(
      `SELECT a.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
        CONCAT(u.first_name, ' ', u.last_name) as dentist_name
       FROM appointments a
       LEFT JOIN patients p ON p.id = a.patient_id
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE a.clinic_id = ? AND a.date >= ? AND a.status IN ('scheduled','confirmed')
         AND a.deleted_at IS NULL
       ORDER BY a.date, a.start_time LIMIT 10`,
      [clinicId, today]
    );

    const [lowStock] = await pool.query(
      `SELECT name, current_stock, min_stock FROM inventory_items
       WHERE clinic_id = ? AND current_stock <= min_stock AND status = 'active' AND deleted_at IS NULL
       LIMIT 5`,
      [clinicId]
    );

    res.json({
      success: true,
      data: {
        today: todayAppts,
        totalActivePatients: patients.total,
        monthRevenue: monthRevenue.revenue || 0,
        monthCollected: monthRevenue.collected || 0,
        upcomingAppointments: upcomingAppts,
        lowStockAlerts: lowStock,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error obteniendo estadísticas del dashboard' });
  }
});

module.exports = router;
