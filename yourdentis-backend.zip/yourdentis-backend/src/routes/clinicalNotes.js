// src/routes/clinicalNotes.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

router.get('/', async (req, res) => {
  try {
    const { patientId, dentistId, appointmentId } = req.query;
    let where = 'WHERE cn.clinic_id = ? AND cn.deleted_at IS NULL';
    const params = [req.user.clinicId];
    if (patientId) { where += ' AND cn.patient_id = ?'; params.push(patientId); }
    if (dentistId) { where += ' AND cn.dentist_id = ?'; params.push(dentistId); }
    if (appointmentId) { where += ' AND cn.appointment_id = ?'; params.push(appointmentId); }

    const [notes] = await pool.query(
      `SELECT cn.*, CONCAT(u.first_name, ' ', u.last_name) as dentist_name,
        CONCAT(p.first_name, ' ', p.last_name) as patient_name
       FROM clinical_notes cn
       LEFT JOIN dentists d ON d.id = cn.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       LEFT JOIN patients p ON p.id = cn.patient_id
       ${where} ORDER BY cn.date DESC`,
      params
    );
    res.json({ success: true, data: notes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo notas clínicas' });
  }
});

router.post('/', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const {
      patientId, dentistId, appointmentId = null, chiefComplaint = '',
      diagnosis = '', treatmentPlan = '', evolution = '', privateNotes = '',
      vitalSigns = null,
    } = req.body;
    const id = uuidv4();

    await pool.query(
      `INSERT INTO clinical_notes (id, clinic_id, patient_id, dentist_id, appointment_id, date,
        chief_complaint, diagnosis, treatment_plan, evolution, private_notes, vital_signs, created_at)
       VALUES (?,?,?,?,?,NOW(),?,?,?,?,?,?,NOW())`,
      [id, req.user.clinicId, patientId, dentistId, appointmentId,
       chiefComplaint, diagnosis, treatmentPlan, evolution, privateNotes,
       vitalSigns ? JSON.stringify(vitalSigns) : null]
    );

    const [created] = await pool.query('SELECT * FROM clinical_notes WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error creando nota clínica' });
  }
});

router.put('/:id', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const { chiefComplaint, diagnosis, treatmentPlan, evolution, privateNotes, vitalSigns } = req.body;
    await pool.query(
      `UPDATE clinical_notes SET
        chief_complaint = COALESCE(?, chief_complaint),
        diagnosis = COALESCE(?, diagnosis),
        treatment_plan = COALESCE(?, treatment_plan),
        evolution = COALESCE(?, evolution),
        private_notes = COALESCE(?, private_notes),
        vital_signs = COALESCE(?, vital_signs),
        updated_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [chiefComplaint, diagnosis, treatmentPlan, evolution, privateNotes,
       vitalSigns ? JSON.stringify(vitalSigns) : null, req.params.id, req.user.clinicId]
    );
    const [updated] = await pool.query('SELECT * FROM clinical_notes WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando nota clínica' });
  }
});

module.exports = router;
