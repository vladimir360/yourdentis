// src/routes/patients.js
const express = require('express');
const { body, query, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ---- GET /api/patients ----
router.get('/', async (req, res) => {
  try {
    const { search, status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const clinicId = req.user.clinicId;

    let whereClause = 'WHERE p.clinic_id = ? AND p.deleted_at IS NULL';
    const params = [clinicId];

    if (status) { whereClause += ' AND p.status = ?'; params.push(status); }
    if (search) {
      whereClause += ' AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.email LIKE ? OR p.phone LIKE ? OR p.id_number LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
    }

    const [patients] = await pool.query(
      `SELECT p.*, 
        (SELECT COUNT(*) FROM appointments a WHERE a.patient_id = p.id AND a.deleted_at IS NULL) as total_appointments,
        (SELECT MAX(a.date) FROM appointments a WHERE a.patient_id = p.id) as last_appointment
       FROM patients p
       ${whereClause}
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) as total FROM patients p ${whereClause}`,
      params
    );

    res.json({
      success: true,
      data: patients,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error obteniendo pacientes' });
  }
});

// ---- GET /api/patients/:id ----
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM patients WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Paciente no encontrado' });

    // Cargar alergias y medicamentos
    const [allergies] = await pool.query('SELECT allergy FROM patient_allergies WHERE patient_id = ?', [req.params.id]);
    const [medications] = await pool.query('SELECT medication FROM patient_medications WHERE patient_id = ?', [req.params.id]);

    const patient = rows[0];
    patient.allergies = allergies.map(a => a.allergy);
    patient.medications = medications.map(m => m.medication);

    res.json({ success: true, data: patient });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo paciente' });
  }
});

// ---- POST /api/patients ----
router.post('/', authorize('admin', 'dentist', 'receptionist'), [
  body('firstName').trim().notEmpty(),
  body('lastName').trim().notEmpty(),
  body('email').optional().isEmail().normalizeEmail(),
  body('phone').notEmpty(),
  body('dateOfBirth').isISO8601(),
  body('gender').isIn(['M', 'F', 'O']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const id = uuidv4();
    const clinicId = req.user.clinicId;
    const {
      firstName, lastName, email = null, phone, dateOfBirth, gender,
      address = '', city = '', idNumber = '', insuranceProvider = null,
      insuranceNumber = null, medicalHistory = '', bloodType = '',
      emergencyContact = '', emergencyPhone = '', notes = '',
      allergies = [], medications = [],
    } = req.body;

    await conn.query(
      `INSERT INTO patients (id, clinic_id, first_name, last_name, email, phone, date_of_birth, gender,
        address, city, id_number, insurance_provider, insurance_number, medical_history,
        blood_type, emergency_contact, emergency_phone, notes, status, balance)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',0)`,
      [id, clinicId, firstName, lastName, email, phone, dateOfBirth, gender,
       address, city, idNumber, insuranceProvider, insuranceNumber, medicalHistory,
       bloodType, emergencyContact, emergencyPhone, notes]
    );

    if (allergies.length) {
      const allergyValues = allergies.map(a => [uuidv4(), id, a]);
      await conn.query('INSERT INTO patient_allergies (id, patient_id, allergy) VALUES ?', [allergyValues]);
    }

    if (medications.length) {
      const medValues = medications.map(m => [uuidv4(), id, m]);
      await conn.query('INSERT INTO patient_medications (id, patient_id, medication) VALUES ?', [medValues]);
    }

    await conn.commit();
    const [created] = await pool.query('SELECT * FROM patients WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0], message: 'Paciente registrado exitosamente' });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ success: false, message: 'Ya existe un paciente con ese correo o número de cédula' });
    }
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creando paciente' });
  } finally {
    conn.release();
  }
});

// ---- PUT /api/patients/:id ----
router.put('/:id', authorize('admin', 'dentist', 'receptionist'), async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [existing] = await conn.query(
      'SELECT id FROM patients WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!existing.length) return res.status(404).json({ success: false, message: 'Paciente no encontrado' });

    const {
      firstName, lastName, email, phone, dateOfBirth, gender,
      address, city, idNumber, insuranceProvider, insuranceNumber,
      medicalHistory, bloodType, emergencyContact, emergencyPhone, notes, status,
      allergies, medications,
    } = req.body;

    await conn.query(
      `UPDATE patients SET
        first_name = COALESCE(?, first_name),
        last_name = COALESCE(?, last_name),
        email = COALESCE(?, email),
        phone = COALESCE(?, phone),
        date_of_birth = COALESCE(?, date_of_birth),
        gender = COALESCE(?, gender),
        address = COALESCE(?, address),
        city = COALESCE(?, city),
        id_number = COALESCE(?, id_number),
        insurance_provider = COALESCE(?, insurance_provider),
        insurance_number = COALESCE(?, insurance_number),
        medical_history = COALESCE(?, medical_history),
        blood_type = COALESCE(?, blood_type),
        emergency_contact = COALESCE(?, emergency_contact),
        emergency_phone = COALESCE(?, emergency_phone),
        notes = COALESCE(?, notes),
        status = COALESCE(?, status),
        updated_at = NOW()
       WHERE id = ?`,
      [firstName, lastName, email, phone, dateOfBirth, gender, address, city, idNumber,
       insuranceProvider, insuranceNumber, medicalHistory, bloodType, emergencyContact,
       emergencyPhone, notes, status, req.params.id]
    );

    if (allergies !== undefined) {
      await conn.query('DELETE FROM patient_allergies WHERE patient_id = ?', [req.params.id]);
      if (allergies.length) {
        await conn.query('INSERT INTO patient_allergies (id, patient_id, allergy) VALUES ?',
          [allergies.map(a => [uuidv4(), req.params.id, a])]);
      }
    }

    if (medications !== undefined) {
      await conn.query('DELETE FROM patient_medications WHERE patient_id = ?', [req.params.id]);
      if (medications.length) {
        await conn.query('INSERT INTO patient_medications (id, patient_id, medication) VALUES ?',
          [medications.map(m => [uuidv4(), req.params.id, m])]);
      }
    }

    await conn.commit();
    const [updated] = await pool.query('SELECT * FROM patients WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0], message: 'Paciente actualizado' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Error actualizando paciente' });
  } finally {
    conn.release();
  }
});

// ---- DELETE /api/patients/:id (soft delete) ----
router.delete('/:id', authorize('admin'), async (req, res) => {
  try {
    const [result] = await pool.query(
      'UPDATE patients SET deleted_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Paciente no encontrado' });
    res.json({ success: true, message: 'Paciente eliminado' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error eliminando paciente' });
  }
});

// ---- GET /api/patients/:id/history ----
router.get('/:id/history', async (req, res) => {
  try {
    const patientId = req.params.id;
    const clinicId = req.user.clinicId;

    const [appointments] = await pool.query(
      `SELECT a.*, CONCAT(u.first_name, ' ', u.last_name) as dentist_name
       FROM appointments a
       LEFT JOIN dentists d ON d.id = a.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE a.patient_id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL
       ORDER BY a.date DESC LIMIT 50`,
      [patientId, clinicId]
    );

    const [treatments] = await pool.query(
      'SELECT * FROM treatments WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL ORDER BY date DESC',
      [patientId, clinicId]
    );

    const [invoices] = await pool.query(
      'SELECT * FROM invoices WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL ORDER BY date DESC',
      [patientId, clinicId]
    );

    const [notes] = await pool.query(
      'SELECT * FROM clinical_notes WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL ORDER BY date DESC',
      [patientId, clinicId]
    );

    res.json({ success: true, data: { appointments, treatments, invoices, clinicalNotes: notes } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo historial' });
  }
});

module.exports = router;
