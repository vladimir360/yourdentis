// src/routes/settings.js
const express = require('express');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate, authorize('admin'));

router.get('/', async (req, res) => {
  try {
    const [[row]] = await pool.query(
      'SELECT settings_json FROM clinic_settings WHERE clinic_id = ?', [req.user.clinicId]);
    res.json({ success: true, data: row ? JSON.parse(row.settings_json) : {} });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo configuración' });
  }
});

router.put('/', async (req, res) => {
  try {
    const json = JSON.stringify(req.body);
    await pool.query(
      `INSERT INTO clinic_settings (id, clinic_id, settings_json, updated_at)
       VALUES (UUID(), ?, ?, NOW())
       ON DUPLICATE KEY UPDATE settings_json = ?, updated_at = NOW()`,
      [req.user.clinicId, json, json]
    );
    res.json({ success: true, message: 'Configuración guardada' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error guardando configuración' });
  }
});

module.exports = router;
