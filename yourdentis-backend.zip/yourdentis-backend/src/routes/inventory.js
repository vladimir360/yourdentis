// src/routes/inventory.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/inventory
router.get('/', async (req, res) => {
  try {
    const { category, status, lowStock, page = 1, limit = 50 } = req.query;
    const clinicId = req.user.clinicId;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where = 'WHERE i.clinic_id = ? AND i.deleted_at IS NULL';
    const params = [clinicId];

    if (category) { where += ' AND i.category = ?'; params.push(category); }
    if (status) { where += ' AND i.status = ?'; params.push(status); }
    if (lowStock === 'true') { where += ' AND i.current_stock <= i.min_stock'; }

    const [items] = await pool.query(
      `SELECT i.* FROM inventory_items i ${where}
       ORDER BY i.name ASC LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    const [[{ total }]] = await pool.query(`SELECT COUNT(*) as total FROM inventory_items i ${where}`, params);

    res.json({ success: true, data: items, pagination: { total } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo inventario' });
  }
});

// GET /api/inventory/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM inventory_items WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Artículo no encontrado' });

    const [movements] = await pool.query(
      'SELECT * FROM inventory_movements WHERE item_id = ? ORDER BY date DESC LIMIT 20',
      [req.params.id]
    );
    rows[0].movements = movements;

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo artículo' });
  }
});

// POST /api/inventory
router.post('/', authorize('admin', 'receptionist'), [
  body('name').notEmpty(),
  body('currentStock').isInt({ min: 0 }),
  body('minStock').isInt({ min: 0 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const {
      name, category = 'General', sku = '', currentStock, minStock, maxStock = 9999,
      unit = 'unidad', unitCost = 0, salePrice = 0, supplier = '', supplierContact = '',
      location = '', expirationDate = null,
    } = req.body;
    const id = uuidv4();

    await pool.query(
      `INSERT INTO inventory_items (id, clinic_id, name, category, sku, current_stock, min_stock, max_stock,
        unit, unit_cost, sale_price, supplier, supplier_contact, location, expiration_date, last_restocked, status, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),'active',NOW())`,
      [id, req.user.clinicId, name, category, sku, currentStock, minStock, maxStock,
       unit, unitCost, salePrice, supplier, supplierContact, location, expirationDate]
    );

    const [created] = await pool.query('SELECT * FROM inventory_items WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error creando artículo de inventario' });
  }
});

// PUT /api/inventory/:id
router.put('/:id', authorize('admin', 'receptionist'), async (req, res) => {
  try {
    const { name, category, minStock, maxStock, unitCost, salePrice, supplier, location, status } = req.body;
    await pool.query(
      `UPDATE inventory_items SET
        name = COALESCE(?, name),
        category = COALESCE(?, category),
        min_stock = COALESCE(?, min_stock),
        max_stock = COALESCE(?, max_stock),
        unit_cost = COALESCE(?, unit_cost),
        sale_price = COALESCE(?, sale_price),
        supplier = COALESCE(?, supplier),
        location = COALESCE(?, location),
        status = COALESCE(?, status),
        updated_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [name, category, minStock, maxStock, unitCost, salePrice, supplier, location, status, req.params.id, req.user.clinicId]
    );
    const [updated] = await pool.query('SELECT * FROM inventory_items WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando artículo' });
  }
});

// POST /api/inventory/:id/movement
// Registrar entrada, salida o ajuste de stock
router.post('/:id/movement', authorize('admin', 'receptionist', 'dentist'), [
  body('type').isIn(['in', 'out', 'adjustment']),
  body('quantity').isInt({ min: 1 }),
  body('reason').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { type, quantity, reason } = req.body;
    const itemId = req.params.id;

    const [[item]] = await conn.query(
      'SELECT * FROM inventory_items WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL FOR UPDATE',
      [itemId, req.user.clinicId]
    );
    if (!item) return res.status(404).json({ success: false, message: 'Artículo no encontrado' });

    let newStock;
    if (type === 'in') newStock = item.current_stock + parseInt(quantity);
    else if (type === 'out') {
      if (item.current_stock < quantity) {
        return res.status(400).json({ success: false, message: `Stock insuficiente. Disponible: ${item.current_stock}` });
      }
      newStock = item.current_stock - parseInt(quantity);
    } else {
      newStock = parseInt(quantity); // adjustment = set absolute value
    }

    await conn.query(
      'UPDATE inventory_items SET current_stock = ?, last_restocked = IF(? = "in", NOW(), last_restocked), updated_at = NOW() WHERE id = ?',
      [newStock, type, itemId]
    );

    await conn.query(
      'INSERT INTO inventory_movements (id, item_id, type, quantity, reason, date, user_id) VALUES (?,?,?,?,?,NOW(),?)',
      [uuidv4(), itemId, type, quantity, reason, req.user.id]
    );

    await conn.commit();
    res.json({ success: true, message: `Stock actualizado: ${item.current_stock} → ${newStock}`, newStock });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Error registrando movimiento' });
  } finally {
    conn.release();
  }
});

module.exports = router;
