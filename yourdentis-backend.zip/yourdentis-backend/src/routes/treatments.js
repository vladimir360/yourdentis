// src/routes/treatments.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/treatments?patientId=&dentistId=&status=
router.get('/', async (req, res) => {
  try {
    const { patientId, dentistId, status, page = 1, limit = 50 } = req.query;
    const clinicId = req.user.clinicId;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where = 'WHERE t.clinic_id = ? AND t.deleted_at IS NULL';
    const params = [clinicId];

    if (patientId) { where += ' AND t.patient_id = ?'; params.push(patientId); }
    if (dentistId) { where += ' AND t.dentist_id = ?'; params.push(dentistId); }
    if (status) { where += ' AND t.status = ?'; params.push(status); }

    const [treatments] = await pool.query(
      `SELECT t.*,
        CONCAT(p.first_name, ' ', p.last_name) as patient_name,
        CONCAT(u.first_name, ' ', u.last_name) as dentist_name
       FROM treatments t
       LEFT JOIN patients p ON p.id = t.patient_id
       LEFT JOIN dentists d ON d.id = t.dentist_id
       LEFT JOIN users u ON u.id = d.user_id
       ${where}
       ORDER BY t.date DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    res.json({ success: true, data: treatments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo tratamientos' });
  }
});

// GET /api/treatments/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM treatments WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL',
      [req.params.id, req.user.clinicId]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Tratamiento no encontrado' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo tratamiento' });
  }
});

// POST /api/treatments
router.post('/', authorize('admin', 'dentist'), [
  body('patientId').notEmpty(),
  body('dentistId').notEmpty(),
  body('type').notEmpty(),
  body('cost').isFloat({ min: 0 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const {
      patientId, dentistId, toothNumber = null, toothSurface = null,
      type, code = '', description = '', cost, discount = 0,
      date, notes = '',
    } = req.body;
    const id = uuidv4();

    await pool.query(
      `INSERT INTO treatments (id, clinic_id, patient_id, dentist_id, tooth_number, tooth_surface,
        type, code, description, status, cost, discount, date, notes, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,'planned',?,?,?,?,NOW())`,
      [id, req.user.clinicId, patientId, dentistId, toothNumber, toothSurface,
       type, code, description, parseFloat(cost), parseFloat(discount), date || new Date().toISOString().split('T')[0], notes]
    );

    const [created] = await pool.query('SELECT * FROM treatments WHERE id = ?', [id]);
    res.status(201).json({ success: true, data: created[0], message: 'Tratamiento registrado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creando tratamiento' });
  }
});

// PUT /api/treatments/:id
router.put('/:id', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const { status, cost, discount, notes, completedDate, toothNumber, toothSurface } = req.body;

    await pool.query(
      `UPDATE treatments SET
        status = COALESCE(?, status),
        cost = COALESCE(?, cost),
        discount = COALESCE(?, discount),
        notes = COALESCE(?, notes),
        completed_date = COALESCE(?, completed_date),
        tooth_number = COALESCE(?, tooth_number),
        tooth_surface = COALESCE(?, tooth_surface),
        updated_at = NOW()
       WHERE id = ? AND clinic_id = ? AND deleted_at IS NULL`,
      [status, cost, discount, notes, completedDate, toothNumber, toothSurface, req.params.id, req.user.clinicId]
    );

    const [updated] = await pool.query('SELECT * FROM treatments WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error actualizando tratamiento' });
  }
});

// DELETE /api/treatments/:id
router.delete('/:id', authorize('admin', 'dentist'), async (req, res) => {
  try {
    const [result] = await pool.query(
      `UPDATE treatments SET status = 'cancelled', deleted_at = NOW()
       WHERE id = ? AND clinic_id = ?`,
      [req.params.id, req.user.clinicId]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Tratamiento no encontrado' });
    res.json({ success: true, message: 'Tratamiento cancelado' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error eliminando tratamiento' });
  }
});

// GET /api/treatments/catalog/search
router.get('/catalog/search', async (req, res) => {
  try {
    const { q } = req.query;
    const [items] = await pool.query(
      `SELECT * FROM treatment_catalog WHERE (name LIKE ? OR code LIKE ?) AND deleted_at IS NULL LIMIT 20`,
      [`%${q}%`, `%${q}%`]
    );
    res.json({ success: true, data: items });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error buscando en catálogo' });
  }
});

module.exports = router;
