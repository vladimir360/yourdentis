// src/routes/notifications.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('../../config/database');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

router.get('/', async (req, res) => {
  try {
    const { unreadOnly } = req.query;
    let where = 'WHERE clinic_id = ? AND (user_id IS NULL OR user_id = ?) AND deleted_at IS NULL';
    const params = [req.user.clinicId, req.user.id];
    if (unreadOnly === 'true') { where += ' AND read_at IS NULL'; }

    const [notifications] = await pool.query(
      `SELECT * FROM notifications ${where} ORDER BY created_at DESC LIMIT 50`, params);
    res.json({ success: true, data: notifications });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error obteniendo notificaciones' });
  }
});

router.patch('/:id/read', async (req, res) => {
  try {
    await pool.query('UPDATE notifications SET read_at = NOW() WHERE id = ? AND clinic_id = ?',
      [req.params.id, req.user.clinicId]);
    res.json({ success: true, message: 'Notificación marcada como leída' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error' });
  }
});

router.patch('/mark-all-read', async (req, res) => {
  try {
    await pool.query(
      'UPDATE notifications SET read_at = NOW() WHERE clinic_id = ? AND (user_id IS NULL OR user_id = ?) AND read_at IS NULL',
      [req.user.clinicId, req.user.id]);
    res.json({ success: true, message: 'Todas las notificaciones marcadas como leídas' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error' });
  }
});

module.exports = router;
