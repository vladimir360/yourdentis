// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const pool = require('../../config/database');

/**
 * Middleware de autenticación JWT.
 * Extrae el token del header Authorization, lo verifica y adjunta
 * el usuario al request.
 */
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Token de autenticación requerido' });
    }

    const token = header.slice(7);
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    // Verificar que el usuario sigue activo en la BD
    const [rows] = await pool.query(
      'SELECT id, clinic_id, role, status FROM users WHERE id = ? AND deleted_at IS NULL',
      [payload.userId]
    );

    if (!rows.length || rows[0].status !== 'active') {
      return res.status(401).json({ success: false, message: 'Usuario no autorizado o inactivo' });
    }

    req.user = {
      id: rows[0].id,
      clinicId: rows[0].clinic_id,
      role: rows[0].role,
    };

    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token expirado. Inicia sesión de nuevo.' });
    }
    return res.status(401).json({ success: false, message: 'Token inválido' });
  }
}

/**
 * Middleware de autorización por rol.
 * Uso: authorize('admin', 'dentist')
 */
function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'No autenticado' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'No tienes permiso para esta acción' });
    }
    next();
  };
}

/**
 * Middleware que asegura que el clinicId del recurso coincide
 * con el del usuario autenticado (aislamiento multi-tenant).
 */
function sameClinic(req, res, next) {
  const clinicIdParam = req.params.clinicId || req.body.clinicId;
  if (clinicIdParam && clinicIdParam !== req.user.clinicId && req.user.role !== 'superadmin') {
    return res.status(403).json({ success: false, message: 'Acceso denegado a esta clínica' });
  }
  next();
}

module.exports = { authenticate, authorize, sameClinic };
