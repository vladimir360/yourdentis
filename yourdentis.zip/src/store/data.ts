import type { Patient, Appointment, Dentist, Invoice, Treatment, InventoryItem, ClinicalNote, User, Clinic, Notification, AuditLog } from './types';

const CLINIC_ID = 'clinic_001';

export const currentClinic: Clinic = {
  id: CLINIC_ID,
  name: 'YourDentis Clínica Central',
  address: 'Av. Principal #456, Centro Médico Torre A, Piso 3',
  phone: '+1 (829) 630-3341',
  email: 'info@yourdentis.com',
  status: 'active',
  plan: 'enterprise',
  createdAt: '2024-01-01',
};

export const currentUser: User = {
  id: 'u1',
  clinicId: CLINIC_ID,
  username: 'admin',
  email: 'admin@yourdentis.com',
  role: 'admin',
  firstName: 'Administrador',
  lastName: 'Sistema',
  status: 'active',
  lastLogin: new Date().toISOString(),
  createdAt: '2024-01-01',
};

export const dentists: Dentist[] = [
  { id: 'd1', clinicId: CLINIC_ID, firstName: 'Carlos', lastName: 'Mendoza', specialty: 'Odontología General', licenseNumber: 'OD-2024-001', email: 'carlos@yourdentis.com', phone: '+1 555-0101', color: '#3B82F6', schedule: [{ dayOfWeek: 1, startTime: '08:00', endTime: '17:00', room: 'Sala 1' }], status: 'active' },
  { id: 'd2', clinicId: CLINIC_ID, firstName: 'María', lastName: 'González', specialty: 'Ortodoncia', licenseNumber: 'OD-2024-002', email: 'maria@yourdentis.com', phone: '+1 555-0102', color: '#8B5CF6', schedule: [{ dayOfWeek: 1, startTime: '09:00', endTime: '18:00', room: 'Sala 2' }], status: 'active' },
  { id: 'd3', clinicId: CLINIC_ID, firstName: 'Roberto', lastName: 'Silva', specialty: 'Endodoncia', licenseNumber: 'OD-2024-003', email: 'roberto@yourdentis.com', phone: '+1 555-0103', color: '#10B981', schedule: [{ dayOfWeek: 1, startTime: '08:00', endTime: '16:00', room: 'Sala 3' }], status: 'active' },
  { id: 'd4', clinicId: CLINIC_ID, firstName: 'Ana', lastName: 'Torres', specialty: 'Periodoncia', licenseNumber: 'OD-2024-004', email: 'ana@yourdentis.com', phone: '+1 555-0104', color: '#F59E0B', schedule: [{ dayOfWeek: 2, startTime: '09:00', endTime: '17:00', room: 'Sala 4' }], status: 'active' },
];

export const patients: Patient[] = [
  { id: 'p1', clinicId: CLINIC_ID, firstName: 'Juan', lastName: 'Pérez', email: 'juan@email.com', phone: '+1 555-1001', dateOfBirth: '1985-03-15', gender: 'M', address: 'Av. Principal 123', city: 'Ciudad Capital', idNumber: 'ID-001234', insuranceProvider: 'SegurSalud', insuranceNumber: 'SS-001234', medicalHistory: 'Hipertensión controlada', allergies: ['Penicilina'], medications: ['Losartan 50mg'], bloodType: 'O+', emergencyContact: 'María Pérez', emergencyPhone: '+1 555-1002', registeredAt: '2024-01-15', lastVisit: '2025-01-10', status: 'active', balance: 350, notes: 'Paciente puntual' },
  { id: 'p2', clinicId: CLINIC_ID, firstName: 'Ana', lastName: 'Rodríguez', email: 'ana.r@email.com', phone: '+1 555-1003', dateOfBirth: '1990-07-22', gender: 'F', address: 'Calle 45 #12-34', city: 'Ciudad Capital', idNumber: 'ID-002345', medicalHistory: 'Sin antecedentes relevantes', allergies: [], medications: [], bloodType: 'A+', emergencyContact: 'Pedro Rodríguez', emergencyPhone: '+1 555-1004', registeredAt: '2024-02-20', lastVisit: '2025-01-08', status: 'active', balance: 0, notes: '' },
  { id: 'p3', clinicId: CLINIC_ID, firstName: 'Carlos', lastName: 'Gómez', email: 'carlos.g@email.com', phone: '+1 555-1005', dateOfBirth: '1978-11-03', gender: 'M', address: 'Carrera 7 #89-10', city: 'Ciudad Norte', idNumber: 'ID-003456', insuranceProvider: 'MediPlus', insuranceNumber: 'MP-005678', medicalHistory: 'Diabetes tipo 2', allergies: ['Latex'], medications: ['Metformina 850mg'], bloodType: 'B+', emergencyContact: 'Laura Gómez', emergencyPhone: '+1 555-1006', registeredAt: '2024-03-10', lastVisit: '2024-12-15', status: 'active', balance: 1200, notes: 'Requiere profilaxis antibiótica' },
  { id: 'p4', clinicId: CLINIC_ID, firstName: 'Lucía', lastName: 'Martínez', email: 'lucia.m@email.com', phone: '+1 555-1007', dateOfBirth: '1995-01-28', gender: 'F', address: 'Calle 100 #15-20', city: 'Ciudad Capital', idNumber: 'ID-004567', medicalHistory: 'Sin antecedentes', allergies: [], medications: [], bloodType: 'AB+', emergencyContact: 'José Martínez', emergencyPhone: '+1 555-1008', registeredAt: '2024-04-05', lastVisit: '2025-01-12', status: 'active', balance: 0, notes: '' },
  { id: 'p5', clinicId: CLINIC_ID, firstName: 'Miguel', lastName: 'Herrera', email: 'miguel.h@email.com', phone: '+1 555-1009', dateOfBirth: '1982-09-14', gender: 'M', address: 'Av. Bolívar 456', city: 'Ciudad Sur', idNumber: 'ID-005678', medicalHistory: 'Asma leve', allergies: ['Aspirina'], medications: ['Salbutamol PRN'], bloodType: 'O-', emergencyContact: 'Carmen Herrera', emergencyPhone: '+1 555-1010', registeredAt: '2024-05-12', lastVisit: '2024-11-20', status: 'inactive', balance: 500, notes: 'No asiste desde noviembre' },
  { id: 'p6', clinicId: CLINIC_ID, firstName: 'Sofía', lastName: 'López', email: 'sofia.l@email.com', phone: '+1 555-1011', dateOfBirth: '2000-04-10', gender: 'F', address: 'Calle 23 #45-67', city: 'Ciudad Capital', idNumber: 'ID-006789', medicalHistory: 'Sin antecedentes', allergies: [], medications: [], bloodType: 'A-', emergencyContact: 'Rosa López', emergencyPhone: '+1 555-1012', registeredAt: '2024-06-18', lastVisit: '2025-01-14', status: 'active', balance: 150, notes: 'Tratamiento de ortodoncia en curso' },
  { id: 'p7', clinicId: CLINIC_ID, firstName: 'Diego', lastName: 'Ramírez', email: 'diego.r@email.com', phone: '+1 555-1013', dateOfBirth: '1970-12-05', gender: 'M', address: 'Carrera 15 #30-45', city: 'Ciudad Capital', idNumber: 'ID-007890', insuranceProvider: 'SegurSalud', insuranceNumber: 'SS-009012', medicalHistory: 'Cardiopatía isquémica', allergies: ['Lidocaína'], medications: ['Enalapril', 'Aspirina'], bloodType: 'B-', emergencyContact: 'Elena Ramírez', emergencyPhone: '+1 555-1014', registeredAt: '2024-07-22', lastVisit: '2025-01-05', status: 'active', balance: 800, notes: 'Precaución con anestésicos' },
  { id: 'p8', clinicId: CLINIC_ID, firstName: 'Valentina', lastName: 'Castro', email: 'vale.c@email.com', phone: '+1 555-1015', dateOfBirth: '1988-06-30', gender: 'F', address: 'Av. 68 #10-25', city: 'Ciudad Capital', idNumber: 'ID-008901', medicalHistory: 'Embarazo 2do trimestre', allergies: [], medications: ['Ácido fólico'], bloodType: 'AB-', emergencyContact: 'Andrés Castro', emergencyPhone: '+1 555-1016', registeredAt: '2024-08-30', lastVisit: '2025-01-11', status: 'active', balance: 0, notes: 'Solo procedimientos de emergencia' },
];

const today = new Date();
const formatDate = (d: Date) => d.toISOString().split('T')[0];
const addDays = (d: Date, n: number) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
const nowISO = new Date().toISOString();

export const appointments: Appointment[] = [
  { id: 'a1', clinicId: CLINIC_ID, patientId: 'p1', dentistId: 'd1', date: formatDate(today), startTime: '09:00', endTime: '09:45', duration: 45, type: 'Limpieza dental', status: 'confirmed', notes: '', room: 'Sala 1', color: '#3B82F6', reminderSent: true, createdAt: nowISO },
  { id: 'a2', clinicId: CLINIC_ID, patientId: 'p2', dentistId: 'd2', date: formatDate(today), startTime: '10:00', endTime: '11:00', duration: 60, type: 'Control ortodoncia', status: 'confirmed', notes: 'Cambio de arco', room: 'Sala 2', color: '#8B5CF6', reminderSent: true, createdAt: nowISO },
  { id: 'a3', clinicId: CLINIC_ID, patientId: 'p3', dentistId: 'd3', date: formatDate(today), startTime: '11:30', endTime: '12:30', duration: 60, type: 'Endodoncia', status: 'scheduled', notes: 'Molar inferior derecho', room: 'Sala 1', color: '#10B981', reminderSent: false, createdAt: nowISO },
  { id: 'a4', clinicId: CLINIC_ID, patientId: 'p4', dentistId: 'd1', date: formatDate(today), startTime: '14:00', endTime: '14:30', duration: 30, type: 'Revisión general', status: 'scheduled', notes: '', room: 'Sala 1', color: '#3B82F6', reminderSent: true, createdAt: nowISO },
  { id: 'a5', clinicId: CLINIC_ID, patientId: 'p6', dentistId: 'd2', date: formatDate(today), startTime: '15:00', endTime: '16:00', duration: 60, type: 'Ajuste brackets', status: 'scheduled', notes: '', room: 'Sala 2', color: '#8B5CF6', reminderSent: true, createdAt: nowISO },
  { id: 'a6', clinicId: CLINIC_ID, patientId: 'p7', dentistId: 'd4', date: formatDate(addDays(today, 1)), startTime: '09:00', endTime: '10:00', duration: 60, type: 'Periodoncia', status: 'scheduled', notes: 'Raspado y alisado', room: 'Sala 3', color: '#F59E0B', reminderSent: false, createdAt: nowISO },
  { id: 'a7', clinicId: CLINIC_ID, patientId: 'p1', dentistId: 'd1', date: formatDate(addDays(today, 2)), startTime: '10:00', endTime: '11:00', duration: 60, type: 'Restauración', status: 'scheduled', notes: '', room: 'Sala 1', color: '#3B82F6', reminderSent: false, createdAt: nowISO },
  { id: 'a8', clinicId: CLINIC_ID, patientId: 'p8', dentistId: 'd1', date: formatDate(addDays(today, 3)), startTime: '09:30', endTime: '10:00', duration: 30, type: 'Emergencia dental', status: 'confirmed', notes: 'Dolor agudo', room: 'Sala 1', color: '#EF4444', reminderSent: true, createdAt: nowISO },
  { id: 'a9', clinicId: CLINIC_ID, patientId: 'p5', dentistId: 'd3', date: formatDate(addDays(today, -2)), startTime: '11:00', endTime: '12:00', duration: 60, type: 'Endodoncia', status: 'completed', notes: '', room: 'Sala 1', color: '#10B981', reminderSent: true, createdAt: nowISO },
  { id: 'a10', clinicId: CLINIC_ID, patientId: 'p2', dentistId: 'd1', date: formatDate(addDays(today, -5)), startTime: '09:00', endTime: '09:30', duration: 30, type: 'Limpieza dental', status: 'completed', notes: '', room: 'Sala 1', color: '#3B82F6', reminderSent: true, createdAt: nowISO },
  { id: 'a11', clinicId: CLINIC_ID, patientId: 'p3', dentistId: 'd1', date: formatDate(addDays(today, -7)), startTime: '14:00', endTime: '15:00', duration: 60, type: 'Extracción', status: 'completed', notes: '', room: 'Sala 1', color: '#3B82F6', reminderSent: true, createdAt: nowISO },
  { id: 'a12', clinicId: CLINIC_ID, patientId: 'p4', dentistId: 'd2', date: formatDate(addDays(today, -3)), startTime: '10:00', endTime: '10:30', duration: 30, type: 'Consulta', status: 'no-show', notes: '', room: 'Sala 2', color: '#8B5CF6', reminderSent: true, createdAt: nowISO },
];

export const treatments: Treatment[] = [
  { id: 't1', clinicId: CLINIC_ID, patientId: 'p1', dentistId: 'd1', toothNumber: 16, type: 'Restauración', code: 'D2391', description: 'Restauración con resina compuesta', status: 'completed', cost: 150, discount: 0, date: '2025-01-10', completedDate: '2025-01-10', notes: '', createdAt: nowISO },
  { id: 't2', clinicId: CLINIC_ID, patientId: 'p1', dentistId: 'd1', toothNumber: 26, type: 'Limpieza', code: 'D1110', description: 'Profilaxis dental completa', status: 'completed', cost: 80, discount: 0, date: '2025-01-10', completedDate: '2025-01-10', notes: '', createdAt: nowISO },
  { id: 't3', clinicId: CLINIC_ID, patientId: 'p2', dentistId: 'd2', type: 'Ortodoncia', code: 'D8080', description: 'Brackets metálicos - ajuste mensual', status: 'in-progress', cost: 2500, discount: 0, date: '2024-06-15', notes: 'Tratamiento de 18 meses', createdAt: nowISO },
  { id: 't4', clinicId: CLINIC_ID, patientId: 'p3', dentistId: 'd3', toothNumber: 46, type: 'Endodoncia', code: 'D3330', description: 'Tratamiento de conducto molar inferior', status: 'in-progress', cost: 450, discount: 0, date: '2025-01-08', notes: 'Segunda sesión pendiente', createdAt: nowISO },
  { id: 't5', clinicId: CLINIC_ID, patientId: 'p3', dentistId: 'd1', toothNumber: 36, type: 'Extracción', code: 'D7140', description: 'Extracción simple tercer molar', status: 'completed', cost: 120, discount: 0, date: '2024-12-15', completedDate: '2024-12-15', notes: '', createdAt: nowISO },
  { id: 't6', clinicId: CLINIC_ID, patientId: 'p6', dentistId: 'd2', type: 'Ortodoncia', code: 'D8090', description: 'Brackets estéticos cerámicos', status: 'in-progress', cost: 3500, discount: 0, date: '2024-09-01', notes: 'Tratamiento de 24 meses', createdAt: nowISO },
  { id: 't7', clinicId: CLINIC_ID, patientId: 'p7', dentistId: 'd4', toothNumber: 11, type: 'Corona', code: 'D2740', description: 'Corona de porcelana diente anterior', status: 'planned', cost: 600, discount: 0, date: '2025-01-15', notes: '', createdAt: nowISO },
  { id: 't8', clinicId: CLINIC_ID, patientId: 'p5', dentistId: 'd3', toothNumber: 37, type: 'Endodoncia', code: 'D3320', description: 'Tratamiento de conducto premolar', status: 'completed', cost: 400, discount: 0, date: '2024-11-20', completedDate: '2024-11-20', notes: '', createdAt: nowISO },
];

export const invoices: Invoice[] = [
  {
    id: 'inv1', clinicId: CLINIC_ID, patientId: 'p1', invoiceNumber: 'YD-2025-001', date: '2025-01-10', dueDate: '2025-02-10',
    items: [
      { id: 'ii1', treatmentId: 't1', description: 'Restauración con resina', quantity: 1, unitPrice: 150, discount: 0, total: 150 },
      { id: 'ii2', treatmentId: 't2', description: 'Profilaxis dental', quantity: 1, unitPrice: 80, discount: 0, total: 80 }
    ],
    subtotal: 230, taxRate: 0, tax: 0, discount: 0, total: 230, paid: 0, status: 'pending', payments: [], notes: '', createdAt: nowISO
  },
  {
    id: 'inv2', clinicId: CLINIC_ID, patientId: 'p3', invoiceNumber: 'YD-2024-045', date: '2024-12-15', dueDate: '2025-01-15',
    items: [
      { id: 'ii3', treatmentId: 't5', description: 'Extracción tercer molar', quantity: 1, unitPrice: 120, discount: 0, total: 120 },
      { id: 'ii4', treatmentId: 't4', description: 'Endodoncia (anticipo)', quantity: 1, unitPrice: 225, discount: 0, total: 225 }
    ],
    subtotal: 345, taxRate: 0, tax: 0, discount: 0, total: 345, paid: 145, status: 'partial',
    payments: [{ id: 'pay1', invoiceId: 'inv2', date: '2024-12-15', amount: 145, method: 'card', reference: 'TXN-001', receivedBy: 'u1', createdAt: nowISO }],
    notes: '', createdAt: nowISO
  },
  {
    id: 'inv3', clinicId: CLINIC_ID, patientId: 'p2', invoiceNumber: 'YD-2024-020', date: '2024-06-15', dueDate: '2025-06-15',
    items: [{ id: 'ii5', treatmentId: 't3', description: 'Tratamiento ortodoncia completo', quantity: 1, unitPrice: 2500, discount: 0, total: 2500 }],
    subtotal: 2500, taxRate: 0, tax: 0, discount: 0, total: 2500, paid: 2500, status: 'paid',
    payments: [
      { id: 'pay2', invoiceId: 'inv3', date: '2024-06-15', amount: 500, method: 'card', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay3', invoiceId: 'inv3', date: '2024-07-15', amount: 500, method: 'transfer', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay4', invoiceId: 'inv3', date: '2024-08-15', amount: 500, method: 'card', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay5', invoiceId: 'inv3', date: '2024-09-15', amount: 500, method: 'transfer', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay6', invoiceId: 'inv3', date: '2024-10-15', amount: 500, method: 'cash', receivedBy: 'u1', createdAt: nowISO },
    ],
    installmentPlan: { id: 'ip1', totalInstallments: 5, installmentAmount: 500, interestRate: 0, startDate: '2024-06-15', installments: [
      { number: 1, dueDate: '2024-06-15', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-06-15', paidAmount: 500 },
      { number: 2, dueDate: '2024-07-15', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-07-15', paidAmount: 500 },
      { number: 3, dueDate: '2024-08-15', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-08-15', paidAmount: 500 },
      { number: 4, dueDate: '2024-09-15', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-09-15', paidAmount: 500 },
      { number: 5, dueDate: '2024-10-15', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-10-15', paidAmount: 500 },
    ] },
    notes: '', createdAt: nowISO
  },
  {
    id: 'inv4', clinicId: CLINIC_ID, patientId: 'p6', invoiceNumber: 'YD-2024-032', date: '2024-09-01', dueDate: '2026-09-01',
    items: [{ id: 'ii6', treatmentId: 't6', description: 'Ortodoncia estética completa', quantity: 1, unitPrice: 3500, discount: 0, total: 3500 }],
    subtotal: 3500, taxRate: 0, tax: 0, discount: 0, total: 3500, paid: 1500, status: 'partial',
    payments: [
      { id: 'pay7', invoiceId: 'inv4', date: '2024-09-01', amount: 500, method: 'card', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay8', invoiceId: 'inv4', date: '2024-10-01', amount: 500, method: 'transfer', receivedBy: 'u1', createdAt: nowISO },
      { id: 'pay9', invoiceId: 'inv4', date: '2024-11-01', amount: 500, method: 'card', receivedBy: 'u1', createdAt: nowISO },
    ],
    installmentPlan: { id: 'ip2', totalInstallments: 7, installmentAmount: 500, interestRate: 0, startDate: '2024-09-01', installments: [
      { number: 1, dueDate: '2024-09-01', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-09-01', paidAmount: 500 },
      { number: 2, dueDate: '2024-10-01', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-10-01', paidAmount: 500 },
      { number: 3, dueDate: '2024-11-01', amount: 500, interest: 0, totalAmount: 500, status: 'paid', paidDate: '2024-11-01', paidAmount: 500 },
      { number: 4, dueDate: '2024-12-01', amount: 500, interest: 0, totalAmount: 500, status: 'overdue' },
      { number: 5, dueDate: '2025-01-01', amount: 500, interest: 0, totalAmount: 500, status: 'overdue' },
      { number: 6, dueDate: '2025-02-01', amount: 500, interest: 0, totalAmount: 500, status: 'pending' },
      { number: 7, dueDate: '2025-03-01', amount: 500, interest: 0, totalAmount: 500, status: 'pending' },
    ] },
    notes: '', createdAt: nowISO
  },
  {
    id: 'inv5', clinicId: CLINIC_ID, patientId: 'p7', invoiceNumber: 'YD-2025-002', date: '2025-01-05', dueDate: '2025-02-05',
    items: [
      { id: 'ii7', description: 'Consulta periodoncia', quantity: 1, unitPrice: 60, discount: 0, total: 60 },
      { id: 'ii8', description: 'Raspado y alisado', quantity: 1, unitPrice: 200, discount: 0, total: 200 }
    ],
    subtotal: 260, taxRate: 0, tax: 0, discount: 0, total: 260, paid: 0, status: 'pending', payments: [], notes: '', createdAt: nowISO
  },
];

export const inventory: InventoryItem[] = [
  { id: 'i1', clinicId: CLINIC_ID, name: 'Resina compuesta A2', category: 'Materiales de restauración', sku: 'MAT-001', currentStock: 15, minStock: 5, maxStock: 50, unit: 'jeringa', unitCost: 45, salePrice: 0, supplier: 'DentalMax', supplierContact: '+1 555-9001', location: 'Almacén A', lastRestocked: '2025-01-05', status: 'active', createdAt: nowISO },
  { id: 'i2', clinicId: CLINIC_ID, name: 'Anestesia Lidocaína 2%', category: 'Anestésicos', sku: 'ANE-001', currentStock: 50, minStock: 20, maxStock: 200, unit: 'carpule', unitCost: 3, salePrice: 0, supplier: 'PharmaDent', supplierContact: '+1 555-9002', location: 'Almacén B', lastRestocked: '2025-01-10', status: 'active', createdAt: nowISO },
  { id: 'i3', clinicId: CLINIC_ID, name: 'Guantes de nitrilo M', category: 'Desechables', sku: 'DES-001', currentStock: 200, minStock: 100, maxStock: 1000, unit: 'unidad', unitCost: 0.15, salePrice: 0, supplier: 'MediSupply', supplierContact: '+1 555-9003', location: 'Almacén A', lastRestocked: '2025-01-08', status: 'active', createdAt: nowISO },
  { id: 'i4', clinicId: CLINIC_ID, name: 'Brackets metálicos', category: 'Ortodoncia', sku: 'ORT-001', currentStock: 8, minStock: 10, maxStock: 50, unit: 'kit', unitCost: 120, salePrice: 0, supplier: 'OrthoWorld', supplierContact: '+1 555-9004', location: 'Almacén C', lastRestocked: '2024-12-20', status: 'active', createdAt: nowISO },
  { id: 'i5', clinicId: CLINIC_ID, name: 'Cemento de ionómero', category: 'Materiales de restauración', sku: 'MAT-002', currentStock: 3, minStock: 5, maxStock: 30, unit: 'frasco', unitCost: 35, salePrice: 0, supplier: 'DentalMax', supplierContact: '+1 555-9001', location: 'Almacén A', lastRestocked: '2024-12-15', status: 'active', createdAt: nowISO },
  { id: 'i6', clinicId: CLINIC_ID, name: 'Fresas diamante redondas', category: 'Instrumental', sku: 'INS-001', currentStock: 25, minStock: 10, maxStock: 100, unit: 'unidad', unitCost: 8, salePrice: 0, supplier: 'DentalTools', supplierContact: '+1 555-9005', location: 'Almacén B', lastRestocked: '2025-01-02', status: 'active', createdAt: nowISO },
  { id: 'i7', clinicId: CLINIC_ID, name: 'Hilo de sutura 3-0', category: 'Cirugía', sku: 'CIR-001', currentStock: 30, minStock: 15, maxStock: 100, unit: 'sobre', unitCost: 5, salePrice: 0, supplier: 'PharmaDent', supplierContact: '+1 555-9002', location: 'Almacén A', lastRestocked: '2025-01-03', status: 'active', createdAt: nowISO },
  { id: 'i8', clinicId: CLINIC_ID, name: 'Alginato para impresiones', category: 'Materiales de impresión', sku: 'IMP-001', currentStock: 4, minStock: 3, maxStock: 20, unit: 'bolsa 500g', unitCost: 22, salePrice: 0, supplier: 'DentalMax', supplierContact: '+1 555-9001', location: 'Almacén A', lastRestocked: '2024-12-28', status: 'active', createdAt: nowISO },
  { id: 'i9', clinicId: CLINIC_ID, name: 'Hipoclorito de sodio 5.25%', category: 'Endodoncia', sku: 'END-001', currentStock: 12, minStock: 5, maxStock: 40, unit: 'frasco 500ml', unitCost: 8, salePrice: 0, supplier: 'PharmaDent', supplierContact: '+1 555-9002', location: 'Almacén B', lastRestocked: '2025-01-06', status: 'active', createdAt: nowISO },
  { id: 'i10', clinicId: CLINIC_ID, name: 'Mascarillas N95', category: 'Desechables', sku: 'DES-002', currentStock: 45, minStock: 50, maxStock: 500, unit: 'unidad', unitCost: 2, salePrice: 0, supplier: 'MediSupply', supplierContact: '+1 555-9003', location: 'Almacén A', lastRestocked: '2024-12-22', status: 'active', createdAt: nowISO },
];

export const clinicalNotes: ClinicalNote[] = [
  { id: 'cn1', clinicId: CLINIC_ID, patientId: 'p1', dentistId: 'd1', date: '2025-01-10', chiefComplaint: 'Dolor al masticar', diagnosis: 'Caries oclusal en pieza 16', treatmentPlan: 'Restauración con resina compuesta + profilaxis dental', evolution: 'Tratamiento completado sin complicaciones', privateNotes: 'Paciente colaborador', attachments: [], createdAt: nowISO },
  { id: 'cn2', clinicId: CLINIC_ID, patientId: 'p3', dentistId: 'd3', date: '2025-01-08', chiefComplaint: 'Dolor espontáneo nocturno', diagnosis: 'Pulpitis irreversible pieza 46', treatmentPlan: 'Endodoncia en 2 sesiones', evolution: 'Primera sesión: apertura cameral y conductometría', privateNotes: 'Conductos calcificados, usar lima más fina', attachments: [], createdAt: nowISO },
  { id: 'cn3', clinicId: CLINIC_ID, patientId: 'p6', dentistId: 'd2', date: '2025-01-14', chiefComplaint: 'Control mensual ortodoncia', diagnosis: 'Maloclusión clase II', treatmentPlan: 'Ortodoncia correctiva 24 meses', evolution: 'Mes 4: buena evolución, alineación progresiva', privateNotes: '', attachments: [], createdAt: nowISO },
];

export const notifications: Notification[] = [
  { id: 'n1', clinicId: CLINIC_ID, type: 'low_stock', title: 'Stock bajo: Brackets metálicos', message: 'El stock de brackets metálicos está por debajo del mínimo (8/10)', read: false, priority: 'high', createdAt: nowISO },
  { id: 'n2', clinicId: CLINIC_ID, type: 'payment_due', title: 'Pago vencido: Sofía López', message: 'La cuota #4 del plan de pagos está vencida', read: false, priority: 'high', createdAt: nowISO },
  { id: 'n3', clinicId: CLINIC_ID, type: 'appointment_reminder', title: 'Citas de hoy', message: 'Hay 5 citas programadas para hoy', read: false, priority: 'medium', createdAt: nowISO },
  { id: 'n4', clinicId: CLINIC_ID, type: 'system', title: 'Backup completado', message: 'Backup automático realizado exitosamente', read: true, priority: 'low', createdAt: nowISO },
  { id: 'n5', clinicId: CLINIC_ID, type: 'low_stock', title: 'Stock bajo: Mascarillas N95', message: 'El stock de mascarillas N95 está por debajo del mínimo (45/50)', read: false, priority: 'medium', createdAt: nowISO },
];

export const auditLogs: AuditLog[] = [
  { id: 'al1', clinicId: CLINIC_ID, userId: 'u1', action: 'LOGIN', entity: 'user', entityId: 'u1', details: 'Inicio de sesión exitoso', ipAddress: '192.168.1.100', timestamp: nowISO },
  { id: 'al2', clinicId: CLINIC_ID, userId: 'u1', action: 'CREATE', entity: 'appointment', entityId: 'a1', details: 'Cita creada para Juan Pérez', ipAddress: '192.168.1.100', timestamp: nowISO },
  { id: 'al3', clinicId: CLINIC_ID, userId: 'u1', action: 'UPDATE', entity: 'invoice', entityId: 'inv2', details: 'Pago registrado $145', ipAddress: '192.168.1.100', timestamp: nowISO },
];
