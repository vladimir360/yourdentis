import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Patient, Appointment, Treatment, Invoice, InventoryItem, ClinicalNote, Dentist, Notification, AppPage, AppSettings } from './types';
import { patients as initPatients, appointments as initAppointments, treatments as initTreatments, invoices as initInvoices, inventory as initInventory, clinicalNotes as initNotes, dentists as initDentists, notifications as initNotifications } from './data';

const defaultSettings: AppSettings = {
  odontogramView: 'realistic',
  theme: 'light',
  language: 'es',
  sidebarCompact: false,
  animationsEnabled: true,
  highContrast: false,
  dateFormat: 'DD/MM/YYYY',
  timeFormat: '12h',
  currency: 'DOP',
  currencySymbol: 'RD$',
  timezone: 'America/Santo_Domingo',
  defaultAppointmentDuration: 30,
  showToothNumbers: true,
  toothNumberingSystem: 'FDI',
  autoSaveOdontogram: true,
  clinicalNotesTemplate: true,
  emailReminders: true,
  smsReminders: true,
  reminderHoursBefore: 24,
  lowStockAlerts: true,
  paymentAlerts: true,
  inactivePatientAlerts: false,
  inactivePatientDays: 60,
  postTreatmentSurvey: false,
  marketingCampaigns: false,
  twoFactorAuth: true,
  autoLogoutMinutes: 30,
  passwordExpireDays: 90,
  sessionRecording: false,
  auditLog: true,
  autoBackup: true,
  backupFrequency: 'daily',
  backupRetentionDays: 30,
  printLogo: true,
  printClinicInfo: true,
  invoiceFooterText: 'Gracias por confiar en YourDentis. ¡Su sonrisa es nuestra prioridad!',
  prescriptionFooterText: 'Este documento es válido como prescripción médica.',
};

interface AppState {
  patients: Patient[];
  appointments: Appointment[];
  treatments: Treatment[];
  invoices: Invoice[];
  inventory: InventoryItem[];
  clinicalNotes: ClinicalNote[];
  dentists: Dentist[];
  notifications: Notification[];
  settings: AppSettings;
  currentPage: AppPage;
  selectedPatientId: string | null;
  setCurrentPage: (page: AppPage) => void;
  setSelectedPatientId: (id: string | null) => void;
  updateAppointmentStatus: (id: string, status: Appointment['status']) => void;
  addAppointment: (apt: Appointment) => void;
  getPatientName: (id: string) => string;
  getDentistName: (id: string) => string;
  getDentist: (id: string) => Dentist | undefined;
  getPatient: (id: string) => Patient | undefined;
  markNotificationRead: (id: string) => void;
  navigateToPatient: (id: string) => void;
  updateSettings: (partial: Partial<AppSettings>) => void;
}

const AppContext = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [patients] = useState<Patient[]>(initPatients);
  const [appointments, setAppointments] = useState<Appointment[]>(initAppointments);
  const [treatments] = useState<Treatment[]>(initTreatments);
  const [invoicesState] = useState<Invoice[]>(initInvoices);
  const [inventoryState] = useState<InventoryItem[]>(initInventory);
  const [notesState] = useState<ClinicalNote[]>(initNotes);
  const [dentistsState] = useState<Dentist[]>(initDentists);
  const [notificationsState, setNotifications] = useState<Notification[]>(initNotifications);
  const [currentPage, setCurrentPage] = useState<AppPage>('dashboard');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  const updateSettings = useCallback((partial: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  }, []);

  const updateAppointmentStatus = useCallback((id: string, status: Appointment['status']) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  }, []);

  const addAppointment = useCallback((apt: Appointment) => {
    setAppointments(prev => [...prev, apt]);
  }, []);

  const getPatientName = useCallback((id: string) => {
    const p = patients.find(pt => pt.id === id);
    return p ? `${p.firstName} ${p.lastName}` : 'Desconocido';
  }, [patients]);

  const getDentistName = useCallback((id: string) => {
    const d = dentistsState.find(dt => dt.id === id);
    return d ? `Dr. ${d.firstName} ${d.lastName}` : 'Desconocido';
  }, [dentistsState]);

  const getDentist = useCallback((id: string) => {
    return dentistsState.find(d => d.id === id);
  }, [dentistsState]);

  const getPatient = useCallback((id: string) => {
    return patients.find(p => p.id === id);
  }, [patients]);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true, readAt: new Date().toISOString() } : n));
  }, []);

  const navigateToPatient = useCallback((id: string) => {
    setSelectedPatientId(id);
    setCurrentPage('patient-detail');
  }, []);

  return (
    <AppContext.Provider value={{
      patients, appointments, treatments, invoices: invoicesState, inventory: inventoryState,
      clinicalNotes: notesState, dentists: dentistsState, notifications: notificationsState,
      settings, currentPage, selectedPatientId,
      setCurrentPage, setSelectedPatientId, updateAppointmentStatus, addAppointment,
      getPatientName, getDentistName, getDentist, getPatient, markNotificationRead, navigateToPatient,
      updateSettings,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppState() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppState must be used within AppProvider');
  return ctx;
}
