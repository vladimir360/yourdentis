// ============================================================
// YourDentis - Complete Type System for Multi-Clinic SaaS
// ============================================================

// ---- CLINIC / SaaS ----
export interface Clinic {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  logo?: string;
  status: 'active' | 'suspended' | 'trial';
  plan: 'basic' | 'professional' | 'enterprise';
  createdAt: string;
}

// ---- USERS & AUTH ----
export type UserRole = 'admin' | 'dentist' | 'receptionist' | 'patient';

export interface User {
  id: string;
  clinicId: string;
  username: string;
  email: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  avatar?: string;
  status: 'active' | 'inactive' | 'blocked';
  lastLogin?: string;
  createdAt: string;
}

// ---- PATIENTS ----
export interface Patient {
  id: string;
  clinicId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: 'M' | 'F' | 'O';
  address: string;
  city: string;
  idNumber: string;
  insuranceProvider?: string;
  insuranceNumber?: string;
  medicalHistory: string;
  allergies: string[];
  medications: string[];
  bloodType: string;
  emergencyContact: string;
  emergencyPhone: string;
  registeredAt: string;
  lastVisit?: string;
  status: 'active' | 'inactive';
  balance: number;
  notes: string;
  photo?: string;
}

// ---- DENTISTS ----
export interface Dentist {
  id: string;
  clinicId: string;
  firstName: string;
  lastName: string;
  specialty: string;
  licenseNumber: string;
  email: string;
  phone: string;
  color: string;
  avatar?: string;
  schedule: DentistSchedule[];
  status: 'active' | 'inactive';
}

export interface DentistSchedule {
  dayOfWeek: number; // 0=Sunday ... 6=Saturday
  startTime: string;
  endTime: string;
  room: string;
}

// ---- APPOINTMENTS ----
export type AppointmentStatus = 'scheduled' | 'confirmed' | 'in-progress' | 'completed' | 'cancelled' | 'no-show';

export interface Appointment {
  id: string;
  clinicId: string;
  patientId: string;
  dentistId: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: number; // minutes
  type: string;
  status: AppointmentStatus;
  notes: string;
  room: string;
  color: string;
  reminderSent: boolean;
  confirmedAt?: string;
  createdAt: string;
}

// ---- TREATMENTS ----
export type TreatmentStatus = 'planned' | 'in-progress' | 'completed' | 'cancelled';

export interface Treatment {
  id: string;
  clinicId: string;
  patientId: string;
  dentistId: string;
  toothNumber?: number;
  toothSurface?: string;
  type: string;
  code: string; // CDT code
  description: string;
  status: TreatmentStatus;
  cost: number;
  discount: number;
  date: string;
  completedDate?: string;
  notes: string;
  createdAt: string;
}

// ---- ODONTOGRAM ----
export type ToothCondition = 'healthy' | 'cavity' | 'filling' | 'crown' | 'extraction' | 'root-canal' | 'implant' | 'sealant' | 'bridge' | 'veneer' | 'fracture' | 'absent';

export interface ToothRecord {
  toothNumber: number;
  status: ToothCondition;
  surfaces: {
    occlusal: ToothCondition;
    mesial: ToothCondition;
    distal: ToothCondition;
    buccal: ToothCondition;
    lingual: ToothCondition;
  };
  notes: string;
  lastModified: string;
}

export interface OdontogramEntry {
  id: string;
  patientId: string;
  dentistId: string;
  toothNumber: number;
  condition: ToothCondition;
  surface?: string;
  date: string;
  treatmentId?: string;
  notes: string;
}

// ---- INVOICES ----
export type InvoiceStatus = 'pending' | 'partial' | 'paid' | 'overdue' | 'cancelled';

export interface Invoice {
  id: string;
  clinicId: string;
  patientId: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  tax: number;
  discount: number;
  total: number;
  paid: number;
  status: InvoiceStatus;
  payments: Payment[];
  installmentPlan?: InstallmentPlan;
  notes: string;
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  treatmentId?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
}

export interface Payment {
  id: string;
  invoiceId: string;
  date: string;
  amount: number;
  method: 'cash' | 'card' | 'transfer' | 'digital' | 'check';
  reference?: string;
  notes?: string;
  receivedBy: string;
  createdAt: string;
}

export interface InstallmentPlan {
  id: string;
  totalInstallments: number;
  installmentAmount: number;
  interestRate: number;
  startDate: string;
  installments: Installment[];
}

export interface Installment {
  number: number;
  dueDate: string;
  amount: number;
  interest: number;
  totalAmount: number;
  status: 'pending' | 'paid' | 'overdue';
  paidDate?: string;
  paidAmount?: number;
}

// ---- CLINICAL NOTES ----
export interface ClinicalNote {
  id: string;
  clinicId: string;
  patientId: string;
  dentistId: string;
  appointmentId?: string;
  date: string;
  chiefComplaint: string;
  diagnosis: string;
  treatmentPlan: string;
  evolution: string;
  privateNotes: string;
  vitalSigns?: {
    bloodPressure?: string;
    heartRate?: number;
    temperature?: number;
  };
  attachments: Attachment[];
  createdAt: string;
}

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'document' | 'xray' | 'photo';
  url: string;
  uploadedAt: string;
}

// ---- INVENTORY ----
export interface InventoryItem {
  id: string;
  clinicId: string;
  name: string;
  category: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  unitCost: number;
  salePrice: number;
  supplier: string;
  supplierContact: string;
  location: string;
  expirationDate?: string;
  lastRestocked: string;
  status: 'active' | 'discontinued';
  createdAt: string;
}

export interface InventoryMovement {
  id: string;
  itemId: string;
  type: 'in' | 'out' | 'adjustment';
  quantity: number;
  reason: string;
  date: string;
  userId: string;
}

// ---- AUDIT & NOTIFICATIONS ----
export interface AuditLog {
  id: string;
  clinicId: string;
  userId: string;
  action: string;
  entity: string;
  entityId: string;
  details: string;
  ipAddress: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  clinicId: string;
  userId?: string;
  type: 'appointment_reminder' | 'payment_due' | 'low_stock' | 'system' | 'marketing';
  title: string;
  message: string;
  read: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  createdAt: string;
  readAt?: string;
}

// ---- REPORTS ----
export interface ReportData {
  revenue: { period: string; amount: number; collected: number }[];
  appointmentStats: { status: string; count: number }[];
  treatmentStats: { type: string; count: number; revenue: number }[];
  dentistPerformance: { dentistId: string; name: string; appointments: number; completed: number; revenue: number }[];
  patientGrowth: { period: string; newPatients: number; totalActive: number }[];
}

// ---- APP SETTINGS ----
export type OdontogramView = 'realistic' | 'classic';
export type ThemeMode = 'light' | 'dark' | 'auto';
export type Language = 'es' | 'en' | 'pt';
export type DateFormat = 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
export type TimeFormat = '12h' | '24h';
export type Currency = 'DOP' | 'USD' | 'EUR';

export interface AppSettings {
  // Display
  odontogramView: OdontogramView;
  theme: ThemeMode;
  language: Language;
  sidebarCompact: boolean;
  animationsEnabled: boolean;
  highContrast: boolean;

  // Regional
  dateFormat: DateFormat;
  timeFormat: TimeFormat;
  currency: Currency;
  currencySymbol: string;
  timezone: string;

  // Clinical
  defaultAppointmentDuration: number; // minutes
  showToothNumbers: boolean;
  toothNumberingSystem: 'FDI' | 'Universal' | 'Palmer';
  autoSaveOdontogram: boolean;
  clinicalNotesTemplate: boolean;

  // Notifications
  emailReminders: boolean;
  smsReminders: boolean;
  reminderHoursBefore: number;
  lowStockAlerts: boolean;
  paymentAlerts: boolean;
  inactivePatientAlerts: boolean;
  inactivePatientDays: number;
  postTreatmentSurvey: boolean;
  marketingCampaigns: boolean;

  // Security
  twoFactorAuth: boolean;
  autoLogoutMinutes: number;
  passwordExpireDays: number;
  sessionRecording: boolean;
  auditLog: boolean;

  // Backup
  autoBackup: boolean;
  backupFrequency: 'daily' | 'weekly' | 'monthly';
  backupRetentionDays: number;

  // Printing
  printLogo: boolean;
  printClinicInfo: boolean;
  invoiceFooterText: string;
  prescriptionFooterText: string;
}

// ---- NAVIGATION ----
export type AppPage = 'dashboard' | 'patients' | 'patient-detail' | 'agenda' | 'odontogram' | 'treatments' | 'billing' | 'inventory' | 'reports' | 'clinical-notes' | 'settings' | 'sql-schema' | 'login';
