import { useState, useRef, useEffect, useMemo } from 'react';
import { AppProvider, useAppState } from './store/context';
import { Dashboard } from './components/Dashboard';
import { Patients } from './components/Patients';
import { PatientDetail } from './components/PatientDetail';
import { Agenda } from './components/Agenda';
import { Odontogram } from './components/Odontogram';
import { Billing } from './components/Billing';
import { Inventory } from './components/Inventory';
import { Reports } from './components/Reports';
// SQLSchema removed from navigation - DB config moved to Settings
import { Settings } from './components/Settings';
import { LoginScreen } from './components/LoginScreen';
import { LandingPage } from './components/LandingPage';
import {
  LayoutDashboard, Users, Calendar, CircleDot, DollarSign, Package,
  BarChart3, Settings as SettingsIcon, Bell, ChevronLeft, Menu,
  Search, X
} from 'lucide-react';
import type { AppPage } from './store/types';

function AppContent() {
  const { currentPage, setCurrentPage, selectedPatientId, notifications, setSelectedPatientId, patients, markNotificationRead } = useAppState();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const unreadCount = notifications.filter(n => !n.read).length;

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchResults(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return patients.filter(p =>
      `${p.firstName} ${p.lastName} ${p.email} ${p.phone} ${p.idNumber}`.toLowerCase().includes(q)
    ).slice(0, 5);
  }, [searchQuery, patients]);

  const navItems: { id: AppPage; label: string; icon: React.ReactNode; group: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, group: 'Principal' },
    { id: 'patients', label: 'Pacientes', icon: <Users className="w-5 h-5" />, group: 'Principal' },
    { id: 'agenda', label: 'Agenda', icon: <Calendar className="w-5 h-5" />, group: 'Principal' },
    { id: 'odontogram', label: 'Odontograma', icon: <CircleDot className="w-5 h-5" />, group: 'Clínico' },
    { id: 'billing', label: 'Facturación', icon: <DollarSign className="w-5 h-5" />, group: 'Financiero' },
    { id: 'inventory', label: 'Inventario', icon: <Package className="w-5 h-5" />, group: 'Financiero' },
    { id: 'reports', label: 'Reportes', icon: <BarChart3 className="w-5 h-5" />, group: 'Analítica' },
    { id: 'settings', label: 'Configuración', icon: <SettingsIcon className="w-5 h-5" />, group: 'Sistema' },
  ];

  const groups = [...new Set(navItems.map(i => i.group))];

  const handleNavClick = (page: AppPage) => {
    setCurrentPage(page);
    setMobileSidebarOpen(false);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <Dashboard />;
      case 'patients': return <Patients onViewPatient={(id) => { setSelectedPatientId(id); setCurrentPage('patient-detail'); }} />;
      case 'patient-detail': return selectedPatientId ? <PatientDetail patientId={selectedPatientId} onBack={() => setCurrentPage('patients')} /> : <Patients onViewPatient={(id) => { setSelectedPatientId(id); setCurrentPage('patient-detail'); }} />;
      case 'agenda': return <Agenda />;
      case 'odontogram': return <Odontogram />;
      case 'billing': return <Billing />;
      case 'inventory': return <Inventory />;
      case 'reports': return <Reports />;
      case 'sql-schema': return <Settings />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className={`h-16 flex items-center border-b border-slate-100 ${sidebarCollapsed && !mobileSidebarOpen ? 'px-3 justify-center' : 'px-5'}`}>
        {sidebarCollapsed && !mobileSidebarOpen ? (
          <div className="w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-sm">YD</span>
          </div>
        ) : (
          <div className="flex items-center gap-3 w-full">
            <div className="w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center shadow-lg shadow-brand-200 shrink-0">
              <span className="text-white font-bold text-sm">YD</span>
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-lg font-bold text-slate-800 leading-tight">YourDentis</h1>
              <p className="text-[10px] text-slate-400 font-medium tracking-wider uppercase">Gestión Dental SaaS</p>
            </div>
            {mobileSidebarOpen && (
              <button onClick={() => setMobileSidebarOpen(false)} className="p-1 rounded-lg hover:bg-slate-100 lg:hidden">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3">
        {groups.map(group => (
          <div key={group} className="mb-4">
            {(!sidebarCollapsed || mobileSidebarOpen) && (
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">{group}</p>
            )}
            {navItems.filter(i => i.group === group).map(item => {
              const isActive = currentPage === item.id || (item.id === 'patients' && currentPage === 'patient-detail');
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  title={sidebarCollapsed && !mobileSidebarOpen ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-brand-50 text-brand-700 shadow-sm'
                      : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                  } ${sidebarCollapsed && !mobileSidebarOpen ? 'justify-center' : ''}`}
                >
                  <span className={isActive ? 'text-brand-600' : ''}>{item.icon}</span>
                  {(!sidebarCollapsed || mobileSidebarOpen) && <span>{item.label}</span>}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Collapse Button - desktop only */}
      <div className="border-t border-slate-100 p-3 hidden lg:block">
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <ChevronLeft className={`w-4 h-4 transition-transform ${sidebarCollapsed ? 'rotate-180' : ''}`} />
          {!sidebarCollapsed && <span>Colapsar</span>}
        </button>
      </div>
    </>
  );

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setMobileSidebarOpen(false)} />
      )}

      {/* Sidebar - Desktop */}
      <aside className={`${sidebarCollapsed ? 'w-[72px]' : 'w-64'} bg-white border-r border-slate-200 flex-col transition-all duration-300 shrink-0 z-20 hidden lg:flex`}>
        {sidebarContent}
      </aside>

      {/* Sidebar - Mobile */}
      <aside className={`fixed inset-y-0 left-0 w-72 bg-white border-r border-slate-200 flex flex-col z-40 transform transition-transform duration-300 lg:hidden ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        {sidebarContent}
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileSidebarOpen(true)} className="p-2 rounded-lg hover:bg-slate-100 lg:hidden">
              <Menu className="w-5 h-5 text-slate-600" />
            </button>
            {/* Search */}
            <div className="relative hidden sm:block" ref={searchRef}>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar pacientes..."
                value={searchQuery}
                onChange={e => { setSearchQuery(e.target.value); setShowSearchResults(true); }}
                onFocus={() => setShowSearchResults(true)}
                className="w-64 md:w-80 pl-10 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent focus:bg-white transition-all"
              />
              {showSearchResults && searchQuery.trim() && (
                <div className="absolute left-0 top-11 w-full bg-white rounded-xl shadow-xl border border-slate-200 z-50 overflow-hidden animate-slide-in">
                  {searchResults.length > 0 ? searchResults.map(p => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setSelectedPatientId(p.id);
                        setCurrentPage('patient-detail');
                        setSearchQuery('');
                        setShowSearchResults(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 transition-colors text-left"
                    >
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                        {p.firstName[0]}{p.lastName[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-800 truncate">{p.firstName} {p.lastName}</p>
                        <p className="text-xs text-slate-500 truncate">{p.email} · {p.phone}</p>
                      </div>
                    </button>
                  )) : (
                    <p className="p-4 text-sm text-slate-400 text-center">No se encontraron resultados</p>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Notifications */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2.5 rounded-xl hover:bg-slate-50 transition-colors"
              >
                <Bell className="w-5 h-5 text-slate-500" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse-dot">
                    {unreadCount}
                  </span>
                )}
              </button>
              {showNotifications && (
                <div className="absolute right-0 top-12 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 animate-slide-in">
                  <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-slate-800">Notificaciones</h3>
                    {unreadCount > 0 && (
                      <span className="text-xs bg-brand-100 text-brand-700 px-2 py-0.5 rounded-full font-medium">{unreadCount} nuevas</span>
                    )}
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.map(n => (
                      <button
                        key={n.id}
                        onClick={() => markNotificationRead(n.id)}
                        className={`w-full p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors text-left ${!n.read ? 'bg-brand-50/30' : ''}`}
                      >
                        <div className="flex items-start gap-3">
                          <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.priority === 'high' || n.priority === 'urgent' ? 'bg-red-500' : n.priority === 'medium' ? 'bg-amber-500' : 'bg-slate-300'}`} />
                          <div>
                            <p className="text-sm font-medium text-slate-800">{n.title}</p>
                            <p className="text-xs text-slate-500 mt-0.5">{n.message}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* User Menu */}
            <div className="flex items-center gap-2 sm:gap-3 pl-2 sm:pl-3 border-l border-slate-200">
              <div className="w-9 h-9 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center text-white font-bold text-xs">
                AD
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-slate-800">Admin Sistema</p>
                <p className="text-xs text-slate-400">Administrador</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 animate-fade-in" key={currentPage + (selectedPatientId || '')}>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

type AppView = 'landing' | 'login' | 'app';

export function App() {
  const [view, setView] = useState<AppView>('landing');

  if (view === 'landing') {
    return <LandingPage onGoToLogin={() => setView('login')} />;
  }

  if (view === 'login') {
    return <LoginScreen onLogin={() => setView('app')} onBack={() => setView('landing')} />;
  }

  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
