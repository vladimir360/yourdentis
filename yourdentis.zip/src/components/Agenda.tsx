import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, Plus, X, Check } from 'lucide-react';
import { format, addDays, startOfWeek, isSameDay, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { useAppState } from '../store/context';

type ViewMode = 'day' | 'week' | 'month';

const HOURS = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 7 PM

export function Agenda() {
  const { appointments, getPatientName, dentists, updateAppointmentStatus, patients, addAppointment } = useAppState();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  const [selectedDentist, setSelectedDentist] = useState<string>('all');
  const [showNewModal, setShowNewModal] = useState(false);

  const navigate = (dir: number) => {
    const d = new Date(currentDate);
    if (viewMode === 'day') d.setDate(d.getDate() + dir);
    else if (viewMode === 'week') d.setDate(d.getDate() + dir * 7);
    else d.setMonth(d.getMonth() + dir);
    setCurrentDate(d);
  };

  const filteredAppointments = useMemo(() => {
    return appointments.filter(a => selectedDentist === 'all' || a.dentistId === selectedDentist);
  }, [appointments, selectedDentist]);

  const weekDays = useMemo(() => {
    const start = startOfWeek(currentDate, { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  }, [currentDate]);

  const monthDays = useMemo(() => {
    const y = currentDate.getFullYear();
    const m = currentDate.getMonth();
    const firstDay = new Date(y, m, 1);
    const lastDay = new Date(y, m + 1, 0);
    const startDate = startOfWeek(firstDay, { weekStartsOn: 1 });
    const days: Date[] = [];
    let d = new Date(startDate);
    while (d <= lastDay || days.length % 7 !== 0) {
      days.push(new Date(d));
      d.setDate(d.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  // Stats
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const todayAppts = appointments.filter(a => a.date === todayStr);
  const confirmedToday = todayAppts.filter(a => a.status === 'confirmed').length;
  const pendingToday = todayAppts.filter(a => a.status === 'scheduled').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Agenda</h1>
          <p className="text-slate-500">
            Hoy: {todayAppts.length} citas · {confirmedToday} confirmadas · {pendingToday} pendientes
          </p>
        </div>
        <button
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200"
        >
          <Plus className="w-4 h-4" /> Nueva Cita
        </button>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-slate-100 transition-colors"><ChevronLeft className="w-5 h-5 text-slate-600" /></button>
            <h2 className="text-base sm:text-lg font-semibold text-slate-800 min-w-40 sm:min-w-48 text-center">
              {viewMode === 'day' && format(currentDate, "EEEE, d 'de' MMMM yyyy", { locale: es })}
              {viewMode === 'week' && `${format(weekDays[0], 'd MMM', { locale: es })} - ${format(weekDays[6], 'd MMM yyyy', { locale: es })}`}
              {viewMode === 'month' && format(currentDate, "MMMM yyyy", { locale: es })}
            </h2>
            <button onClick={() => navigate(1)} className="p-2 rounded-lg hover:bg-slate-100 transition-colors"><ChevronRight className="w-5 h-5 text-slate-600" /></button>
            <button onClick={() => setCurrentDate(new Date())} className="px-3 py-1.5 rounded-lg text-sm font-medium text-sky-600 hover:bg-sky-50 transition-colors">Hoy</button>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <select
              value={selectedDentist}
              onChange={e => setSelectedDentist(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="all">Todos los odontólogos</option>
              {dentists.map(d => (
                <option key={d.id} value={d.id}>Dr. {d.firstName} {d.lastName}</option>
              ))}
            </select>

            <div className="flex rounded-xl border border-slate-200 overflow-hidden">
              {(['day', 'week', 'month'] as const).map(v => (
                <button
                  key={v}
                  onClick={() => setViewMode(v)}
                  className={`px-3 py-2 text-sm font-medium transition-colors ${viewMode === v ? 'bg-sky-500 text-white' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
                >
                  {v === 'day' ? 'Día' : v === 'week' ? 'Semana' : 'Mes'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      {viewMode === 'month' ? (
        <MonthView days={monthDays} currentDate={currentDate} appointments={filteredAppointments} getPatientName={getPatientName} />
      ) : (
        <WeekDayView
          days={viewMode === 'day' ? [currentDate] : weekDays}
          appointments={filteredAppointments}
          getPatientName={getPatientName}
          onStatusChange={updateAppointmentStatus}
        />
      )}

      {/* Legends */}
      <div className="flex flex-wrap gap-4 px-2">
        {dentists.map(d => (
          <span key={d.id} className="flex items-center gap-2 text-xs text-slate-600">
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
            Dr. {d.lastName} - {d.specialty}
          </span>
        ))}
      </div>

      {/* New Appointment Modal */}
      {showNewModal && (
        <NewAppointmentModal
          patients={patients}
          dentists={dentists}
          onClose={() => setShowNewModal(false)}
          onAdd={addAppointment}
        />
      )}
    </div>
  );
}

function NewAppointmentModal({ patients, dentists, onClose, onAdd }: {
  patients: ReturnType<typeof useAppState>['patients'];
  dentists: ReturnType<typeof useAppState>['dentists'];
  onClose: () => void;
  onAdd: ReturnType<typeof useAppState>['addAppointment'];
}) {
  const [form, setForm] = useState({
    patientId: patients[0]?.id || '',
    dentistId: dentists[0]?.id || '',
    date: format(new Date(), 'yyyy-MM-dd'),
    startTime: '09:00',
    endTime: '09:30',
    type: 'Consulta general',
    notes: '',
    room: 'Sala 1',
  });
  const [submitted, setSubmitted] = useState(false);

  const update = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dentist = dentists.find(d => d.id === form.dentistId);
    const startH = parseInt(form.startTime.split(':')[0]);
    const endH = parseInt(form.endTime.split(':')[0]);
    const duration = (endH - startH) * 60;

    onAdd({
      id: `a_new_${Date.now()}`,
      clinicId: 'clinic_001',
      patientId: form.patientId,
      dentistId: form.dentistId,
      date: form.date,
      startTime: form.startTime,
      endTime: form.endTime,
      duration: duration > 0 ? duration : 30,
      type: form.type,
      status: 'scheduled',
      notes: form.notes,
      room: form.room,
      color: dentist?.color || '#3B82F6',
      reminderSent: false,
      createdAt: new Date().toISOString(),
    });
    setSubmitted(true);
    setTimeout(onClose, 1200);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-8 text-center max-w-sm animate-slide-in" onClick={e => e.stopPropagation()}>
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800">¡Cita Programada!</h3>
          <p className="text-sm text-slate-500 mt-2">La cita ha sido agregada a la agenda.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-lg animate-slide-in" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Nueva Cita</h2>
            <p className="text-sm text-slate-500">Programar una nueva cita</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Paciente *</label>
            <select value={form.patientId} onChange={e => update('patientId', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required>
              {patients.map(p => <option key={p.id} value={p.id}>{p.firstName} {p.lastName}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Odontólogo *</label>
            <select value={form.dentistId} onChange={e => update('dentistId', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required>
              {dentists.map(d => <option key={d.id} value={d.id}>Dr. {d.firstName} {d.lastName} — {d.specialty}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Fecha *</label>
              <input type="date" value={form.date} onChange={e => update('date', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Inicio *</label>
              <input type="time" value={form.startTime} onChange={e => update('startTime', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Fin *</label>
              <input type="time" value={form.endTime} onChange={e => update('endTime', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Tipo de Cita *</label>
              <select value={form.type} onChange={e => update('type', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                {['Consulta general', 'Limpieza dental', 'Restauración', 'Endodoncia', 'Extracción', 'Control ortodoncia', 'Emergencia dental', 'Revisión general', 'Blanqueamiento', 'Periodoncia'].map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Sala</label>
              <select value={form.room} onChange={e => update('room', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                {['Sala 1', 'Sala 2', 'Sala 3', 'Sala 4'].map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Notas</label>
            <textarea value={form.notes} onChange={e => update('notes', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none h-16" placeholder="Notas adicionales..." />
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-100">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
              Cancelar
            </button>
            <button type="submit" className="flex-1 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium transition-colors shadow-lg shadow-sky-200">
              Programar Cita
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function WeekDayView({ days, appointments, getPatientName, onStatusChange }: {
  days: Date[];
  appointments: ReturnType<typeof useAppState>['appointments'];
  getPatientName: (id: string) => string;
  onStatusChange: (id: string, status: 'completed' | 'cancelled' | 'no-show') => void;
}) {
  const isToday = (d: Date) => isSameDay(d, new Date());

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <div className="overflow-x-auto">
        <div className="min-w-[700px]">
          {/* Header */}
          <div className="grid border-b border-slate-200" style={{ gridTemplateColumns: `60px repeat(${days.length}, 1fr)` }}>
            <div className="p-3 border-r border-slate-100" />
            {days.map(day => (
              <div key={day.toISOString()} className={`p-3 text-center border-r border-slate-100 last:border-r-0 ${isToday(day) ? 'bg-sky-50' : ''}`}>
                <p className="text-xs text-slate-500 uppercase">{format(day, 'EEE', { locale: es })}</p>
                <p className={`text-lg font-bold mt-0.5 ${isToday(day) ? 'text-white bg-sky-500 w-8 h-8 rounded-full flex items-center justify-center mx-auto' : 'text-slate-800'}`}>
                  {format(day, 'd')}
                </p>
              </div>
            ))}
          </div>

          {/* Time Grid */}
          <div className="relative">
            {HOURS.map(hour => (
              <div key={hour} className="grid border-b border-slate-50" style={{ gridTemplateColumns: `60px repeat(${days.length}, 1fr)` }}>
                <div className="p-2 text-right pr-3 border-r border-slate-100">
                  <span className="text-xs text-slate-400">{hour}:00</span>
                </div>
                {days.map(day => {
                  const dayAppts = appointments.filter(a => {
                    try {
                      return isSameDay(parseISO(a.date), day) && parseInt(a.startTime) === hour;
                    } catch { return false; }
                  });
                  return (
                    <div key={day.toISOString()} className={`min-h-16 border-r border-slate-50 last:border-r-0 p-0.5 ${isToday(day) ? 'bg-sky-50/30' : ''}`}>
                      {dayAppts.map(apt => (
                        <div
                          key={apt.id}
                          className="group rounded-lg p-1.5 text-xs text-white mb-0.5 cursor-pointer hover:opacity-90 transition-opacity relative"
                          style={{ backgroundColor: apt.color + 'dd' }}
                        >
                          <p className="font-semibold truncate">{getPatientName(apt.patientId)}</p>
                          <p className="opacity-80 truncate">{apt.startTime} - {apt.endTime}</p>
                          <p className="opacity-80 truncate">{apt.type}</p>
                          {apt.status !== 'completed' && apt.status !== 'cancelled' && (
                            <div className="absolute top-0 right-0 hidden group-hover:flex bg-white rounded-lg shadow-lg border p-1 gap-1 z-10">
                              <button onClick={(e) => { e.stopPropagation(); onStatusChange(apt.id, 'completed'); }} className="text-[10px] px-1.5 py-0.5 bg-emerald-500 text-white rounded" title="Completar">✓</button>
                              <button onClick={(e) => { e.stopPropagation(); onStatusChange(apt.id, 'cancelled'); }} className="text-[10px] px-1.5 py-0.5 bg-red-500 text-white rounded" title="Cancelar">✗</button>
                              <button onClick={(e) => { e.stopPropagation(); onStatusChange(apt.id, 'no-show'); }} className="text-[10px] px-1.5 py-0.5 bg-amber-500 text-white rounded" title="No asistió">NS</button>
                            </div>
                          )}
                          {apt.status === 'completed' && (
                            <span className="absolute top-0.5 right-0.5 w-3 h-3 bg-white rounded-full flex items-center justify-center">
                              <Check className="w-2 h-2 text-emerald-600" />
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MonthView({ days, currentDate, appointments, getPatientName }: {
  days: Date[];
  currentDate: Date;
  appointments: ReturnType<typeof useAppState>['appointments'];
  getPatientName: (id: string) => string;
}) {
  const isToday = (d: Date) => isSameDay(d, new Date());
  const isCurrentMonth = (d: Date) => d.getMonth() === currentDate.getMonth();

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <div className="grid grid-cols-7">
        {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(d => (
          <div key={d} className="p-3 text-center text-xs font-medium text-slate-500 uppercase border-b border-slate-200 bg-slate-50">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {days.map(day => {
          const dayAppts = appointments.filter(a => { try { return isSameDay(parseISO(a.date), day); } catch { return false; } });
          return (
            <div key={day.toISOString()} className={`min-h-24 border-b border-r border-slate-100 p-1.5 ${!isCurrentMonth(day) ? 'bg-slate-50/50' : ''} ${isToday(day) ? 'bg-sky-50' : ''}`}>
              <p className={`text-xs font-medium mb-1 ${isToday(day) ? 'text-sky-600 font-bold' : isCurrentMonth(day) ? 'text-slate-700' : 'text-slate-300'}`}>
                {format(day, 'd')}
              </p>
              {dayAppts.slice(0, 3).map(apt => (
                <div key={apt.id} className="text-[10px] rounded px-1 py-0.5 mb-0.5 text-white truncate" style={{ backgroundColor: apt.color }}>
                  {apt.startTime} {getPatientName(apt.patientId).split(' ')[0]}
                </div>
              ))}
              {dayAppts.length > 3 && <p className="text-[10px] text-slate-400">+{dayAppts.length - 3} más</p>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
