import { Users, Calendar, DollarSign, AlertTriangle, TrendingUp, Clock, Activity, Package } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { useAppState } from '../store/context';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const CHART_COLORS = ['#3B93F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#EC4899'];

export function Dashboard() {
  const { patients, appointments, invoices, treatments, inventory, dentists, getPatientName, getDentistName } = useAppState();

  const today = format(new Date(), 'yyyy-MM-dd');
  const todayAppointments = appointments.filter(a => a.date === today);
  const activePatients = patients.filter(p => p.status === 'active').length;
  const totalRevenue = invoices.reduce((s, i) => s + i.paid, 0);
  const pendingBalance = invoices.reduce((s, i) => s + (i.total - i.paid), 0);
  const lowStockItems = inventory.filter(i => i.currentStock <= i.minStock).length;

  const monthlyRevenue = [
    { month: 'Ago', ingreso: 4200 },
    { month: 'Sep', ingreso: 5800 },
    { month: 'Oct', ingreso: 4900 },
    { month: 'Nov', ingreso: 6100 },
    { month: 'Dic', ingreso: 5300 },
    { month: 'Ene', ingreso: totalRevenue > 0 ? totalRevenue : 3800 },
  ];

  const treatmentTypes = treatments.reduce((acc, t) => {
    acc[t.type] = (acc[t.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const treatmentData = Object.entries(treatmentTypes).map(([name, value]) => ({ name, value }));

  const dentistPerformance = dentists.map(d => ({
    name: `Dr. ${d.lastName}`,
    citas: appointments.filter(a => a.dentistId === d.id).length,
    completadas: appointments.filter(a => a.dentistId === d.id && a.status === 'completed').length,
  }));

  const appointmentStatusData = [
    { name: 'Completadas', value: appointments.filter(a => a.status === 'completed').length },
    { name: 'Confirmadas', value: appointments.filter(a => a.status === 'confirmed').length },
    { name: 'Programadas', value: appointments.filter(a => a.status === 'scheduled').length },
    { name: 'Canceladas', value: appointments.filter(a => a.status === 'cancelled').length },
    { name: 'No asistió', value: appointments.filter(a => a.status === 'no-show').length },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Dashboard</h1>
        <p className="text-slate-500">{format(new Date(), "EEEE, d 'de' MMMM yyyy", { locale: es })}</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard icon={<Calendar className="w-5 h-5" />} label="Citas Hoy" value={todayAppointments.length.toString()} sub={`${todayAppointments.filter(a => a.status === 'confirmed').length} confirmadas`} color="bg-sky-500" />
        <KpiCard icon={<Users className="w-5 h-5" />} label="Pacientes Activos" value={activePatients.toString()} sub={`${patients.length} total`} color="bg-emerald-500" />
        <KpiCard icon={<DollarSign className="w-5 h-5" />} label="Ingresos Cobrados" value={`$${totalRevenue.toLocaleString()}`} sub="este periodo" color="bg-violet-500" />
        <KpiCard icon={<AlertTriangle className="w-5 h-5" />} label="Saldo Pendiente" value={`$${pendingBalance.toLocaleString()}`} sub={`${lowStockItems} items bajo stock`} color="bg-amber-500" />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-sky-500" /> Ingresos Mensuales
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={monthlyRevenue}>
              <defs>
                <linearGradient id="colorIngreso" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0EA5E9" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#0EA5E9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={v => `$${v}`} />
              <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Ingreso']} />
              <Area type="monotone" dataKey="ingreso" stroke="#0EA5E9" strokeWidth={2} fill="url(#colorIngreso)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-violet-500" /> Estado de Citas
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={appointmentStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={5} dataKey="value">
                {appointmentStatusData.map((_, idx) => (
                  <Cell key={idx} fill={CHART_COLORS[idx % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-2 justify-center">
            {appointmentStatusData.map((d, i) => (
              <span key={d.name} className="flex items-center gap-1 text-xs text-slate-600">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }} />
                {d.name} ({d.value})
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-500" /> Rendimiento por Odontólogo
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={dentistPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip />
              <Bar dataKey="citas" fill="#0EA5E9" radius={[6, 6, 0, 0]} name="Total citas" />
              <Bar dataKey="completadas" fill="#10B981" radius={[6, 6, 0, 0]} name="Completadas" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-500" /> Procedimientos Realizados
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={treatmentData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" stroke="#94a3b8" fontSize={12} />
              <YAxis type="category" dataKey="name" stroke="#94a3b8" fontSize={11} width={100} />
              <Tooltip />
              <Bar dataKey="value" fill="#8B5CF6" radius={[0, 6, 6, 0]} name="Cantidad" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Today's Appointments + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-sky-500" /> Citas de Hoy
          </h3>
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {todayAppointments.length === 0 ? (
              <p className="text-slate-400 text-center py-8">No hay citas programadas para hoy</p>
            ) : todayAppointments.map(apt => (
              <div key={apt.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
                <div className="w-1 h-12 rounded-full" style={{ backgroundColor: apt.color }} />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-800 truncate">{getPatientName(apt.patientId)}</p>
                  <p className="text-sm text-slate-500">{apt.type} • {getDentistName(apt.dentistId)}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-medium text-slate-700">{apt.startTime} - {apt.endTime}</p>
                  <span className={`inline-block text-xs px-2 py-0.5 rounded-full font-medium ${
                    apt.status === 'confirmed' ? 'bg-emerald-100 text-emerald-700' :
                    apt.status === 'completed' ? 'bg-sky-100 text-sky-700' :
                    apt.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                    'bg-amber-100 text-amber-700'
                  }`}>{apt.status === 'confirmed' ? 'Confirmada' : apt.status === 'scheduled' ? 'Programada' : apt.status === 'completed' ? 'Completada' : apt.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Package className="w-5 h-5 text-red-500" /> Alertas del Sistema
          </h3>
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {inventory.filter(i => i.currentStock <= i.minStock).map(item => (
              <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-red-50 border border-red-100">
                <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-red-800 text-sm">{item.name}</p>
                  <p className="text-xs text-red-600">Stock: {item.currentStock}/{item.minStock} mínimo</p>
                </div>
              </div>
            ))}
            {invoices.filter(i => i.status === 'pending' || i.status === 'overdue').map(inv => (
              <div key={inv.id} className="flex items-center gap-3 p-3 rounded-xl bg-amber-50 border border-amber-100">
                <DollarSign className="w-4 h-4 text-amber-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-amber-800 text-sm">{getPatientName(inv.patientId)}</p>
                  <p className="text-xs text-amber-600">Pendiente: ${(inv.total - inv.paid).toLocaleString()} • Vence: {inv.dueDate}</p>
                </div>
              </div>
            ))}
            {patients.filter(p => p.status === 'inactive').map(pat => (
              <div key={pat.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <Users className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-700 text-sm">{pat.firstName} {pat.lastName}</p>
                  <p className="text-xs text-slate-500">Paciente inactivo • Última visita: {pat.lastVisit}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function KpiCard({ icon, label, value, sub, color }: { icon: React.ReactNode; label: string; value: string; sub: string; color: string }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-lg hover:shadow-slate-100 transition-all">
      <div className="flex items-center gap-3">
        <div className={`${color} text-white p-2.5 rounded-xl`}>{icon}</div>
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="text-2xl font-bold text-slate-800">{value}</p>
          <p className="text-xs text-slate-400">{sub}</p>
        </div>
      </div>
    </div>
  );
}
