import { useState } from 'react';
import { Package, AlertTriangle, Search, Plus, TrendingDown, CheckCircle, X } from 'lucide-react';
import { useAppState } from '../store/context';

export function Inventory() {
  const { inventory } = useAppState();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'low' | 'ok'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = inventory.filter(item => {
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase()) || item.category.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || (filter === 'low' && item.currentStock <= item.minStock) || (filter === 'ok' && item.currentStock > item.minStock);
    return matchSearch && matchFilter;
  });

  const totalItems = inventory.length;
  const lowStockCount = inventory.filter(i => i.currentStock <= i.minStock).length;
  const totalValue = inventory.reduce((s, i) => s + (i.currentStock * i.unitCost), 0);
  // categories available: [...new Set(inventory.map(i => i.category))]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Inventario</h1>
          <p className="text-slate-500">Control de materiales dentales</p>
        </div>
        <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200">
          <Plus className="w-4 h-4" /> Agregar Material
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-sky-500 text-white p-2.5 rounded-xl"><Package className="w-5 h-5" /></div>
          <div>
            <p className="text-sm text-slate-500">Total Items</p>
            <p className="text-2xl font-bold text-slate-800">{totalItems}</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-red-500 text-white p-2.5 rounded-xl"><AlertTriangle className="w-5 h-5" /></div>
          <div>
            <p className="text-sm text-slate-500">Bajo Stock</p>
            <p className="text-2xl font-bold text-red-600">{lowStockCount}</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-emerald-500 text-white p-2.5 rounded-xl"><TrendingDown className="w-5 h-5" /></div>
          <div>
            <p className="text-sm text-slate-500">Valor Total</p>
            <p className="text-2xl font-bold text-emerald-600">${totalValue.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" placeholder="Buscar material..." value={search} onChange={e => setSearch(e.target.value)} className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
        </div>
        <div className="flex gap-2">
          {(['all', 'low', 'ok'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${filter === f ? 'bg-sky-500 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
              {f === 'all' ? 'Todos' : f === 'low' ? '⚠ Bajo Stock' : '✓ Ok'}
            </button>
          ))}
        </div>
      </div>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(item => {
          const isLow = item.currentStock <= item.minStock;
          const stockPercent = Math.min((item.currentStock / (item.minStock * 3)) * 100, 100);
          return (
            <div key={item.id} className={`bg-white rounded-2xl border p-5 hover:shadow-lg hover:shadow-slate-100 transition-all ${isLow ? 'border-red-200' : 'border-slate-200'}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-800">{item.name}</h3>
                  <p className="text-sm text-slate-500 mt-0.5">{item.category}</p>
                </div>
                {isLow ? (
                  <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Bajo</span>
                ) : (
                  <span className="bg-emerald-100 text-emerald-700 text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Ok</span>
                )}
              </div>

              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-500">Stock: <strong className={isLow ? 'text-red-600' : 'text-slate-800'}>{item.currentStock}</strong> {item.unit}s</span>
                  <span className="text-slate-400">Min: {item.minStock}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all ${isLow ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${stockPercent}%` }} />
                </div>
              </div>

              <div className="mt-3 flex justify-between text-xs text-slate-500">
                <span>Costo: ${item.unitCost}/{item.unit}</span>
                <span>Proveedor: {item.supplier}</span>
              </div>
              <div className="mt-1 text-xs text-slate-400">Último restock: {item.lastRestocked}</div>
            </div>
          );
        })}
      </div>

      {/* Add Material Modal */}
      {showAddModal && <AddMaterialModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
}

function AddMaterialModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({
    name: '', category: 'Materiales de restauración', sku: '', currentStock: '',
    minStock: '', unit: 'unidad', unitCost: '', supplier: '', supplierContact: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const update = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(onClose, 1500);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-8 text-center max-w-sm animate-slide-in" onClick={e => e.stopPropagation()}>
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800">¡Material Agregado!</h3>
          <p className="text-sm text-slate-500 mt-2">{form.name} ha sido registrado exitosamente.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-in" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-slate-100 p-5 flex items-center justify-between rounded-t-2xl z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Agregar Material</h2>
            <p className="text-sm text-slate-500">Registrar nuevo material en inventario</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100"><X className="w-5 h-5 text-slate-400" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Nombre del material *</label>
            <input type="text" value={form.name} onChange={e => update('name', e.target.value)} placeholder="Ej: Resina compuesta A2" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Categoría *</label>
              <select value={form.category} onChange={e => update('category', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                {['Materiales de restauración', 'Anestésicos', 'Desechables', 'Ortodoncia', 'Instrumental', 'Cirugía', 'Materiales de impresión', 'Endodoncia', 'Otros'].map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">SKU / Código</label>
              <input type="text" value={form.sku} onChange={e => update('sku', e.target.value)} placeholder="MAT-XXX" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Stock actual *</label>
              <input type="number" min={0} value={form.currentStock} onChange={e => update('currentStock', e.target.value)} placeholder="0" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Stock mínimo *</label>
              <input type="number" min={0} value={form.minStock} onChange={e => update('minStock', e.target.value)} placeholder="0" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Unidad *</label>
              <select value={form.unit} onChange={e => update('unit', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                {['unidad', 'caja', 'paquete', 'frasco', 'sobre', 'jeringa', 'kit', 'bolsa', 'rollo', 'litro'].map(u => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Costo unitario ($) *</label>
            <input type="number" min={0} step={0.01} value={form.unitCost} onChange={e => update('unitCost', e.target.value)} placeholder="0.00" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Proveedor</label>
              <input type="text" value={form.supplier} onChange={e => update('supplier', e.target.value)} placeholder="Nombre del proveedor" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Contacto proveedor</label>
              <input type="text" value={form.supplierContact} onChange={e => update('supplierContact', e.target.value)} placeholder="Teléfono" className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-100">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50">Cancelar</button>
            <button type="submit" className="flex-1 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium shadow-lg shadow-sky-200">Agregar Material</button>
          </div>
        </form>
      </div>
    </div>
  );
}
