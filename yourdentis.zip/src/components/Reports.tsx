import { BarChart3, TrendingUp, Users, Calendar, DollarSign, Activity, PieChart as PieIcon, ArrowUp, ArrowDown, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, LineChart, Line } from 'recharts';
import { useAppState } from '../store/context';

const COLORS = ['#3B93F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#EC4899', '#14B8A6', '#6366F1'];

export function Reports() {
  const { patients, appointments, invoices, treatments, dentists } = useAppState();

  const totalRevenue = invoices.reduce((s, i) => s + i.paid, 0);
  const totalPending = invoices.reduce((s, i) => s + (i.total - i.paid), 0);
  const activePatients = patients.filter(p => p.status === 'active').length;
  const completedAppts = appointments.filter(a => a.status === 'completed').length;
  const noShowRate = appointments.length > 0 ? Math.round((appointments.filter(a => a.status === 'no-show').length / appointments.length) * 100) : 0;

  const monthlyRevenue = [
    { month: 'Jul', ingresos: 3200, gastos: 1800 },
    { month: 'Ago', ingresos: 4200, gastos: 2100 },
    { month: 'Sep', ingresos: 5800, gastos: 2400 },
    { month: 'Oct', ingresos: 4900, gastos: 2200 },
    { month: 'Nov', ingresos: 6100, gastos: 2600 },
    { month: 'Dic', ingresos: 5300, gastos: 2300 },
    { month: 'Ene', ingresos: totalRevenue > 0 ? totalRevenue : 4600, gastos: 2100 },
  ];

  const treatmentByCount = treatments.reduce((acc, t) => {
    acc[t.type] = (acc[t.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const treatmentCountData = Object.entries(treatmentByCount).map(([name, value]) => ({ name, value }));

  const treatmentRevenue = treatments.reduce((acc, t) => {
    acc[t.type] = (acc[t.type] || 0) + t.cost;
    return acc;
  }, {} as Record<string, number>);
  const treatmentRevenueData = Object.entries(treatmentRevenue).map(([name, revenue]) => ({ name, revenue })).sort((a, b) => b.revenue - a.revenue);

  const dentistPerformance = dentists.map(d => ({
    name: `Dr. ${d.lastName}`,
    citas: appointments.filter(a => a.dentistId === d.id).length,
    completadas: appointments.filter(a => a.dentistId === d.id && a.status === 'completed').length,
    ingresos: treatments.filter(t => t.dentistId === d.id).reduce((s, t) => s + t.cost, 0),
  }));

  const appointmentStatusData = [
    { name: 'Completadas', value: appointments.filter(a => a.status === 'completed').length },
    { name: 'Confirmadas', value: appointments.filter(a => a.status === 'confirmed').length },
    { name: 'Programadas', value: appointments.filter(a => a.status === 'scheduled').length },
    { name: 'Canceladas', value: appointments.filter(a => a.status === 'cancelled').length },
    { name: 'No asistió', value: appointments.filter(a => a.status === 'no-show').length },
  ].filter(d => d.value > 0);

  const patientGrowth = [
    { month: 'Jul', nuevos: 1, activos: 3 },
    { month: 'Ago', nuevos: 1, activos: 4 },
    { month: 'Sep', nuevos: 2, activos: 5 },
    { month: 'Oct', nuevos: 0, activos: 5 },
    { month: 'Nov', nuevos: 1, activos: 6 },
    { month: 'Dic', nuevos: 1, activos: 7 },
    { month: 'Ene', nuevos: 0, activos: activePatients },
  ];

  const invoiceStatusData = [
    { name: 'Pagadas', value: invoices.filter(i => i.status === 'paid').length, color: '#10B981' },
    { name: 'Parciales', value: invoices.filter(i => i.status === 'partial').length, color: '#F59E0B' },
    { name: 'Pendientes', value: invoices.filter(i => i.status === 'pending').length, color: '#EF4444' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Reportes y Analíticas</h1>
          <p className="text-slate-500">Análisis de rendimiento de la clínica</p>
        </div>
        <button
          onClick={() => {
            let content = '🦷 YOURDENTIS - REPORTE GENERAL\n';
            content += '═══════════════════════════════════════\n\n';
            content += `Fecha: ${new Date().toLocaleDateString('es-DO')}\n\n`;
            content += '─── RESUMEN FINANCIERO ───\n';
            content += `Ingresos Totales: $${totalRevenue.toLocaleString()}\n`;
            content += `Pendiente Cobro: $${totalPending.toLocaleString()}\n`;
            content += `Pacientes Activos: ${activePatients}\n`;
            content += `Citas Completadas: ${completedAppts}\n`;
            content += `Tasa No Asistencia: ${noShowRate}%\n\n`;
            content += '─── INGRESOS POR PROCEDIMIENTO ───\n';
            treatmentRevenueData.forEach(t => { content += `${t.name}: $${t.revenue.toLocaleString()}\n`; });
            content += '\n─── RENDIMIENTO POR ODONTÓLOGO ───\n';
            dentistPerformance.forEach(d => {
              content += `${d.name}: ${d.citas} citas, ${d.completadas} completadas, $${d.ingresos.toLocaleString()}\n`;
            });
            content += '\n\n© YourDentis - Sistema de Gestión Odontológica\n';
            const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `reporte_yourdentis_${new Date().toISOString().split('T')[0]}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200 text-sm"
        >
          <Download className="w-4 h-4" /> Exportar Reporte
        </button>
      </div>

      {/* KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KpiMini icon={<DollarSign className="w-4 h-4" />} label="Ingresos Totales" value={`$${totalRevenue.toLocaleString()}`} trend="+12%" up color="bg-emerald-500" />
        <KpiMini icon={<DollarSign className="w-4 h-4" />} label="Pendiente Cobro" value={`$${totalPending.toLocaleString()}`} trend="3 facturas" up={false} color="bg-amber-500" />
        <KpiMini icon={<Users className="w-4 h-4" />} label="Pacientes Activos" value={activePatients.toString()} trend="+2 este mes" up color="bg-brand-500" />
        <KpiMini icon={<Calendar className="w-4 h-4" />} label="Citas Completadas" value={completedAppts.toString()} trend={`${appointments.length} total`} up color="bg-violet-500" />
        <KpiMini icon={<Activity className="w-4 h-4" />} label="Tasa No Asistencia" value={`${noShowRate}%`} trend="vs 15% anterior" up={false} color="bg-red-500" />
      </div>

      {/* Revenue Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-brand-500" /> Ingresos vs Gastos Mensuales
          </h3>
          <p className="text-xs text-slate-400 mb-4">Últimos 7 meses</p>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyRevenue}>
              <defs>
                <linearGradient id="colorIngresos" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B93F6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3B93F6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorGastos" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#EF4444" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={v => `$${v}`} />
              <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, '']} />
              <Area type="monotone" dataKey="ingresos" stroke="#3B93F6" strokeWidth={2} fill="url(#colorIngresos)" name="Ingresos" />
              <Area type="monotone" dataKey="gastos" stroke="#EF4444" strokeWidth={2} fill="url(#colorGastos)" name="Gastos" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <PieIcon className="w-5 h-5 text-violet-500" /> Estado de Facturas
          </h3>
          <p className="text-xs text-slate-400 mb-4">{invoices.length} facturas totales</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={invoiceStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={5} dataKey="value">
                {invoiceStatusData.map((entry, idx) => (
                  <Cell key={idx} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {invoiceStatusData.map(d => (
              <div key={d.name} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                  {d.name}
                </span>
                <span className="font-semibold text-slate-800">{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Treatment & Patient Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-brand-500" /> Ingresos por Procedimiento
          </h3>
          <p className="text-xs text-slate-400 mb-4">{treatmentCountData.reduce((s, t) => s + t.value, 0)} tratamientos totales</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={treatmentRevenueData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" stroke="#94a3b8" fontSize={12} tickFormatter={v => `$${v}`} />
              <YAxis type="category" dataKey="name" stroke="#94a3b8" fontSize={11} width={100} />
              <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Ingreso']} />
              <Bar dataKey="revenue" radius={[0, 6, 6, 0]} name="Ingreso">
                {treatmentRevenueData.map((_, idx) => (
                  <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-500" /> Crecimiento de Pacientes
          </h3>
          <p className="text-xs text-slate-400 mb-4">Nuevos pacientes y base activa</p>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={patientGrowth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip />
              <Line type="monotone" dataKey="activos" stroke="#10B981" strokeWidth={2} dot={{ fill: '#10B981', r: 4 }} name="Activos" />
              <Line type="monotone" dataKey="nuevos" stroke="#3B93F6" strokeWidth={2} dot={{ fill: '#3B93F6', r: 4 }} name="Nuevos" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Dentist Performance & Appointment Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <Activity className="w-5 h-5 text-violet-500" /> Rendimiento por Odontólogo
          </h3>
          <p className="text-xs text-slate-400 mb-4">Citas e ingresos generados</p>
          <div className="space-y-4">
            {dentistPerformance.map((d, i) => (
              <div key={d.name} className="flex items-center gap-4 p-3 rounded-xl bg-slate-50">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-xs" style={{ backgroundColor: COLORS[i] }}>
                  {d.name.split(' ')[1]?.[0] || 'D'}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{d.name}</p>
                  <div className="flex gap-4 mt-1">
                    <span className="text-xs text-slate-500">{d.citas} citas</span>
                    <span className="text-xs text-emerald-600">{d.completadas} completadas</span>
                    <span className="text-xs text-brand-600 font-medium">${d.ingresos.toLocaleString()}</span>
                  </div>
                </div>
                <div className="w-20 h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${d.citas > 0 ? (d.completadas / d.citas) * 100 : 0}%`, backgroundColor: COLORS[i] }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-500" /> Distribución de Citas
          </h3>
          <p className="text-xs text-slate-400 mb-4">Por estado actual</p>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={appointmentStatusData} cx="50%" cy="50%" outerRadius={100} paddingAngle={3} dataKey="value" label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}>
                {appointmentStatusData.map((_, idx) => (
                  <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-r from-brand-600 to-violet-600 rounded-2xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          🤖 Insights Inteligentes con IA
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <p className="text-sm font-medium mb-1">📊 Predicción de Ausencias</p>
            <p className="text-xs text-white/80">Basado en el historial, hay un 15% de probabilidad de no-show para las citas de mañana. Se recomienda enviar recordatorios adicionales.</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <p className="text-sm font-medium mb-1">💰 Análisis de Ingresos</p>
            <p className="text-xs text-white/80">Los ingresos muestran tendencia alcista del 12%. La ortodoncia genera el mayor revenue (68% del total).</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <p className="text-sm font-medium mb-1">🔔 Seguimiento Clínico</p>
            <p className="text-xs text-white/80">3 pacientes requieren seguimiento: Miguel Herrera (inactivo 60+ días), Carlos Gómez (endodoncia pendiente).</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function KpiMini({ icon, label, value, trend, up, color }: { icon: React.ReactNode; label: string; value: string; trend: string; up: boolean; color: string }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4">
      <div className="flex items-center gap-2 mb-2">
        <div className={`${color} text-white p-1.5 rounded-lg`}>{icon}</div>
        <span className="text-xs text-slate-500">{label}</span>
      </div>
      <p className="text-xl font-bold text-slate-800">{value}</p>
      <span className={`text-xs font-medium flex items-center gap-1 mt-1 ${up ? 'text-emerald-600' : 'text-amber-600'}`}>
        {up ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />} {trend}
      </span>
    </div>
  );
}
