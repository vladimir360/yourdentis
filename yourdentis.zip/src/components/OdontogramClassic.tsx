import { useState, useMemo } from 'react';
import { Download, RotateCcw, Info, UserCircle, History, ChevronDown } from 'lucide-react';
import { useAppState } from '../store/context';

type ToothStatus = 'healthy' | 'cavity' | 'filling' | 'crown' | 'extraction' | 'root-canal' | 'implant' | 'sealant';

interface ToothData {
  number: number;
  status: ToothStatus;
  surfaces: { top: ToothStatus; bottom: ToothStatus; left: ToothStatus; right: ToothStatus; center: ToothStatus };
  notes: string;
  history: { date: string; condition: ToothStatus; surface?: string }[];
}

const STATUS_COLORS: Record<ToothStatus, string> = {
  healthy: '#FFFFFF',
  cavity: '#EF4444',
  filling: '#3B82F6',
  crown: '#F59E0B',
  extraction: '#6B7280',
  'root-canal': '#8B5CF6',
  implant: '#10B981',
  sealant: '#EC4899',
};

const STATUS_LABELS: Record<ToothStatus, string> = {
  healthy: 'Sano',
  cavity: 'Caries',
  filling: 'Obturación',
  crown: 'Corona',
  extraction: 'Extracción',
  'root-canal': 'Endodoncia',
  implant: 'Implante',
  sealant: 'Sellante',
};

const STATUS_ICONS: Record<ToothStatus, string> = {
  healthy: '✓',
  cavity: '●',
  filling: '◆',
  crown: '♛',
  extraction: '✕',
  'root-canal': '⊕',
  implant: '⬡',
  sealant: '◐',
};

const UPPER_TEETH = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const LOWER_TEETH = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

function getToothName(num: number): string {
  const n = num % 10;
  let type = 'Molar';
  if (n === 1) type = 'Incisivo Central';
  else if (n === 2) type = 'Incisivo Lateral';
  else if (n === 3) type = 'Canino';
  else if (n <= 5) type = 'Premolar';
  const quadrant = Math.floor(num / 10);
  const side = quadrant === 1 || quadrant === 4 ? 'Derecho' : 'Izquierdo';
  const arch = quadrant <= 2 ? 'Superior' : 'Inferior';
  return `${type} ${arch} ${side}`;
}

const defaultSurfaces = (): ToothData['surfaces'] => ({
  top: 'healthy', bottom: 'healthy', left: 'healthy', right: 'healthy', center: 'healthy'
});

function createInitialTeeth(): Record<number, ToothData> {
  const teeth: Record<number, ToothData> = {};
  [...UPPER_TEETH, ...LOWER_TEETH].forEach(n => {
    teeth[n] = { number: n, status: 'healthy', surfaces: defaultSurfaces(), notes: '', history: [] };
  });
  teeth[16].surfaces.top = 'cavity';
  teeth[16].surfaces.center = 'cavity';
  teeth[16].history = [{ date: '2025-01-10', condition: 'cavity', surface: 'oclusal' }];
  teeth[26].surfaces.center = 'filling';
  teeth[26].history = [{ date: '2024-11-15', condition: 'filling', surface: 'centro' }];
  teeth[36].status = 'extraction';
  teeth[36].history = [{ date: '2024-12-15', condition: 'extraction' }];
  teeth[46].surfaces.center = 'root-canal';
  teeth[46].history = [{ date: '2025-01-08', condition: 'root-canal' }];
  teeth[11].status = 'crown';
  teeth[11].history = [{ date: '2024-10-20', condition: 'crown' }];
  teeth[37].surfaces.top = 'filling';
  teeth[37].surfaces.left = 'filling';
  teeth[24].surfaces.center = 'sealant';
  teeth[24].history = [{ date: '2024-09-05', condition: 'sealant', surface: 'oclusal' }];
  return teeth;
}

export function OdontogramClassic() {
  const { patients } = useAppState();
  const [teeth, setTeeth] = useState<Record<number, ToothData>>(createInitialTeeth);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [currentTool, setCurrentTool] = useState<ToothStatus>('cavity');
  const [selectedPatient, setSelectedPatient] = useState(patients[0]?.id || '');
  const [toothNotes, setToothNotes] = useState('');
  const [showHistory, setShowHistory] = useState(false);

  const patient = patients.find(p => p.id === selectedPatient);

  const exportPDF = () => {
    const toothData = Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy'));
    let content = '🦷 YOURDENTIS - ODONTOGRAMA CLÁSICO\n';
    content += '═══════════════════════════════════════\n\n';
    content += `Paciente: ${patient ? `${patient.firstName} ${patient.lastName}` : 'N/A'}\n`;
    content += `Fecha: ${new Date().toLocaleDateString('es-DO')}\n\n`;
    content += '─── DIENTES CON CONDICIÓN ───\n\n';
    if (toothData.length === 0) { content += 'Todos los dientes sanos.\n'; } else {
      toothData.forEach(t => {
        content += `#${t.number} ${getToothName(t.number)}: ${STATUS_LABELS[t.status]}\n`;
        Object.entries(t.surfaces).filter(([, s]) => s !== 'healthy').forEach(([surf, status]) => {
          content += `  ${surf}: ${STATUS_LABELS[status]}\n`;
        });
      });
    }
    content += '\n© YourDentis\n';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `odontograma_clasico_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSurfaceClick = (toothNum: number, surface: keyof ToothData['surfaces']) => {
    setTeeth(prev => {
      const t = { ...prev[toothNum] };
      if (currentTool === 'extraction' || currentTool === 'crown' || currentTool === 'implant') {
        t.status = t.status === currentTool ? 'healthy' : currentTool;
      } else {
        const surfaces = { ...t.surfaces };
        surfaces[surface] = surfaces[surface] === currentTool ? 'healthy' : currentTool;
        t.surfaces = surfaces;
      }
      t.history = [...t.history, { date: new Date().toISOString().split('T')[0], condition: currentTool, surface }];
      return { ...prev, [toothNum]: t };
    });
    setSelectedTooth(toothNum);
    setToothNotes(teeth[toothNum]?.notes || '');
  };

  const resetTooth = (num: number) => {
    setTeeth(prev => ({
      ...prev,
      [num]: { number: num, status: 'healthy', surfaces: defaultSurfaces(), notes: '', history: prev[num].history }
    }));
    setToothNotes('');
  };

  const resetAll = () => {
    setTeeth(createInitialTeeth());
    setSelectedTooth(null);
    setToothNotes('');
  };

  const saveNotes = (num: number, notes: string) => {
    setTeeth(prev => ({ ...prev, [num]: { ...prev[num], notes } }));
  };

  const tooth = selectedTooth ? teeth[selectedTooth] : null;

  const conditionCounts = useMemo(() => {
    return Object.values(teeth).reduce((acc, t) => {
      if (t.status !== 'healthy') acc[t.status] = (acc[t.status] || 0) + 1;
      Object.values(t.surfaces).forEach(s => {
        if (s !== 'healthy') acc[s] = (acc[s] || 0) + 1;
      });
      return acc;
    }, {} as Record<string, number>);
  }, [teeth]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Odontograma Digital</h1>
          <p className="text-slate-500">Vista clásica — Diagrama dental interactivo por superficies</p>
        </div>
        <div className="flex gap-2">
          <button onClick={resetAll} className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-medium transition-colors text-sm">
            <RotateCcw className="w-4 h-4" /> Resetear
          </button>
          <button onClick={exportPDF} className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200 text-sm">
            <Download className="w-4 h-4" /> Exportar PDF
          </button>
        </div>
      </div>

      {/* Patient Selector */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-3 flex-1">
            <UserCircle className="w-5 h-5 text-brand-500 shrink-0" />
            <select
              value={selectedPatient}
              onChange={e => { setSelectedPatient(e.target.value); resetAll(); }}
              className="flex-1 px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>{p.firstName} {p.lastName} — {p.idNumber}</option>
              ))}
            </select>
          </div>
          {patient && (
            <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
              <span>Edad: {new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear()} años</span>
              <span>Última visita: {patient.lastVisit || 'N/A'}</span>
              {patient.allergies.length > 0 && (
                <span className="text-red-600 font-medium">⚠ Alergias: {patient.allergies.join(', ')}</span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Tool Palette */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <p className="text-sm font-medium text-slate-600 mb-3">🔧 Herramientas de marcado:</p>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(STATUS_COLORS) as ToothStatus[]).map(status => (
            <button
              key={status}
              onClick={() => setCurrentTool(status)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${
                currentTool === status
                  ? 'ring-2 ring-offset-2 ring-sky-500 shadow-lg scale-105 border-sky-300'
                  : 'hover:bg-slate-50 border-slate-200'
              }`}
              style={{
                backgroundColor: currentTool === status ? (STATUS_COLORS[status] === '#FFFFFF' ? '#f8fafc' : STATUS_COLORS[status] + '15') : 'white',
                color: STATUS_COLORS[status] === '#FFFFFF' ? '#64748b' : STATUS_COLORS[status]
              }}
            >
              <span className="text-base">{STATUS_ICONS[status]}</span>
              <span className="w-3 h-3 rounded-full border border-white shadow-sm" style={{ backgroundColor: STATUS_COLORS[status] === '#FFFFFF' ? '#e2e8f0' : STATUS_COLORS[status] }} />
              {STATUS_LABELS[status]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Classic Odontogram */}
        <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200 p-6">
          {/* Upper Arch */}
          <div className="text-center mb-4">
            <span className="inline-block px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-bold tracking-wider uppercase">
              Arcada Superior
            </span>
          </div>

          <div className="flex justify-center gap-1 sm:gap-1.5 mb-2 flex-wrap">
            {UPPER_TEETH.map((num, idx) => (
              <ClassicTooth
                key={num}
                tooth={teeth[num]}
                isSelected={selectedTooth === num}
                onSurfaceClick={(surface) => handleSurfaceClick(num, surface)}
                showDivider={idx === 7}
              />
            ))}
          </div>

          {/* Number labels */}
          <div className="flex justify-center gap-1 sm:gap-1.5 mb-6 flex-wrap">
            {UPPER_TEETH.map((num, idx) => (
              <div key={num} className={`w-10 sm:w-12 text-center ${idx === 7 ? 'ml-4' : ''}`}>
                <span className={`text-[10px] font-bold ${selectedTooth === num ? 'text-sky-600' : 'text-slate-400'}`}>{num}</span>
              </div>
            ))}
          </div>

          {/* Divider */}
          <div className="relative my-4">
            <div className="border-t-2 border-dashed border-slate-200" />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <span className="inline-block px-4 py-1 bg-white rounded-full text-[10px] font-bold text-slate-400 tracking-wider border border-slate-200">
                LÍNEA MEDIA
              </span>
            </div>
          </div>

          {/* Number labels lower */}
          <div className="flex justify-center gap-1 sm:gap-1.5 mt-6 mb-2 flex-wrap">
            {LOWER_TEETH.map((num, idx) => (
              <div key={num} className={`w-10 sm:w-12 text-center ${idx === 7 ? 'ml-4' : ''}`}>
                <span className={`text-[10px] font-bold ${selectedTooth === num ? 'text-sky-600' : 'text-slate-400'}`}>{num}</span>
              </div>
            ))}
          </div>

          {/* Lower Arch */}
          <div className="flex justify-center gap-1 sm:gap-1.5 mb-4 flex-wrap">
            {LOWER_TEETH.map((num, idx) => (
              <ClassicTooth
                key={num}
                tooth={teeth[num]}
                isSelected={selectedTooth === num}
                onSurfaceClick={(surface) => handleSurfaceClick(num, surface)}
                showDivider={idx === 7}
              />
            ))}
          </div>

          <div className="text-center mt-4">
            <span className="inline-block px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-bold tracking-wider uppercase">
              Arcada Inferior
            </span>
          </div>

          {/* Legend */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <div className="flex flex-wrap gap-3 justify-center">
              {(Object.keys(STATUS_COLORS) as ToothStatus[]).map(s => (
                <span key={s} className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className="w-3 h-3 rounded border border-slate-200 shadow-sm"
                    style={{ backgroundColor: STATUS_COLORS[s] === '#FFFFFF' ? '#f8fafc' : STATUS_COLORS[s] }} />
                  <span className="font-medium">{STATUS_LABELS[s]}</span>
                  {conditionCounts[s] ? <span className="text-slate-400">({conditionCounts[s]})</span> : null}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Detail Panel */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Info className="w-5 h-5 text-sky-500" /> Detalle del Diente
            </h3>
            {tooth ? (
              <div className="space-y-4">
                <div className="text-center p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200">
                  {/* Classic tooth preview - big */}
                  <div className="mx-auto mb-3" style={{ width: 100, height: 100 }}>
                    <ClassicToothBig tooth={tooth} />
                  </div>
                  <p className="text-3xl font-black text-slate-800">#{tooth.number}</p>
                  <p className="text-sm text-slate-500 mt-1">{getToothName(tooth.number)}</p>
                  <p className="text-xs mt-2 font-medium" style={{
                    color: tooth.status !== 'healthy' ? STATUS_COLORS[tooth.status] : '#10b981'
                  }}>
                    {tooth.status !== 'healthy' ? `⚠ ${STATUS_LABELS[tooth.status]}` : '✓ Estado general: Sano'}
                  </p>
                </div>

                {/* Surfaces */}
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-2">Superficies:</p>
                  <div className="space-y-1.5">
                    {([
                      ['top', 'Oclusal / Incisal'],
                      ['right', 'Distal'],
                      ['bottom', 'Cervical / Gingival'],
                      ['left', 'Mesial'],
                      ['center', 'Centro / Palatina'],
                    ] as const).map(([s, label]) => (
                      <div key={s} className="flex items-center justify-between text-sm p-2 rounded-lg hover:bg-slate-50">
                        <span className="text-slate-500 text-xs">{label}</span>
                        <span className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full border border-slate-200"
                            style={{ backgroundColor: STATUS_COLORS[tooth.surfaces[s]] === '#FFFFFF' ? '#e2e8f0' : STATUS_COLORS[tooth.surfaces[s]] }} />
                          <span className={`text-xs font-semibold ${tooth.surfaces[s] !== 'healthy' ? '' : 'text-slate-400'}`}
                            style={{ color: tooth.surfaces[s] !== 'healthy' ? STATUS_COLORS[tooth.surfaces[s]] : undefined }}>
                            {STATUS_LABELS[tooth.surfaces[s]]}
                          </span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Notas clínicas:</p>
                  <textarea
                    value={toothNotes}
                    onChange={e => setToothNotes(e.target.value)}
                    onBlur={() => selectedTooth && saveNotes(selectedTooth, toothNotes)}
                    placeholder="Agregar notas sobre este diente..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none h-20"
                  />
                </div>

                <button
                  onClick={() => resetTooth(tooth.number)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" /> Resetear Diente
                </button>
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="w-20 h-20 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-slate-100">
                  <span className="text-4xl">🦷</span>
                </div>
                <p className="text-slate-500 text-sm font-medium">Seleccione un diente</p>
                <p className="text-slate-400 text-xs mt-1">Haga clic en cualquier superficie del diagrama</p>
              </div>
            )}
          </div>

          {/* History */}
          {tooth && tooth.history.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <button onClick={() => setShowHistory(!showHistory)} className="w-full flex items-center justify-between">
                <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                  <History className="w-4 h-4 text-violet-500" /> Historial #{tooth.number}
                </h4>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
              </button>
              {showHistory && (
                <div className="mt-3 space-y-2">
                  {tooth.history.map((h, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 text-xs">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: STATUS_COLORS[h.condition] === '#FFFFFF' ? '#94a3b8' : STATUS_COLORS[h.condition] }} />
                      <span className="text-slate-400 font-mono">{h.date}</span>
                      <span className="font-medium" style={{ color: STATUS_COLORS[h.condition] === '#FFFFFF' ? '#64748b' : STATUS_COLORS[h.condition] }}>
                        {STATUS_LABELS[h.condition]}
                      </span>
                      {h.surface && <span className="text-slate-400">({h.surface})</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Stats */}
          <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-2xl border border-sky-200 p-5">
            <h4 className="text-sm font-semibold text-sky-800 mb-3">📊 Resumen</h4>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-slate-800">32</p>
                <p className="text-[10px] text-slate-500">Total</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-emerald-600">
                  {32 - Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy')).length}
                </p>
                <p className="text-[10px] text-slate-500">Sanos</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-red-500">
                  {Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy')).length}
                </p>
                <p className="text-[10px] text-slate-500">Con condición</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-slate-500">
                  {Object.values(teeth).filter(t => t.status === 'extraction').length}
                </p>
                <p className="text-[10px] text-slate-500">Extraídos</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ====================================================================
   CLASSIC TOOTH - Square surface diagram (traditional dental chart)
   ==================================================================== */

function ClassicTooth({ tooth, isSelected, onSurfaceClick, showDivider }: {
  tooth: ToothData;
  isSelected: boolean;
  onSurfaceClick: (surface: keyof ToothData['surfaces']) => void;
  showDivider: boolean;
}) {
  const isExtracted = tooth.status === 'extraction';
  const isCrown = tooth.status === 'crown';
  const isImplant = tooth.status === 'implant';

  const getSurfaceColor = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#f8fafc' : STATUS_COLORS[status];
  };

  const getSurfaceBorder = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#cbd5e1' : STATUS_COLORS[status];
  };

  const size = 40;
  const inner = 14;
  const offset = (size - inner) / 2;

  return (
    <div className={`flex flex-col items-center ${showDivider ? 'ml-4' : ''}`}>
      <div
        className={`relative cursor-pointer transition-all ${
          isSelected ? 'scale-110 ring-2 ring-sky-400 ring-offset-2 rounded-lg z-10' : 'hover:scale-105'
        }`}
      >
        <svg width={size + 4} height={size + 4} viewBox={`-2 -2 ${size + 4} ${size + 4}`}>
          {isExtracted ? (
            <g>
              <rect x="0" y="0" width={size} height={size} rx="4" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1" />
              <line x1="4" y1="4" x2={size - 4} y2={size - 4} stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round" />
              <line x1={size - 4} y1="4" x2="4" y2={size - 4} stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round" />
              <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#EF4444" fontSize="6" fontWeight="bold" opacity="0.6">EXT</text>
            </g>
          ) : isCrown ? (
            <g>
              <rect x="0" y="0" width={size} height={size} rx="4" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
              <circle cx={size / 2} cy={size / 2} r={inner / 2 + 2} fill="#FCD34D" stroke="#F59E0B" strokeWidth="1" />
              <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#92400E" fontSize="12" fontWeight="bold">♛</text>
            </g>
          ) : isImplant ? (
            <g>
              <rect x="0" y="0" width={size} height={size} rx="4" fill="#ECFDF5" stroke="#10B981" strokeWidth="1.5" />
              <circle cx={size / 2} cy={size / 2} r={inner / 2 + 2} fill="#D1FAE5" stroke="#10B981" strokeWidth="1" />
              <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#059669" fontSize="10" fontWeight="bold">⬡</text>
            </g>
          ) : (
            <g>
              {/* Outer box */}
              <rect x="0" y="0" width={size} height={size} rx="3" fill="white" stroke="#e2e8f0" strokeWidth="0.5" />

              {/* Top surface (triangle) */}
              <path
                d={`M0,0 L${size},0 L${offset + inner},${offset} L${offset},${offset} Z`}
                fill={getSurfaceColor('top')}
                stroke={getSurfaceBorder('top')}
                strokeWidth="0.8"
                className="cursor-pointer hover:brightness-90 transition-all"
                onClick={(e) => { e.stopPropagation(); onSurfaceClick('top'); }}
              />

              {/* Bottom surface (triangle) */}
              <path
                d={`M0,${size} L${offset},${offset + inner} L${offset + inner},${offset + inner} L${size},${size} Z`}
                fill={getSurfaceColor('bottom')}
                stroke={getSurfaceBorder('bottom')}
                strokeWidth="0.8"
                className="cursor-pointer hover:brightness-90 transition-all"
                onClick={(e) => { e.stopPropagation(); onSurfaceClick('bottom'); }}
              />

              {/* Left surface (triangle) */}
              <path
                d={`M0,0 L${offset},${offset} L${offset},${offset + inner} L0,${size} Z`}
                fill={getSurfaceColor('left')}
                stroke={getSurfaceBorder('left')}
                strokeWidth="0.8"
                className="cursor-pointer hover:brightness-90 transition-all"
                onClick={(e) => { e.stopPropagation(); onSurfaceClick('left'); }}
              />

              {/* Right surface (triangle) */}
              <path
                d={`M${size},0 L${offset + inner},${offset} L${offset + inner},${offset + inner} L${size},${size} Z`}
                fill={getSurfaceColor('right')}
                stroke={getSurfaceBorder('right')}
                strokeWidth="0.8"
                className="cursor-pointer hover:brightness-90 transition-all"
                onClick={(e) => { e.stopPropagation(); onSurfaceClick('right'); }}
              />

              {/* Center surface (square) */}
              <rect
                x={offset} y={offset}
                width={inner} height={inner}
                fill={getSurfaceColor('center')}
                stroke={getSurfaceBorder('center')}
                strokeWidth="0.8"
                rx="1"
                className="cursor-pointer hover:brightness-90 transition-all"
                onClick={(e) => { e.stopPropagation(); onSurfaceClick('center'); }}
              />
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}

/* Big preview for detail panel */
function ClassicToothBig({ tooth }: { tooth: ToothData }) {
  const isExtracted = tooth.status === 'extraction';
  const isCrown = tooth.status === 'crown';
  const isImplant = tooth.status === 'implant';

  const getSurfaceColor = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#f8fafc' : STATUS_COLORS[status];
  };

  const getSurfaceBorder = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#cbd5e1' : STATUS_COLORS[status];
  };

  const size = 90;
  const inner = 30;
  const offset = (size - inner) / 2;

  return (
    <svg width="100%" height="100%" viewBox={`-2 -2 ${size + 4} ${size + 4}`}>
      {isExtracted ? (
        <g>
          <rect x="0" y="0" width={size} height={size} rx="8" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="2" />
          <line x1="10" y1="10" x2={size - 10} y2={size - 10} stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />
          <line x1={size - 10} y1="10" x2="10" y2={size - 10} stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />
        </g>
      ) : isCrown ? (
        <g>
          <rect x="0" y="0" width={size} height={size} rx="8" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2" />
          <circle cx={size / 2} cy={size / 2} r={20} fill="#FCD34D" stroke="#F59E0B" strokeWidth="1.5" />
          <text x={size / 2} y={size / 2 + 2} textAnchor="middle" dominantBaseline="middle" fill="#92400E" fontSize="22" fontWeight="bold">♛</text>
        </g>
      ) : isImplant ? (
        <g>
          <rect x="0" y="0" width={size} height={size} rx="8" fill="#ECFDF5" stroke="#10B981" strokeWidth="2" />
          <circle cx={size / 2} cy={size / 2} r={20} fill="#D1FAE5" stroke="#10B981" strokeWidth="1.5" />
          <text x={size / 2} y={size / 2 + 2} textAnchor="middle" dominantBaseline="middle" fill="#059669" fontSize="18" fontWeight="bold">⬡</text>
        </g>
      ) : (
        <g>
          <rect x="0" y="0" width={size} height={size} rx="6" fill="white" stroke="#e2e8f0" strokeWidth="1" />
          <path d={`M0,0 L${size},0 L${offset + inner},${offset} L${offset},${offset} Z`}
            fill={getSurfaceColor('top')} stroke={getSurfaceBorder('top')} strokeWidth="1.2" />
          <path d={`M0,${size} L${offset},${offset + inner} L${offset + inner},${offset + inner} L${size},${size} Z`}
            fill={getSurfaceColor('bottom')} stroke={getSurfaceBorder('bottom')} strokeWidth="1.2" />
          <path d={`M0,0 L${offset},${offset} L${offset},${offset + inner} L0,${size} Z`}
            fill={getSurfaceColor('left')} stroke={getSurfaceBorder('left')} strokeWidth="1.2" />
          <path d={`M${size},0 L${offset + inner},${offset} L${offset + inner},${offset + inner} L${size},${size} Z`}
            fill={getSurfaceColor('right')} stroke={getSurfaceBorder('right')} strokeWidth="1.2" />
          <rect x={offset} y={offset} width={inner} height={inner}
            fill={getSurfaceColor('center')} stroke={getSurfaceBorder('center')} strokeWidth="1.2" rx="2" />
          {/* Surface labels */}
          <text x={size / 2} y={offset / 2 + 2} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="7" fontWeight="600">O</text>
          <text x={size / 2} y={size - offset / 2 + 2} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="7" fontWeight="600">C</text>
          <text x={offset / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="7" fontWeight="600">M</text>
          <text x={size - offset / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="7" fontWeight="600">D</text>
          <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="7" fontWeight="600">P</text>
        </g>
      )}
    </svg>
  );
}
