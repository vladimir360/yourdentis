import { useState } from 'react';
import { Eye, EyeOff, Lock, User, ArrowRight, ArrowLeft } from 'lucide-react';

export function LoginScreen({ onLogin, onBack }: { onLogin: () => void; onBack?: () => void }) {
  const [email, setEmail] = useState('admin@yourdentis.com');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-brand-950 to-slate-900 flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo & Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-brand-400 to-brand-600 rounded-2xl shadow-2xl shadow-brand-500/30 mb-6">
            <svg viewBox="0 0 40 40" className="w-10 h-10 text-white" fill="currentColor">
              <path d="M20 2C15 2 12 6 12 10c0 3 1 5 2 8l4 14c.5 2 1.5 3 2 3s1.5-1 2-3l4-14c1-3 2-5 2-8 0-4-3-8-8-8z"/>
              <path d="M14 10c0-3 2.5-6 6-6s6 3 6 6" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.5"/>
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">YourDentis</h1>
          <p className="text-brand-300 text-sm font-medium tracking-wide">Sistema de Gestión Odontológica SaaS</p>
          <p className="text-slate-500 text-xs mt-1 italic">"Tu sonrisa, nuestra tecnología"</p>
        </div>

        {/* Login Card */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-8 shadow-2xl">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-white">Iniciar Sesión</h2>
            <p className="text-sm text-slate-400 mt-1">Accede a tu panel de gestión dental</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Correo electrónico</label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all"
                  placeholder="correo@yourdentis.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-10 pr-12 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 text-slate-400 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-500 bg-white/10 text-brand-500 focus:ring-brand-500" />
                Recordarme
              </label>
              <button type="button" className="text-brand-400 hover:text-brand-300 font-medium transition-colors">
                ¿Olvidaste tu contraseña?
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-600 hover:to-brand-700 text-white py-3 rounded-xl font-semibold text-sm transition-all shadow-lg shadow-brand-500/30 disabled:opacity-70"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                    <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" className="opacity-75" />
                  </svg>
                  Iniciando sesión...
                </>
              ) : (
                <>
                  Iniciar Sesión <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-6 p-3 rounded-xl bg-brand-500/10 border border-brand-500/20">
            <p className="text-xs text-brand-300 font-medium mb-1">🔐 Credenciales de demostración:</p>
            <p className="text-xs text-slate-400">Email: admin@yourdentis.com</p>
            <p className="text-xs text-slate-400">Contraseña: admin123</p>
          </div>
        </div>

        {/* Back to landing */}
        {onBack && (
          <div className="text-center mt-6">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 text-sm text-brand-400 hover:text-brand-300 font-medium transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Volver a la página principal
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-xs text-slate-500">
            © 2025 YourDentis. Todos los derechos reservados.
          </p>
          <p className="text-[10px] text-slate-600 mt-1">
            Encriptación AES-256 · HIPAA Compliant · SOC 2 Type II
          </p>
        </div>
      </div>
    </div>
  );
}
