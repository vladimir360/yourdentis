import { useState, useEffect } from 'react';
import {
  Calendar, Users, Shield, BarChart3, Package, DollarSign,
  Star, Phone, Mail, MapPin, Clock, CheckCircle,
  Zap, Globe, ArrowRight, Menu, X, Heart, Smartphone,
  MessageCircle, TrendingUp, Lock,
  CircleDot, FileText, Bell, Cpu
} from 'lucide-react';

export function LandingPage({ onGoToLogin }: { onGoToLogin: () => void }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);
  const [formData, setFormData] = useState({ nombre: '', apellido: '', email: '', telefono: '', clinica: '', mensaje: '' });
  const [formSent, setFormSent] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature(prev => (prev + 1) % features.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSent(true);
    setTimeout(() => setFormSent(false), 4000);
    setFormData({ nombre: '', apellido: '', email: '', telefono: '', clinica: '', mensaje: '' });
  };

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* ========== NAVBAR ========== */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-xl shadow-lg shadow-slate-200/50 border-b border-slate-100' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-blue-700 rounded-xl flex items-center justify-center shadow-lg shadow-sky-200">
                <svg viewBox="0 0 40 40" className="w-6 h-6 text-white" fill="currentColor">
                  <path d="M20 2C15 2 12 6 12 10c0 3 1 5 2 8l4 14c.5 2 1.5 3 2 3s1.5-1 2-3l4-14c1-3 2-5 2-8 0-4-3-8-8-8z"/>
                </svg>
              </div>
              <div>
                <h1 className={`text-xl font-bold ${scrolled ? 'text-slate-800' : 'text-white'}`}>YourDentis</h1>
                <p className={`text-[9px] font-medium tracking-wider uppercase ${scrolled ? 'text-slate-400' : 'text-sky-200'}`}>Gestión Dental SaaS</p>
              </div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-8">
              {[
                { label: 'Inicio', id: 'hero' },
                { label: 'Características', id: 'features' },
                { label: 'Ventajas', id: 'advantages' },
                { label: 'Módulos', id: 'modules' },
                { label: 'Precios', id: 'pricing' },
                { label: 'Contacto', id: 'contact' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors hover:text-sky-500 ${scrolled ? 'text-slate-600' : 'text-white/90 hover:text-white'}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="hidden lg:flex items-center gap-3">
              <button
                onClick={onGoToLogin}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${scrolled ? 'text-slate-600 hover:text-sky-600' : 'text-white/90 hover:text-white'}`}
              >
                Iniciar Sesión
              </button>
              <button
                onClick={onGoToLogin}
                className="px-5 py-2.5 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-sky-500/30 hover:shadow-sky-500/50"
              >
                Prueba Gratis
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-2 rounded-lg ${scrolled ? 'text-slate-600' : 'text-white'}`}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-slate-100 shadow-xl animate-slide-in">
            <div className="px-4 py-4 space-y-1">
              {['Inicio', 'Características', 'Ventajas', 'Módulos', 'Precios', 'Contacto'].map(label => (
                <button
                  key={label}
                  onClick={() => scrollToSection(label.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''))}
                  className="w-full text-left px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  {label}
                </button>
              ))}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <button onClick={onGoToLogin} className="w-full px-4 py-3 rounded-xl text-sm font-medium text-sky-600 hover:bg-sky-50 transition-colors">
                  Iniciar Sesión
                </button>
                <button
                  onClick={() => { setMobileMenuOpen(false); onGoToLogin(); }}
                  className="block w-full px-4 py-3 rounded-xl bg-sky-500 text-white text-sm font-semibold text-center"
                >
                  Prueba Gratis
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* ========== HERO SECTION ========== */}
      <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-sky-950 to-blue-950" />
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
        {/* Floating orbs */}
        <div className="absolute top-20 right-10 w-72 h-72 bg-sky-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-sky-400/5 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 sm:pt-32 sm:pb-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-lg rounded-full border border-white/20 mb-6">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-xs text-sky-200 font-medium">Software #1 en gestión odontológica</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-tight mb-6">
                Tu sonrisa,{' '}
                <span className="bg-gradient-to-r from-sky-400 to-cyan-300 bg-clip-text text-transparent">
                  nuestra tecnología
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-slate-300 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                <strong className="text-white">YourDentis</strong> es el sistema integral de gestión para clínicas odontológicas más completo del mercado. Moderno, seguro y preparado para funcionar como SaaS multi-clínica.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
                <button
                  onClick={onGoToLogin}
                  className="group flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white rounded-2xl font-bold text-lg transition-all shadow-xl shadow-sky-500/30 hover:shadow-sky-400/50 hover:scale-105"
                >
                  Comenzar Prueba Gratis
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button
                  onClick={() => scrollToSection('features')}
                  className="flex items-center justify-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-lg hover:bg-white/20 text-white rounded-2xl font-medium text-lg border border-white/20 transition-all"
                >
                  Ver Características
                </button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 max-w-md mx-auto lg:mx-0">
                {[
                  { value: '500+', label: 'Clínicas activas' },
                  { value: '99.9%', label: 'Uptime garantizado' },
                  { value: '24/7', label: 'Soporte técnico' },
                ].map(stat => (
                  <div key={stat.label} className="text-center lg:text-left">
                    <p className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</p>
                    <p className="text-xs text-slate-400">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Visual - Dashboard Preview */}
            <div className="hidden lg:block relative">
              <div className="relative bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-6 shadow-2xl transform rotate-1 hover:rotate-0 transition-transform duration-500">
                <div className="bg-slate-900 rounded-2xl p-4 overflow-hidden">
                  {/* Mock Dashboard */}
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="text-xs text-slate-500 ml-2">YourDentis — Dashboard</span>
                  </div>
                  <div className="space-y-3">
                    <div className="grid grid-cols-4 gap-2">
                      {['Citas Hoy', 'Pacientes', 'Ingresos', 'Pendiente'].map(label => (
                        <div key={label} className="bg-slate-800 rounded-lg p-3">
                          <div className="w-8 h-2 bg-sky-500/50 rounded mb-2" />
                          <div className="w-12 h-3 bg-white/20 rounded mb-1" />
                          <div className="w-16 h-2 bg-slate-700 rounded" />
                        </div>
                      ))}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2 bg-slate-800 rounded-lg p-3 h-32">
                        <div className="w-20 h-2 bg-sky-500/50 rounded mb-3" />
                        <div className="flex items-end gap-1 h-20">
                          {[40, 60, 45, 70, 55, 80, 65].map((h, i) => (
                            <div key={i} className="flex-1 bg-gradient-to-t from-sky-500 to-sky-400 rounded-sm opacity-70" style={{ height: `${h}%` }} />
                          ))}
                        </div>
                      </div>
                      <div className="bg-slate-800 rounded-lg p-3 h-32 flex items-center justify-center">
                        <div className="w-20 h-20 rounded-full border-4 border-sky-500/50 border-t-sky-400 relative flex items-center justify-center">
                          <span className="text-xs text-white/70 font-bold">85%</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-slate-800 rounded-lg p-3">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="flex items-center gap-2 py-1.5">
                          <div className="w-6 h-6 rounded-md bg-sky-500/30" />
                          <div className="flex-1 h-2 bg-slate-700 rounded" />
                          <div className="w-12 h-2 bg-emerald-500/30 rounded" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              {/* Floating badges */}
              <div className="absolute -left-8 top-1/4 bg-white rounded-xl shadow-xl p-3 flex items-center gap-2 animate-bounce" style={{ animationDuration: '3s' }}>
                <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-800">Cita confirmada</p>
                  <p className="text-[10px] text-slate-400">Hace 2 min</p>
                </div>
              </div>
              <div className="absolute -right-4 bottom-1/4 bg-white rounded-xl shadow-xl p-3 flex items-center gap-2 animate-bounce" style={{ animationDuration: '4s', animationDelay: '1s' }}>
                <div className="w-8 h-8 bg-sky-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-4 h-4 text-sky-600" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-800">Pago recibido</p>
                  <p className="text-[10px] text-slate-400">$2,500.00</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50">
          <span className="text-xs">Desliza para explorar</span>
          <div className="w-5 h-8 border-2 border-white/30 rounded-full flex justify-center pt-1.5">
            <div className="w-1 h-2 bg-white/60 rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* ========== TRUSTED BY / SOCIAL PROOF ========== */}
      <section className="py-12 bg-slate-50 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-slate-500 mb-8">Confianza de clínicas en toda la República Dominicana y Latinoamérica</p>
          <div className="flex flex-wrap justify-center items-center gap-8 sm:gap-12 opacity-50">
            {['Clínica Dental Sonrisa', 'OdontoCare RD', 'DentalPlus SC', 'Centro Dental Familiar', 'SmileLab Clinic', 'Dental Excellence'].map(name => (
              <span key={name} className="text-sm sm:text-base font-bold text-slate-400 tracking-wide">{name}</span>
            ))}
          </div>
        </div>
      </section>

      {/* ========== WHAT IS YOURDENTIS ========== */}
      <section className="py-20 sm:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-sky-100 text-sky-700 text-xs font-semibold rounded-full mb-4">¿QUÉ ES YOURDENTIS?</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
              El sistema de gestión odontológica más completo del mercado
            </h2>
            <p className="text-lg text-slate-500 leading-relaxed">
              YourDentis es una plataforma SaaS profesional diseñada para transformar la manera en que las clínicas dentales gestionan sus operaciones. Desde la agenda de citas hasta la facturación con cuotas, todo en un solo lugar.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Globe className="w-8 h-8" />,
                title: 'Multi-Clínica SaaS',
                desc: 'Gestiona múltiples sedes desde una sola plataforma. Cada clínica con su propia configuración, equipo y datos aislados.',
                color: 'sky'
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: 'Seguridad de Nivel Empresarial',
                desc: 'Encriptación AES-256, backups automáticos, cumplimiento de normativas de protección de datos y autenticación de dos factores.',
                color: 'emerald'
              },
              {
                icon: <Smartphone className="w-8 h-8" />,
                title: '100% Responsive',
                desc: 'Accede desde cualquier dispositivo: computadora, tablet o celular. Interfaz adaptable y moderna con diseño profesional.',
                color: 'violet'
              },
            ].map(item => (
              <div key={item.title} className="group bg-white rounded-3xl border border-slate-200 p-8 hover:shadow-2xl hover:shadow-slate-200/50 hover:border-slate-300 transition-all duration-500 hover:-translate-y-1">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${
                  item.color === 'sky' ? 'bg-sky-100 text-sky-600 group-hover:bg-sky-500 group-hover:text-white' :
                  item.color === 'emerald' ? 'bg-emerald-100 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white' :
                  'bg-violet-100 text-violet-600 group-hover:bg-violet-500 group-hover:text-white'
                } transition-all duration-500`}>
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{item.title}</h3>
                <p className="text-slate-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FEATURES SECTION ========== */}
      <section id="features" className="py-20 sm:py-28 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-sky-100 text-sky-700 text-xs font-semibold rounded-full mb-4">CARACTERÍSTICAS</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
              Todo lo que necesitas para gestionar tu clínica
            </h2>
            <p className="text-lg text-slate-500">
              Módulos integrados diseñados por expertos en odontología y tecnología
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Feature List */}
            <div className="space-y-3">
              {features.map((feature, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveFeature(idx)}
                  className={`w-full text-left p-5 rounded-2xl transition-all duration-300 ${
                    activeFeature === idx
                      ? 'bg-white shadow-xl shadow-slate-200/50 border border-sky-200'
                      : 'hover:bg-white/50 border border-transparent'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                      activeFeature === idx ? 'bg-sky-500 text-white shadow-lg shadow-sky-200' : 'bg-slate-100 text-slate-400'
                    }`}>
                      {feature.icon}
                    </div>
                    <div>
                      <h3 className={`font-semibold mb-1 ${activeFeature === idx ? 'text-sky-700' : 'text-slate-700'}`}>{feature.title}</h3>
                      {activeFeature === idx && (
                        <p className="text-sm text-slate-500 leading-relaxed animate-fade-in">{feature.description}</p>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Feature Visual */}
            <div className="relative">
              <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-xl">
                <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mb-6 bg-gradient-to-br from-sky-400 to-blue-600 text-white shadow-lg shadow-sky-200`}>
                  {features[activeFeature].icon}
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">{features[activeFeature].title}</h3>
                <p className="text-slate-500 leading-relaxed mb-6">{features[activeFeature].description}</p>
                <ul className="space-y-3">
                  {features[activeFeature].details.map((detail, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm text-slate-600">
                      <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== ADVANTAGES SECTION ========== */}
      <section id="advantages" className="py-20 sm:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full mb-4">VENTAJAS</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
              ¿Por qué elegir YourDentis?
            </h2>
            <p className="text-lg text-slate-500">
              Ventajas competitivas que marcan la diferencia frente a otros sistemas
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {advantages.map((adv, idx) => (
              <div key={idx} className="group relative bg-gradient-to-br from-slate-50 to-white rounded-2xl border border-slate-200 p-6 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-500 hover:-translate-y-1 overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-sky-100 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative">
                  <div className="text-3xl mb-4">{adv.emoji}</div>
                  <h3 className="text-lg font-bold text-slate-800 mb-2">{adv.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{adv.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== MODULES SECTION ========== */}
      <section id="modules" className="py-20 sm:py-28 bg-gradient-to-br from-slate-900 via-sky-950 to-blue-950 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-white/10 text-sky-300 text-xs font-semibold rounded-full mb-4 border border-white/20">MÓDULOS</span>
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              9 módulos integrados en una sola plataforma
            </h2>
            <p className="text-lg text-slate-400">
              Cada módulo diseñado al nivel de soluciones como Dentrix, Open Dental y CareStack
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {modules.map((mod, idx) => (
              <div key={idx} className="bg-white/5 backdrop-blur-lg rounded-2xl border border-white/10 p-6 hover:bg-white/10 hover:border-white/20 transition-all group">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    {mod.icon}
                  </div>
                  <h3 className="font-bold text-white">{mod.title}</h3>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">{mod.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== AI SECTION ========== */}
      <section className="py-20 sm:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block px-4 py-1.5 bg-violet-100 text-violet-700 text-xs font-semibold rounded-full mb-4">INTELIGENCIA ARTIFICIAL</span>
              <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
                Potenciado con Inteligencia Artificial
              </h2>
              <p className="text-lg text-slate-500 mb-8 leading-relaxed">
                YourDentis integra funcionalidades avanzadas de IA para ayudarte a tomar mejores decisiones clínicas y administrativas.
              </p>
              <div className="space-y-4">
                {[
                  { icon: <TrendingUp className="w-5 h-5" />, title: 'Predicción de ausencias', desc: 'Anticipa no-shows basándose en patrones históricos del paciente' },
                  { icon: <Bell className="w-5 h-5" />, title: 'Recordatorios inteligentes', desc: 'Envío automático optimizado por canal preferido del paciente' },
                  { icon: <BarChart3 className="w-5 h-5" />, title: 'Análisis predictivo de ingresos', desc: 'Proyecciones financieras basadas en tendencias y estacionalidad' },
                  { icon: <Heart className="w-5 h-5" />, title: 'Seguimiento clínico automático', desc: 'Alertas inteligentes para pacientes que requieren control' },
                ].map(item => (
                  <div key={item.title} className="flex items-start gap-4 p-4 rounded-xl hover:bg-violet-50 transition-colors">
                    <div className="w-10 h-10 rounded-xl bg-violet-100 text-violet-600 flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">{item.title}</h4>
                      <p className="text-sm text-slate-500">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-violet-500 to-purple-700 rounded-3xl p-8 text-white shadow-2xl shadow-violet-500/20">
                <div className="flex items-center gap-3 mb-6">
                  <Cpu className="w-8 h-8" />
                  <h3 className="text-xl font-bold">YourDentis AI</h3>
                </div>
                <div className="space-y-4">
                  <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                    <p className="text-sm font-medium mb-1">📊 Análisis de hoy</p>
                    <p className="text-xs text-white/80">3 pacientes con alta probabilidad de no-show. Se recomienda confirmar por WhatsApp.</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                    <p className="text-sm font-medium mb-1">💰 Proyección semanal</p>
                    <p className="text-xs text-white/80">Ingresos estimados: RD$185,000. Tendencia +12% vs semana anterior.</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                    <p className="text-sm font-medium mb-1">🔔 Seguimiento requerido</p>
                    <p className="text-xs text-white/80">5 pacientes sin visita en 60+ días. Campaña de reactivación sugerida.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== PRICING SECTION ========== */}
      <section id="pricing" className="py-20 sm:py-28 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-sky-100 text-sky-700 text-xs font-semibold rounded-full mb-4">PRECIOS</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
              Planes flexibles para cada clínica
            </h2>
            <p className="text-lg text-slate-500">
              Sin contratos a largo plazo. Cancela cuando quieras.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, idx) => (
              <div key={idx} className={`relative bg-white rounded-3xl border-2 p-8 ${plan.popular ? 'border-sky-500 shadow-xl shadow-sky-200/30 scale-105 z-10' : 'border-slate-200'} transition-all hover:shadow-xl`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-sky-500 to-blue-600 text-white text-xs font-bold rounded-full shadow-lg">
                    MÁS POPULAR
                  </div>
                )}
                <div className="text-center mb-8">
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{plan.name}</h3>
                  <p className="text-sm text-slate-500 mb-4">{plan.desc}</p>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-black text-slate-800">{plan.price}</span>
                    {plan.period && <span className="text-slate-400 text-sm">{plan.period}</span>}
                  </div>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm text-slate-600">
                      <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={onGoToLogin}
                  className={`block w-full py-3 rounded-xl font-semibold text-sm transition-all text-center ${
                    plan.popular
                      ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-lg shadow-sky-200 hover:shadow-sky-300'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== TESTIMONIALS ========== */}
      <section className="py-20 sm:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 bg-amber-100 text-amber-700 text-xs font-semibold rounded-full mb-4">TESTIMONIOS</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
              Lo que dicen nuestros clientes
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t, idx) => (
              <div key={idx} className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-slate-600 mb-6 leading-relaxed italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center text-white font-bold text-sm">
                    {t.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FREE TRIAL SECTION ========== */}
      <section id="free-trial" className="py-20 sm:py-28 bg-gradient-to-br from-sky-500 via-blue-600 to-blue-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur rounded-full border border-white/30 mb-8">
            <Zap className="w-4 h-4 text-yellow-300" />
            <span className="text-sm text-white font-medium">Sin tarjeta de crédito requerida</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-white mb-6">
            Comienza tu prueba gratis hoy
          </h2>
          <p className="text-xl text-sky-100 mb-10 max-w-2xl mx-auto">
            Accede a todas las funcionalidades de YourDentis durante 14 días completamente gratis. Sin compromisos ni tarjeta de crédito.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button
              onClick={onGoToLogin}
              className="group flex items-center justify-center gap-3 px-10 py-5 bg-white text-sky-700 hover:bg-sky-50 rounded-2xl font-bold text-lg transition-all shadow-2xl shadow-black/20 hover:scale-105"
            >
              🦷 Comenzar Ahora — Es Gratis
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-sm text-sky-200">
            <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> 14 días gratis</span>
            <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Todas las funciones</span>
            <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Soporte incluido</span>
            <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Datos seguros</span>
          </div>
        </div>
      </section>

      {/* ========== CONTACT SECTION ========== */}
      <section id="contact" className="py-20 sm:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <span className="inline-block px-4 py-1.5 bg-sky-100 text-sky-700 text-xs font-semibold rounded-full mb-4">CONTACTO</span>
              <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-6">
                ¿Tienes preguntas? Contáctanos
              </h2>
              <p className="text-lg text-slate-500 mb-10 leading-relaxed">
                Nuestro equipo está listo para ayudarte a transformar la gestión de tu clínica dental. Escríbenos o llámanos.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-sky-200 hover:bg-sky-50/50 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Teléfono</h4>
                    <a href="tel:+18296303341" className="text-sky-600 font-medium hover:text-sky-700 transition-colors text-lg">+1 (829) 630‑3341</a>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/50 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">WhatsApp</h4>
                    <a href="https://wa.me/18296303341" target="_blank" rel="noopener noreferrer" className="text-emerald-600 font-medium hover:text-emerald-700 transition-colors text-lg">+1 (829) 630‑3341</a>
                    <p className="text-sm text-slate-400 mt-0.5">Respuesta rápida por WhatsApp</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-violet-200 hover:bg-violet-50/50 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-violet-100 text-violet-600 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Email</h4>
                    <a href="mailto:info@yourdentis.com" className="text-violet-600 font-medium hover:text-violet-700 transition-colors text-lg">info@yourdentis.com</a>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-amber-200 hover:bg-amber-50/50 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Ubicación</h4>
                    <p className="text-slate-700 font-medium">C/3ra número 3, Madrevieja Sur</p>
                    <p className="text-slate-500">San Cristóbal, República Dominicana</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="w-12 h-12 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Horario de Atención</h4>
                    <p className="text-slate-600">Lunes a Viernes: 8:00 AM - 6:00 PM</p>
                    <p className="text-slate-600">Sábados: 8:00 AM - 1:00 PM</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Envíanos un mensaje</h3>
              
              {formSent && (
                <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                  <p className="text-sm text-emerald-700 font-medium">¡Mensaje enviado correctamente! Te responderemos pronto.</p>
                </div>
              )}

              <form className="space-y-5" onSubmit={handleFormSubmit}>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Nombre</label>
                    <input type="text" placeholder="Tu nombre" value={formData.nombre} onChange={e => setFormData(p => ({ ...p, nombre: e.target.value }))} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Apellido</label>
                    <input type="text" placeholder="Tu apellido" value={formData.apellido} onChange={e => setFormData(p => ({ ...p, apellido: e.target.value }))} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <input type="email" placeholder="correo@ejemplo.com" value={formData.email} onChange={e => setFormData(p => ({ ...p, email: e.target.value }))} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Teléfono</label>
                  <input type="tel" placeholder="+1 829-000-0000" value={formData.telefono} onChange={e => setFormData(p => ({ ...p, telefono: e.target.value }))} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Nombre de tu clínica</label>
                  <input type="text" placeholder="Clínica Dental..." value={formData.clinica} onChange={e => setFormData(p => ({ ...p, clinica: e.target.value }))} className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Mensaje</label>
                  <textarea rows={4} placeholder="¿En qué podemos ayudarte?" value={formData.mensaje} onChange={e => setFormData(p => ({ ...p, mensaje: e.target.value }))} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white resize-none" />
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white rounded-xl font-semibold text-sm transition-all shadow-lg shadow-sky-200 flex items-center justify-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  Enviar Mensaje
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* ========== FOOTER ========== */}
      <footer className="bg-slate-900 text-white pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-blue-700 rounded-xl flex items-center justify-center">
                  <svg viewBox="0 0 40 40" className="w-6 h-6 text-white" fill="currentColor">
                    <path d="M20 2C15 2 12 6 12 10c0 3 1 5 2 8l4 14c.5 2 1.5 3 2 3s1.5-1 2-3l4-14c1-3 2-5 2-8 0-4-3-8-8-8z"/>
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold">YourDentis</h3>
                  <p className="text-[10px] text-slate-400 tracking-wider uppercase">Gestión Dental SaaS</p>
                </div>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed mb-4">
                Tu sonrisa, nuestra tecnología. La plataforma de gestión odontológica más completa del Caribe y Latinoamérica.
              </p>
              <div className="flex items-center gap-4">
                <a href="https://wa.me/18296303341" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center hover:bg-emerald-500 transition-colors">
                  <MessageCircle className="w-4 h-4" />
                </a>
                <a href="tel:+18296303341" className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center hover:bg-sky-500 transition-colors">
                  <Phone className="w-4 h-4" />
                </a>
                <a href="mailto:info@yourdentis.com" className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center hover:bg-violet-500 transition-colors">
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold mb-4 text-sm">Producto</h4>
              <ul className="space-y-2.5">
                {['Características', 'Módulos', 'Precios', 'Integraciones', 'API', 'Actualizaciones'].map(item => (
                  <li key={item}><button onClick={() => scrollToSection(item.toLowerCase())} className="text-sm text-slate-400 hover:text-white transition-colors">{item}</button></li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold mb-4 text-sm">Empresa</h4>
              <ul className="space-y-2.5">
                {['Sobre nosotros', 'Blog', 'Carreras', 'Partners', 'Testimonios', 'Casos de éxito'].map(item => (
                  <li key={item}><span className="text-sm text-slate-400 hover:text-white transition-colors cursor-pointer">{item}</span></li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4 text-sm">Contacto</h4>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-sm text-slate-400">
                  <Phone className="w-4 h-4 text-sky-500 shrink-0" />
                  <a href="tel:+18296303341" className="hover:text-white transition-colors">+1 (829) 630‑3341</a>
                </li>
                <li className="flex items-center gap-2 text-sm text-slate-400">
                  <MessageCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                  <a href="https://wa.me/18296303341" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">+1 (829) 630‑3341</a>
                </li>
                <li className="flex items-center gap-2 text-sm text-slate-400">
                  <Mail className="w-4 h-4 text-violet-500 shrink-0" />
                  <a href="mailto:info@yourdentis.com" className="hover:text-white transition-colors">info@yourdentis.com</a>
                </li>
                <li className="flex items-start gap-2 text-sm text-slate-400">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>C/3ra #3, Madrevieja Sur<br />San Cristóbal, Rep. Dominicana</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-slate-500">
              © {new Date().getFullYear()} YourDentis. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <div className="flex items-center gap-1.5">
                <Lock className="w-3 h-3" />
                <span>Encriptación AES-256</span>
              </div>
              <span>·</span>
              <span>HIPAA Compliant</span>
              <span>·</span>
              <span>SOC 2 Type II</span>
            </div>
            <div className="flex gap-4 text-xs text-slate-500">
              <span className="hover:text-white cursor-pointer transition-colors">Privacidad</span>
              <span className="hover:text-white cursor-pointer transition-colors">Términos</span>
              <span className="hover:text-white cursor-pointer transition-colors">Cookies</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ========== DATA ==========

const features = [
  {
    icon: <Users className="w-5 h-5" />,
    title: 'Gestión de Pacientes',
    description: 'Registro completo con historial médico, alergias, documentos adjuntos y portal de paciente para autogestión.',
    details: ['Perfil completo con historial médico y dental', 'Portal web para que los pacientes vean sus datos', 'Buscador avanzado multicritério', 'Adjuntar radiografías, fotos y documentos'],
  },
  {
    icon: <Calendar className="w-5 h-5" />,
    title: 'Agenda Inteligente',
    description: 'Calendario inspirado en los mejores sistemas del mercado con vista día, semana y mes, drag & drop y recordatorios.',
    details: ['Vista por día, semana y mes', 'Asignación por odontólogo y sala', 'Recordatorios automáticos por WhatsApp y email', 'Control de ausencias y reprogramaciones'],
  },
  {
    icon: <CircleDot className="w-5 h-5" />,
    title: 'Odontograma Digital',
    description: 'Diagrama dental interactivo completo con representación de arcadas superiores e inferiores.',
    details: ['Click por superficie para marcar condiciones', 'Colores por estado clínico', 'Historial visual de cambios por fecha', 'Exportación en PDF'],
  },
  {
    icon: <DollarSign className="w-5 h-5" />,
    title: 'Facturación y Cuotas',
    description: 'Sistema financiero completo con facturas automáticas, pagos parciales y planes de cuotas con intereses.',
    details: ['Generación automática de facturas', 'Sistema de pago en cuotas con intereses opcionales', 'Alertas de mora y vencimiento', 'Reportes financieros mensuales'],
  },
  {
    icon: <FileText className="w-5 h-5" />,
    title: 'Historia Clínica Electrónica',
    description: 'Registro completo de diagnósticos, planes de tratamiento, evolución y notas privadas del odontólogo.',
    details: ['Diagnósticos con códigos ICD-10', 'Plan de tratamiento estructurado', 'Adjuntar imágenes y radiografías', 'Notas privadas del odontólogo'],
  },
  {
    icon: <BarChart3 className="w-5 h-5" />,
    title: 'Reportes Avanzados',
    description: 'Dashboard con gráficos interactivos, análisis de ingresos, rendimiento y predicciones con IA.',
    details: ['Ingresos y cuentas por cobrar', 'Rendimiento por odontólogo', 'Procedimientos más realizados', 'Predicciones inteligentes con IA'],
  },
];

const advantages = [
  { emoji: '⚡', title: 'Rápido y Sin Instalación', desc: 'Accede desde cualquier navegador sin instalar nada. Listo para usar en minutos.' },
  { emoji: '🏥', title: 'Multi-Clínica', desc: 'Gestiona múltiples sedes desde una sola cuenta. Cada clínica con datos independientes.' },
  { emoji: '🔐', title: 'Datos 100% Seguros', desc: 'Encriptación de nivel bancario, backups automáticos y cumplimiento normativo.' },
  { emoji: '📱', title: 'Funciona en Cualquier Dispositivo', desc: 'Diseño responsive perfecto para computadora, tablet o celular.' },
  { emoji: '🤖', title: 'Potenciado con IA', desc: 'Predicción de ausencias, recordatorios inteligentes y análisis predictivo.' },
  { emoji: '💳', title: 'Pagos en Cuotas', desc: 'Sistema único de planes de pago con cálculo de intereses y alertas automáticas.' },
  { emoji: '🦷', title: 'Odontograma Interactivo', desc: 'Diagrama dental profesional con historial visual y exportación PDF.' },
  { emoji: '📊', title: 'Reportes en Tiempo Real', desc: 'Dashboards interactivos con gráficos y métricas actualizadas al instante.' },
  { emoji: '🌐', title: 'Preparado para la Nube', desc: 'Arquitectura escalable lista para miles de clínicas simultáneas.' },
];

const modules = [
  { icon: <Users className="w-5 h-5" />, title: 'Gestión de Pacientes', desc: 'Registro completo, historial médico, portal de paciente y búsqueda avanzada.' },
  { icon: <Calendar className="w-5 h-5" />, title: 'Agenda Inteligente', desc: 'Calendario multi-vista con drag & drop, recordatorios y confirmación automática.' },
  { icon: <CircleDot className="w-5 h-5" />, title: 'Odontograma Digital', desc: 'Diagrama interactivo con estados por superficie, historial y exportación.' },
  { icon: <DollarSign className="w-5 h-5" />, title: 'Facturación y Cuotas', desc: 'Facturas, pagos parciales, planes de cuotas con intereses y alertas de mora.' },
  { icon: <FileText className="w-5 h-5" />, title: 'Historia Clínica', desc: 'Diagnósticos, evolución, plan de tratamiento y notas privadas.' },
  { icon: <BarChart3 className="w-5 h-5" />, title: 'Reportes y Analíticas', desc: 'Dashboard con gráficos, KPIs, rendimiento y predicciones.' },
  { icon: <Package className="w-5 h-5" />, title: 'Inventario', desc: 'Control de stock, alertas de reposición y historial de consumo.' },
  { icon: <Bell className="w-5 h-5" />, title: 'Automatización', desc: 'Recordatorios, encuestas de satisfacción y campañas automáticas.' },
  { icon: <Shield className="w-5 h-5" />, title: 'Seguridad y Roles', desc: 'Roles, permisos, encriptación y cumplimiento normativo.' },
];

const plans = [
  {
    name: 'Básico',
    desc: 'Para clínicas pequeñas',
    price: '$49',
    period: '/mes',
    popular: false,
    cta: 'Comenzar Ahora',
    features: ['1 clínica', '3 usuarios', '100 pacientes', 'Agenda básica', 'Facturación', 'Soporte por email'],
  },
  {
    name: 'Profesional',
    desc: 'El más popular',
    price: '$99',
    period: '/mes',
    popular: true,
    cta: 'Prueba Gratis',
    features: ['3 clínicas', '10 usuarios', 'Pacientes ilimitados', 'Agenda inteligente', 'Odontograma digital', 'Reportes avanzados', 'Facturación con cuotas', 'Soporte prioritario', 'IA integrada'],
  },
  {
    name: 'Enterprise',
    desc: 'Para grandes redes',
    price: 'Custom',
    period: undefined,
    popular: false,
    cta: 'Contactar Ventas',
    features: ['Clínicas ilimitadas', 'Usuarios ilimitados', 'API completa', 'White-label disponible', 'SLA garantizado', 'Soporte 24/7 dedicado', 'Capacitación incluida', 'Migración de datos'],
  },
];

const testimonials = [
  {
    name: 'Dra. Carmen Jiménez',
    role: 'Directora, Clínica Dental Sonrisa — Santiago',
    text: 'YourDentis transformó completamente la gestión de nuestra clínica. El odontograma digital y el sistema de cuotas son increíbles. Nuestros pacientes pueden ver todo desde su portal.',
  },
  {
    name: 'Dr. Roberto Almonte',
    role: 'Fundador, DentalPlus — San Cristóbal',
    text: 'Llevamos 6 meses usando YourDentis y los reportes nos ayudaron a identificar áreas de mejora que no veíamos antes. El soporte técnico es excepcional.',
  },
  {
    name: 'Dra. María Peña',
    role: 'Ortodoncista, SmileLab Clinic — Santo Domingo',
    text: 'La agenda inteligente con recordatorios por WhatsApp redujo nuestras ausencias en un 40%. La mejor inversión que hemos hecho en tecnología.',
  },
];
