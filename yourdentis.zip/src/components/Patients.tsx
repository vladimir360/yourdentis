import { useState } from 'react';
import { Search, Plus, Phone, Mail, Calendar, FileText, ChevronRight, User, Shield, AlertCircle, X } from 'lucide-react';
import { useAppState } from '../store/context';
import type { Patient } from '../store/types';

export function Patients({ onViewPatient }: { onViewPatient: (id: string) => void }) {
  const { patients, treatments, invoices } = useAppState();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'recent' | 'balance'>('name');

  const filtered = patients.filter(p => {
    const matchSearch = `${p.firstName} ${p.lastName} ${p.email} ${p.phone} ${p.idNumber}`.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || p.status === filter;
    return matchSearch && matchFilter;
  }).sort((a, b) => {
    if (sortBy === 'name') return `${a.lastName}${a.firstName}`.localeCompare(`${b.lastName}${b.firstName}`);
    if (sortBy === 'recent') return (b.lastVisit || '').localeCompare(a.lastVisit || '');
    if (sortBy === 'balance') {
      const balA = invoices.filter(i => i.patientId === a.id).reduce((s, i) => s + (i.total - i.paid), 0);
      const balB = invoices.filter(i => i.patientId === b.id).reduce((s, i) => s + (i.total - i.paid), 0);
      return balB - balA;
    }
    return 0;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Pacientes</h1>
          <p className="text-slate-500">{patients.length} pacientes registrados · {patients.filter(p => p.status === 'active').length} activos</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200"
        >
          <Plus className="w-4 h-4" /> Nuevo Paciente
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nombre, email, teléfono o ID..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {(['all', 'active', 'inactive'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                filter === f ? 'bg-sky-500 text-white shadow-lg shadow-sky-200' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {f === 'all' ? 'Todos' : f === 'active' ? 'Activos' : 'Inactivos'}
            </button>
          ))}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as 'name' | 'recent' | 'balance')}
            className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="name">Ordenar: Nombre</option>
            <option value="recent">Ordenar: Reciente</option>
            <option value="balance">Ordenar: Saldo</option>
          </select>
        </div>
      </div>

      {/* Patient Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(patient => (
          <PatientCard
            key={patient.id}
            patient={patient}
            treatments={treatments.filter(t => t.patientId === patient.id).length}
            pendingBalance={invoices.filter(i => i.patientId === patient.id).reduce((s, i) => s + (i.total - i.paid), 0)}
            onView={() => onViewPatient(patient.id)}
          />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <User className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No se encontraron pacientes</p>
          <p className="text-slate-400 text-sm mt-1">Intenta con otros criterios de búsqueda</p>
        </div>
      )}

      {/* Add Patient Modal */}
      {showAddModal && <AddPatientModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
}

function PatientCard({ patient, treatments, pendingBalance, onView }: { patient: Patient; treatments: number; pendingBalance: number; onView: () => void }) {
  const initials = `${patient.firstName[0]}${patient.lastName[0]}`;
  const age = new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear();

  return (
    <div onClick={onView} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-lg hover:shadow-slate-100 transition-all cursor-pointer group">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-slate-800 truncate">{patient.firstName} {patient.lastName}</h3>
            <span className={`inline-block w-2 h-2 rounded-full shrink-0 ${patient.status === 'active' ? 'bg-emerald-500' : 'bg-slate-300'}`} />
          </div>
          <p className="text-sm text-slate-500">{age} años • {patient.gender === 'M' ? 'Masculino' : patient.gender === 'F' ? 'Femenino' : 'Otro'}</p>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-sky-500 transition-colors shrink-0 mt-1" />
      </div>

      <div className="mt-4 space-y-2">
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Phone className="w-3.5 h-3.5 shrink-0" /> <span className="truncate">{patient.phone}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Mail className="w-3.5 h-3.5 shrink-0" /> <span className="truncate">{patient.email}</span>
        </div>
        {patient.lastVisit && (
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Calendar className="w-3.5 h-3.5 shrink-0" /> Última visita: {patient.lastVisit}
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center gap-3 pt-3 border-t border-slate-100">
        <div className="flex items-center gap-1 text-xs text-slate-500">
          <FileText className="w-3 h-3" /> {treatments} tratamientos
        </div>
        {patient.insuranceProvider && (
          <div className="flex items-center gap-1 text-xs text-emerald-600">
            <Shield className="w-3 h-3" /> {patient.insuranceProvider}
          </div>
        )}
        {pendingBalance > 0 && (
          <div className="flex items-center gap-1 text-xs text-amber-600 ml-auto font-medium">
            <AlertCircle className="w-3 h-3" /> ${pendingBalance.toLocaleString()}
          </div>
        )}
      </div>
    </div>
  );
}

function AddPatientModal({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', dateOfBirth: '',
    gender: 'M', idNumber: '', address: '', city: '', bloodType: 'unknown',
    emergencyContact: '', emergencyPhone: '', medicalHistory: '', allergies: '',
    insuranceProvider: '', insuranceNumber: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // In a real app, this would call an API
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-8 text-center max-w-sm animate-slide-in" onClick={e => e.stopPropagation()}>
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">✓</span>
          </div>
          <h3 className="text-lg font-semibold text-slate-800">¡Paciente Registrado!</h3>
          <p className="text-sm text-slate-500 mt-2">{formData.firstName} {formData.lastName} ha sido agregado exitosamente.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-slide-in" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-slate-100 p-5 flex items-center justify-between rounded-t-2xl z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Nuevo Paciente</h2>
            <p className="text-sm text-slate-500">Complete los datos del paciente</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          {/* Personal Data */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Datos Personales</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <ModalInput label="Nombre *" value={formData.firstName} onChange={v => updateField('firstName', v)} required />
              <ModalInput label="Apellido *" value={formData.lastName} onChange={v => updateField('lastName', v)} required />
              <ModalInput label="Cédula / ID *" value={formData.idNumber} onChange={v => updateField('idNumber', v)} required />
              <ModalInput label="Fecha de nacimiento *" type="date" value={formData.dateOfBirth} onChange={v => updateField('dateOfBirth', v)} required />
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Género *</label>
                <select value={formData.gender} onChange={e => updateField('gender', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                  <option value="M">Masculino</option>
                  <option value="F">Femenino</option>
                  <option value="O">Otro</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Tipo de Sangre</label>
                <select value={formData.bloodType} onChange={e => updateField('bloodType', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                  {['unknown', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bt => (
                    <option key={bt} value={bt}>{bt === 'unknown' ? 'Desconocido' : bt}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Contacto</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <ModalInput label="Teléfono *" value={formData.phone} onChange={v => updateField('phone', v)} required />
              <ModalInput label="Email" type="email" value={formData.email} onChange={v => updateField('email', v)} />
              <ModalInput label="Dirección" value={formData.address} onChange={v => updateField('address', v)} />
              <ModalInput label="Ciudad" value={formData.city} onChange={v => updateField('city', v)} />
            </div>
          </div>

          {/* Medical */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Información Médica</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-600 mb-1">Historial Médico</label>
                <textarea value={formData.medicalHistory} onChange={e => updateField('medicalHistory', e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none h-16" placeholder="Antecedentes médicos relevantes..." />
              </div>
              <ModalInput label="Alergias (separadas por coma)" value={formData.allergies} onChange={v => updateField('allergies', v)} />
              <ModalInput label="Contacto de Emergencia" value={formData.emergencyContact} onChange={v => updateField('emergencyContact', v)} />
              <ModalInput label="Teléfono de Emergencia" value={formData.emergencyPhone} onChange={v => updateField('emergencyPhone', v)} />
            </div>
          </div>

          {/* Insurance */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Seguro Dental (Opcional)</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <ModalInput label="Aseguradora" value={formData.insuranceProvider} onChange={v => updateField('insuranceProvider', v)} />
              <ModalInput label="Número de póliza" value={formData.insuranceNumber} onChange={v => updateField('insuranceNumber', v)} />
            </div>
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-100">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
              Cancelar
            </button>
            <button type="submit" className="flex-1 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium transition-colors shadow-lg shadow-sky-200">
              Registrar Paciente
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ModalInput({ label, value, onChange, type = 'text', required = false }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        required={required}
        className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent"
      />
    </div>
  );
}
