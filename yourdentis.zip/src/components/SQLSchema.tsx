import { useState } from 'react';
import { Database, Copy, Check, ChevronDown, ChevronRight, Table2, Key, Link2, Layers, Zap } from 'lucide-react';

const SQL_SECTIONS = [
  {
    title: '1. Configuración Inicial y Base de Datos',
    icon: '🔧',
    description: 'Creación de la base de datos con charset UTF8MB4 y configuración de zona horaria.',
    sql: `-- ============================================================
-- 🦷 YOURDENTIS - SCRIPT SQL COMPLETO PARA PRODUCCIÓN
-- Sistema de Gestión Odontológica Multi-Clínica SaaS
-- Motor: MySQL 8.0+ / InnoDB
-- Charset: UTF8MB4 (soporte completo Unicode)
-- ============================================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS yourdentis_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE yourdentis_db;

-- Configuración de zona horaria
SET time_zone = '+00:00';
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;`
  },
  {
    title: '2. Tabla: clinics (Multi-Clínica SaaS)',
    icon: '🏥',
    description: 'Tabla principal para el modelo multi-tenant. Cada clínica es un tenant independiente con su plan y estado.',
    sql: `-- ============================================================
-- MÓDULO 1: MULTI-CLÍNICA (SaaS Multi-Tenant)
-- ============================================================

CREATE TABLE clinics (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  name            VARCHAR(200) NOT NULL,
  legal_name      VARCHAR(200) NULL,
  tax_id          VARCHAR(50)  NULL COMMENT 'RUC/NIT/RFC según país',
  address         VARCHAR(500) NOT NULL,
  city            VARCHAR(100) NOT NULL,
  state           VARCHAR(100) NULL,
  country         VARCHAR(100) NOT NULL DEFAULT 'República Dominicana',
  postal_code     VARCHAR(20)  NULL,
  phone           VARCHAR(30)  NOT NULL,
  email           VARCHAR(255) NOT NULL,
  website         VARCHAR(255) NULL,
  logo_url        VARCHAR(500) NULL,
  
  -- SaaS Configuration
  plan            ENUM('trial', 'basic', 'professional', 'enterprise')
                  NOT NULL DEFAULT 'trial',
  status          ENUM('active', 'suspended', 'cancelled', 'trial')
                  NOT NULL DEFAULT 'trial',
  trial_ends_at   DATETIME     NULL,
  max_users       INT          NOT NULL DEFAULT 5,
  max_patients    INT          NOT NULL DEFAULT 100,
  
  -- Timezone & Locale
  timezone        VARCHAR(50)  NOT NULL DEFAULT 'America/Santo_Domingo',
  locale          VARCHAR(10)  NOT NULL DEFAULT 'es',
  currency        VARCHAR(3)   NOT NULL DEFAULT 'DOP',
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at      DATETIME     NULL COMMENT 'Soft delete',
  
  PRIMARY KEY (id),
  UNIQUE INDEX idx_clinic_email (email),
  INDEX idx_clinic_status (status),
  INDEX idx_clinic_plan (plan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Tabla principal de clínicas - modelo multi-tenant SaaS';`
  },
  {
    title: '3. Tabla: users (Usuarios y Autenticación)',
    icon: '👤',
    description: 'Usuarios del sistema con roles, autenticación segura y relación a clínica. Soporta Admin, Odontólogo, Recepcionista y Paciente.',
    sql: `-- ============================================================
-- MÓDULO 2: USUARIOS, ROLES Y AUTENTICACIÓN
-- ============================================================

CREATE TABLE users (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  
  -- Authentication
  email           VARCHAR(255) NOT NULL,
  password_hash   VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  
  -- Profile
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  phone           VARCHAR(30)  NULL,
  avatar_url      VARCHAR(500) NULL,
  
  -- Role & Status
  role            ENUM('admin', 'dentist', 'receptionist', 'patient')
                  NOT NULL DEFAULT 'receptionist',
  status          ENUM('active', 'inactive', 'blocked', 'pending_verification')
                  NOT NULL DEFAULT 'pending_verification',
  email_verified  BOOLEAN      NOT NULL DEFAULT FALSE,
  
  -- Security
  last_login_at   DATETIME     NULL,
  last_login_ip   VARCHAR(45)  NULL COMMENT 'IPv4 o IPv6',
  failed_attempts INT          NOT NULL DEFAULT 0,
  locked_until    DATETIME     NULL,
  two_factor_enabled BOOLEAN   NOT NULL DEFAULT FALSE,
  two_factor_secret VARCHAR(100) NULL,
  
  -- Tokens
  password_reset_token   VARCHAR(255) NULL,
  password_reset_expires DATETIME     NULL,
  verification_token     VARCHAR(255) NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at      DATETIME     NULL,
  
  PRIMARY KEY (id),
  UNIQUE INDEX idx_user_email (email),
  INDEX idx_user_clinic (clinic_id),
  INDEX idx_user_role (role),
  INDEX idx_user_status (status),
  
  CONSTRAINT fk_user_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Usuarios del sistema con autenticación y roles';

-- Tabla de permisos escalables
CREATE TABLE permissions (
  id              INT          NOT NULL AUTO_INCREMENT,
  name            VARCHAR(100) NOT NULL COMMENT 'ej: patients.create, appointments.delete',
  description     VARCHAR(255) NULL,
  module          VARCHAR(50)  NOT NULL COMMENT 'patients, appointments, billing, etc.',
  
  PRIMARY KEY (id),
  UNIQUE INDEX idx_permission_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Relación roles-permisos
CREATE TABLE role_permissions (
  id              INT          NOT NULL AUTO_INCREMENT,
  role            ENUM('admin', 'dentist', 'receptionist', 'patient') NOT NULL,
  permission_id   INT          NOT NULL,
  
  PRIMARY KEY (id),
  UNIQUE INDEX idx_role_perm (role, permission_id),
  
  CONSTRAINT fk_rp_permission
    FOREIGN KEY (permission_id) REFERENCES permissions(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sesiones de usuario
CREATE TABLE user_sessions (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  user_id         CHAR(36)     NOT NULL,
  token           VARCHAR(500) NOT NULL,
  ip_address      VARCHAR(45)  NULL,
  user_agent      VARCHAR(500) NULL,
  expires_at      DATETIME     NOT NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_session_user (user_id),
  INDEX idx_session_token (token(255)),
  INDEX idx_session_expires (expires_at),
  
  CONSTRAINT fk_session_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    title: '4. Tabla: patients (Pacientes)',
    icon: '🧑‍⚕️',
    description: 'Registro completo de pacientes con datos personales, historial médico, alergias y información de seguro.',
    sql: `-- ============================================================
-- MÓDULO 3: PACIENTES
-- ============================================================

CREATE TABLE patients (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  user_id         CHAR(36)     NULL COMMENT 'Si el paciente tiene acceso al portal',
  
  -- Personal Data
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  id_type         ENUM('cedula', 'passport', 'other') NOT NULL DEFAULT 'cedula',
  id_number       VARCHAR(50)  NOT NULL,
  date_of_birth   DATE         NOT NULL,
  gender          ENUM('M', 'F', 'O') NOT NULL,
  marital_status  ENUM('single', 'married', 'divorced', 'widowed', 'other') NULL,
  occupation      VARCHAR(100) NULL,
  
  -- Contact
  email           VARCHAR(255) NULL,
  phone           VARCHAR(30)  NOT NULL,
  phone_secondary VARCHAR(30)  NULL,
  address         VARCHAR(500) NOT NULL,
  city            VARCHAR(100) NOT NULL,
  state           VARCHAR(100) NULL,
  postal_code     VARCHAR(20)  NULL,
  
  -- Medical History
  blood_type      ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'unknown')
                  NOT NULL DEFAULT 'unknown',
  medical_history TEXT         NULL COMMENT 'Antecedentes médicos generales',
  current_medications TEXT     NULL,
  is_pregnant     BOOLEAN      NOT NULL DEFAULT FALSE,
  is_smoker       BOOLEAN      NOT NULL DEFAULT FALSE,
  has_diabetes    BOOLEAN      NOT NULL DEFAULT FALSE,
  has_hypertension BOOLEAN     NOT NULL DEFAULT FALSE,
  has_heart_disease BOOLEAN    NOT NULL DEFAULT FALSE,
  has_hepatitis   BOOLEAN      NOT NULL DEFAULT FALSE,
  has_hiv         BOOLEAN      NOT NULL DEFAULT FALSE,
  other_conditions TEXT        NULL,
  
  -- Emergency Contact
  emergency_contact_name  VARCHAR(200) NULL,
  emergency_contact_phone VARCHAR(30)  NULL,
  emergency_contact_relationship VARCHAR(50) NULL,
  
  -- Insurance
  insurance_provider VARCHAR(200) NULL,
  insurance_number   VARCHAR(100) NULL,
  insurance_group    VARCHAR(100) NULL,
  insurance_expiry   DATE         NULL,
  
  -- Status
  status          ENUM('active', 'inactive', 'deceased') NOT NULL DEFAULT 'active',
  referral_source VARCHAR(200) NULL COMMENT 'Cómo conoció la clínica',
  preferred_contact ENUM('phone', 'email', 'sms', 'whatsapp') NOT NULL DEFAULT 'whatsapp',
  
  -- Photo
  photo_url       VARCHAR(500) NULL,
  
  -- Financial
  balance         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  credit_limit    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  
  -- Notes
  notes           TEXT         NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at      DATETIME     NULL,
  
  PRIMARY KEY (id),
  INDEX idx_patient_clinic (clinic_id),
  INDEX idx_patient_user (user_id),
  INDEX idx_patient_name (last_name, first_name),
  INDEX idx_patient_id_number (id_number),
  INDEX idx_patient_phone (phone),
  INDEX idx_patient_email (email),
  INDEX idx_patient_status (status),
  INDEX idx_patient_created (created_at),
  
  CONSTRAINT fk_patient_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_patient_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Registro completo de pacientes';

-- Alergias del paciente (normalizado)
CREATE TABLE patient_allergies (
  id              INT          NOT NULL AUTO_INCREMENT,
  patient_id      CHAR(36)     NOT NULL,
  allergy_type    ENUM('medication', 'food', 'material', 'environmental', 'other') NOT NULL,
  allergen        VARCHAR(200) NOT NULL,
  severity        ENUM('mild', 'moderate', 'severe', 'life_threatening') NOT NULL DEFAULT 'moderate',
  reaction        VARCHAR(500) NULL,
  notes           TEXT         NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_allergy_patient (patient_id),
  
  CONSTRAINT fk_allergy_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Documentos y archivos del paciente
CREATE TABLE patient_documents (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  patient_id      CHAR(36)     NOT NULL,
  uploaded_by     CHAR(36)     NOT NULL,
  
  document_type   ENUM('xray', 'photo', 'lab_result', 'consent_form', 'insurance_card', 'id_document', 'other')
                  NOT NULL,
  title           VARCHAR(200) NOT NULL,
  description     TEXT         NULL,
  file_url        VARCHAR(500) NOT NULL,
  file_type       VARCHAR(50)  NOT NULL COMMENT 'MIME type',
  file_size       INT          NOT NULL COMMENT 'Bytes',
  
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_doc_patient (patient_id),
  INDEX idx_doc_type (document_type),
  
  CONSTRAINT fk_doc_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_doc_uploader
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    title: '5. Tablas: dentists y rooms (Odontólogos y Salas)',
    icon: '🦷',
    description: 'Perfil profesional de odontólogos con especialidad, licencia y horarios. Salas de atención con equipamiento.',
    sql: `-- ============================================================
-- MÓDULO 4: ODONTÓLOGOS Y SALAS
-- ============================================================

CREATE TABLE dentists (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  user_id         CHAR(36)     NOT NULL,
  
  -- Professional Info
  license_number  VARCHAR(50)  NOT NULL,
  specialty       VARCHAR(200) NOT NULL,
  secondary_specialty VARCHAR(200) NULL,
  education       TEXT         NULL,
  bio             TEXT         NULL,
  
  -- Display
  color           VARCHAR(7)   NOT NULL DEFAULT '#3B82F6' COMMENT 'Color en agenda',
  
  -- Rate
  consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  
  -- Status
  status          ENUM('active', 'inactive', 'on_leave') NOT NULL DEFAULT 'active',
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_dentist_clinic (clinic_id),
  INDEX idx_dentist_user (user_id),
  INDEX idx_dentist_license (license_number),
  INDEX idx_dentist_status (status),
  
  CONSTRAINT fk_dentist_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_dentist_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Horarios del odontólogo
CREATE TABLE dentist_schedules (
  id              INT          NOT NULL AUTO_INCREMENT,
  dentist_id      CHAR(36)     NOT NULL,
  day_of_week     TINYINT      NOT NULL COMMENT '0=Domingo, 6=Sábado',
  start_time      TIME         NOT NULL,
  end_time        TIME         NOT NULL,
  break_start     TIME         NULL,
  break_end       TIME         NULL,
  room_id         CHAR(36)     NULL,
  is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
  
  PRIMARY KEY (id),
  INDEX idx_schedule_dentist (dentist_id),
  
  CONSTRAINT fk_schedule_dentist
    FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_schedule_times
    CHECK (end_time > start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Salas de atención
CREATE TABLE rooms (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  name            VARCHAR(100) NOT NULL,
  description     VARCHAR(500) NULL,
  equipment       TEXT         NULL COMMENT 'Lista de equipamiento',
  status          ENUM('available', 'occupied', 'maintenance') NOT NULL DEFAULT 'available',
  floor           VARCHAR(20)  NULL,
  color           VARCHAR(7)   NOT NULL DEFAULT '#6B7280',
  
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_room_clinic (clinic_id),
  
  CONSTRAINT fk_room_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    title: '6. Tabla: appointments (Agenda y Citas)',
    icon: '📅',
    description: 'Citas con relación paciente-odontólogo, estados, recordatorios, sala asignada y control de ausencias.',
    sql: `-- ============================================================
-- MÓDULO 5: AGENDA Y CITAS
-- ============================================================

CREATE TABLE appointments (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  patient_id      CHAR(36)     NOT NULL,
  dentist_id      CHAR(36)     NOT NULL,
  room_id         CHAR(36)     NULL,
  
  -- Schedule
  appointment_date DATE        NOT NULL,
  start_time      TIME         NOT NULL,
  end_time        TIME         NOT NULL,
  duration_minutes INT         NOT NULL DEFAULT 30,
  
  -- Type & Details
  appointment_type VARCHAR(200) NOT NULL COMMENT 'Limpieza, Endodoncia, Control, etc.',
  reason          TEXT         NULL COMMENT 'Motivo de consulta',
  notes           TEXT         NULL,
  
  -- Status Management
  status          ENUM('scheduled', 'confirmed', 'checked_in', 'in_progress',
                       'completed', 'cancelled', 'no_show', 'rescheduled')
                  NOT NULL DEFAULT 'scheduled',
  cancellation_reason TEXT     NULL,
  cancelled_at    DATETIME     NULL,
  cancelled_by    CHAR(36)     NULL,
  
  -- Reminders
  reminder_sent   BOOLEAN      NOT NULL DEFAULT FALSE,
  reminder_sent_at DATETIME    NULL,
  reminder_type   ENUM('email', 'sms', 'whatsapp', 'none') NOT NULL DEFAULT 'whatsapp',
  
  -- Confirmation
  confirmed_at    DATETIME     NULL,
  confirmed_by    ENUM('patient', 'staff', 'auto') NULL,
  
  -- Check-in
  checked_in_at   DATETIME     NULL,
  
  -- Rescheduling
  rescheduled_from CHAR(36)   NULL COMMENT 'ID de cita original si fue reprogramada',
  
  -- Color for calendar
  color           VARCHAR(7)   NOT NULL DEFAULT '#3B82F6',
  
  -- Recurrence
  is_recurring    BOOLEAN      NOT NULL DEFAULT FALSE,
  recurrence_rule VARCHAR(200) NULL COMMENT 'RRULE format',
  
  -- Audit
  created_by      CHAR(36)     NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_appt_clinic (clinic_id),
  INDEX idx_appt_patient (patient_id),
  INDEX idx_appt_dentist (dentist_id),
  INDEX idx_appt_date (appointment_date),
  INDEX idx_appt_status (status),
  INDEX idx_appt_datetime (appointment_date, start_time),
  INDEX idx_appt_dentist_date (dentist_id, appointment_date),
  INDEX idx_appt_patient_date (patient_id, appointment_date),
  
  CONSTRAINT fk_appt_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_dentist
    FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_room
    FOREIGN KEY (room_id) REFERENCES rooms(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_appt_times
    CHECK (end_time > start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Agenda de citas con estados completos y recordatorios';`
  },
  {
    title: '7. Tabla: clinical_notes (Historia Clínica Electrónica)',
    icon: '📋',
    description: 'Historia clínica con diagnóstico, plan de tratamiento, evolución, signos vitales y notas privadas.',
    sql: `-- ============================================================
-- MÓDULO 6: HISTORIA CLÍNICA ELECTRÓNICA
-- ============================================================

CREATE TABLE clinical_notes (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  patient_id      CHAR(36)     NOT NULL,
  dentist_id      CHAR(36)     NOT NULL,
  appointment_id  CHAR(36)     NULL,
  
  -- Clinical Data
  note_date       DATE         NOT NULL,
  chief_complaint TEXT         NULL COMMENT 'Motivo de consulta',
  diagnosis       TEXT         NOT NULL,
  diagnosis_code  VARCHAR(20)  NULL COMMENT 'Código ICD-10',
  treatment_plan  TEXT         NULL,
  procedures_done TEXT         NULL,
  evolution       TEXT         NULL,
  prognosis       VARCHAR(200) NULL,
  
  -- Vital Signs
  blood_pressure_systolic  INT  NULL,
  blood_pressure_diastolic INT  NULL,
  heart_rate      INT          NULL,
  temperature     DECIMAL(4,1) NULL,
  oxygen_saturation INT       NULL,
  weight          DECIMAL(5,2) NULL,
  
  -- Notes
  private_notes   TEXT         NULL COMMENT 'Solo visible para el odontólogo',
  
  -- Follow-up
  follow_up_date  DATE         NULL,
  follow_up_notes VARCHAR(500) NULL,
  
  -- Status
  status          ENUM('draft', 'signed', 'amended', 'locked') NOT NULL DEFAULT 'draft',
  signed_at       DATETIME     NULL,
  signed_by       CHAR(36)     NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_cn_clinic (clinic_id),
  INDEX idx_cn_patient (patient_id),
  INDEX idx_cn_dentist (dentist_id),
  INDEX idx_cn_date (note_date),
  INDEX idx_cn_appointment (appointment_id),
  
  CONSTRAINT fk_cn_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_cn_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_cn_dentist
    FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_cn_appointment
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Historia clínica electrónica completa';

-- Adjuntos de notas clínicas
CREATE TABLE clinical_attachments (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinical_note_id CHAR(36)   NOT NULL,
  file_type       ENUM('xray', 'photo', 'document', 'lab_result', 'other') NOT NULL,
  title           VARCHAR(200) NOT NULL,
  file_url        VARCHAR(500) NOT NULL,
  file_size       INT          NOT NULL,
  mime_type       VARCHAR(100) NOT NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_ca_note (clinical_note_id),
  
  CONSTRAINT fk_ca_note
    FOREIGN KEY (clinical_note_id) REFERENCES clinical_notes(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    title: '8. Tabla: treatments (Tratamientos)',
    icon: '💊',
    description: 'Tratamientos con código CDT, estado, costo, relación con diente y odontólogo responsable.',
    sql: `-- ============================================================
-- MÓDULO 7: TRATAMIENTOS
-- ============================================================

-- Catálogo de procedimientos
CREATE TABLE treatment_catalog (
  id              INT          NOT NULL AUTO_INCREMENT,
  clinic_id       CHAR(36)     NOT NULL,
  code            VARCHAR(20)  NOT NULL COMMENT 'Código CDT/CDA',
  name            VARCHAR(200) NOT NULL,
  description     TEXT         NULL,
  category        VARCHAR(100) NOT NULL,
  default_price   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  default_duration INT         NOT NULL DEFAULT 30 COMMENT 'Minutos',
  is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
  
  PRIMARY KEY (id),
  INDEX idx_tc_clinic (clinic_id),
  INDEX idx_tc_code (code),
  INDEX idx_tc_category (category),
  
  CONSTRAINT fk_tc_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tratamientos realizados
CREATE TABLE treatments (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  patient_id      CHAR(36)     NOT NULL,
  dentist_id      CHAR(36)     NOT NULL,
  appointment_id  CHAR(36)     NULL,
  catalog_id      INT          NULL,
  
  -- Treatment Details
  code            VARCHAR(20)  NULL COMMENT 'Código CDT',
  treatment_type  VARCHAR(200) NOT NULL,
  description     TEXT         NOT NULL,
  
  -- Tooth Info
  tooth_number    TINYINT      NULL COMMENT 'Número FDI (11-48)',
  tooth_surface   VARCHAR(20)  NULL COMMENT 'O,M,D,B,L combinaciones',
  quadrant        TINYINT      NULL COMMENT '1-4',
  
  -- Status
  status          ENUM('planned', 'approved', 'in_progress', 'completed', 'cancelled')
                  NOT NULL DEFAULT 'planned',
  priority        ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  
  -- Dates
  planned_date    DATE         NULL,
  started_date    DATE         NULL,
  completed_date  DATE         NULL,
  
  -- Financial
  cost            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  final_cost      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  
  -- Notes
  notes           TEXT         NULL,
  lab_work_needed BOOLEAN      NOT NULL DEFAULT FALSE,
  lab_notes       TEXT         NULL,
  
  -- Warranty
  warranty_months INT          NULL,
  warranty_until  DATE         NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_treat_clinic (clinic_id),
  INDEX idx_treat_patient (patient_id),
  INDEX idx_treat_dentist (dentist_id),
  INDEX idx_treat_status (status),
  INDEX idx_treat_tooth (tooth_number),
  INDEX idx_treat_date (planned_date),
  INDEX idx_treat_patient_status (patient_id, status),
  
  CONSTRAINT fk_treat_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_treat_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_treat_dentist
    FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_treat_appointment
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_tooth_number
    CHECK (tooth_number IS NULL OR (tooth_number >= 11 AND tooth_number <= 48))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Tratamientos con estado completo y relación a diente';`
  },
  {
    title: '9. Tabla: odontogram_entries (Odontograma Digital)',
    icon: '🦷',
    description: 'Historial del odontograma con estado por superficie, vinculado a tratamientos y fecha para seguimiento visual.',
    sql: `-- ============================================================
-- MÓDULO 8: ODONTOGRAMA DIGITAL
-- ============================================================

CREATE TABLE odontogram_entries (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  patient_id      CHAR(36)     NOT NULL,
  dentist_id      CHAR(36)     NOT NULL,
  treatment_id    CHAR(36)     NULL,
  
  -- Tooth Identification
  tooth_number    TINYINT      NOT NULL COMMENT 'Sistema FDI: 11-18, 21-28, 31-38, 41-48',
  
  -- Condition
  condition       ENUM('healthy', 'cavity', 'filling', 'crown', 'extraction', 
                       'root_canal', 'implant', 'sealant', 'bridge', 'veneer',
                       'fracture', 'absent', 'impacted', 'mobility',
                       'periodontal', 'temporary')
                  NOT NULL DEFAULT 'healthy',
  
  -- Surface (múltiples superficies posibles)
  surface_occlusal BOOLEAN     NOT NULL DEFAULT FALSE,
  surface_mesial   BOOLEAN     NOT NULL DEFAULT FALSE,
  surface_distal   BOOLEAN     NOT NULL DEFAULT FALSE,
  surface_buccal   BOOLEAN     NOT NULL DEFAULT FALSE,
  surface_lingual  BOOLEAN     NOT NULL DEFAULT FALSE,
  
  -- Details
  entry_date      DATE         NOT NULL,
  severity        ENUM('mild', 'moderate', 'severe') NULL,
  notes           TEXT         NULL,
  
  -- Tracking
  is_current      BOOLEAN      NOT NULL DEFAULT TRUE COMMENT 'Estado actual vs histórico',
  superseded_by   CHAR(36)     NULL COMMENT 'ID de la entrada que reemplaza esta',
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_odont_clinic (clinic_id),
  INDEX idx_odont_patient (patient_id),
  INDEX idx_odont_tooth (patient_id, tooth_number),
  INDEX idx_odont_date (entry_date),
  INDEX idx_odont_current (patient_id, is_current),
  INDEX idx_odont_condition (condition),
  
  CONSTRAINT fk_odont_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_odont_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_odont_dentist
    FOREIGN KEY (dentist_id) REFERENCES dentists(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_odont_treatment
    FOREIGN KEY (treatment_id) REFERENCES treatments(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_odont_tooth
    CHECK (tooth_number >= 11 AND tooth_number <= 48)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Odontograma digital con historial completo por fecha';`
  },
  {
    title: '10. Tablas: invoices, installments, payments (Facturación)',
    icon: '💳',
    description: 'Sistema completo de facturación con cuotas, intereses, pagos parciales y múltiples métodos de pago.',
    sql: `-- ============================================================
-- MÓDULO 9: FACTURACIÓN Y PAGOS
-- ============================================================

CREATE TABLE invoices (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  patient_id      CHAR(36)     NOT NULL,
  
  -- Invoice Number
  invoice_number  VARCHAR(50)  NOT NULL,
  
  -- Dates
  invoice_date    DATE         NOT NULL,
  due_date        DATE         NOT NULL,
  
  -- Amounts
  subtotal        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  tax_rate        DECIMAL(5,2)  NOT NULL DEFAULT 0.00 COMMENT 'ITBIS/IVA %',
  tax_amount      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount_paid     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  balance         DECIMAL(12,2) GENERATED ALWAYS AS (total - amount_paid) STORED,
  
  -- Status
  status          ENUM('draft', 'pending', 'partial', 'paid', 'overdue', 'cancelled', 'refunded')
                  NOT NULL DEFAULT 'draft',
  
  -- Payment Terms
  payment_terms   VARCHAR(200) NULL,
  has_installment_plan BOOLEAN NOT NULL DEFAULT FALSE,
  
  -- NCF (Fiscal document for DR)
  ncf_number      VARCHAR(20)  NULL COMMENT 'Número comprobante fiscal',
  ncf_type        VARCHAR(5)   NULL,
  
  -- Notes
  notes           TEXT         NULL,
  internal_notes  TEXT         NULL,
  
  -- Issued by
  issued_by       CHAR(36)     NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  voided_at       DATETIME     NULL,
  voided_by       CHAR(36)     NULL,
  
  PRIMARY KEY (id),
  UNIQUE INDEX idx_inv_number (clinic_id, invoice_number),
  INDEX idx_inv_clinic (clinic_id),
  INDEX idx_inv_patient (patient_id),
  INDEX idx_inv_date (invoice_date),
  INDEX idx_inv_due (due_date),
  INDEX idx_inv_status (status),
  INDEX idx_inv_patient_status (patient_id, status),
  
  CONSTRAINT fk_inv_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_inv_patient
    FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Facturas con soporte fiscal y multi-moneda';

-- Items de factura
CREATE TABLE invoice_items (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  invoice_id      CHAR(36)     NOT NULL,
  treatment_id    CHAR(36)     NULL,
  
  description     VARCHAR(500) NOT NULL,
  quantity        DECIMAL(10,2) NOT NULL DEFAULT 1,
  unit_price      DECIMAL(10,2) NOT NULL,
  discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  tax_rate        DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  tax_amount      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  line_total      DECIMAL(12,2) NOT NULL,
  
  sort_order      INT          NOT NULL DEFAULT 0,
  
  PRIMARY KEY (id),
  INDEX idx_ii_invoice (invoice_id),
  
  CONSTRAINT fk_ii_invoice
    FOREIGN KEY (invoice_id) REFERENCES invoices(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ii_treatment
    FOREIGN KEY (treatment_id) REFERENCES treatments(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Plan de cuotas
CREATE TABLE installment_plans (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  invoice_id      CHAR(36)     NOT NULL,
  
  total_installments INT       NOT NULL,
  installment_amount DECIMAL(10,2) NOT NULL,
  interest_rate   DECIMAL(5,2)  NOT NULL DEFAULT 0.00 COMMENT 'Tasa mensual %',
  start_date      DATE         NOT NULL,
  
  -- Penalty
  late_fee_type   ENUM('none', 'fixed', 'percentage') NOT NULL DEFAULT 'none',
  late_fee_value  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  grace_days      INT          NOT NULL DEFAULT 5,
  
  status          ENUM('active', 'completed', 'defaulted', 'cancelled') NOT NULL DEFAULT 'active',
  
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_ip_invoice (invoice_id),
  
  CONSTRAINT fk_ip_invoice
    FOREIGN KEY (invoice_id) REFERENCES invoices(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Planes de pago en cuotas con intereses opcionales';

-- Cuotas individuales
CREATE TABLE installments (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  plan_id         CHAR(36)     NOT NULL,
  
  installment_number INT       NOT NULL,
  due_date        DATE         NOT NULL,
  principal       DECIMAL(10,2) NOT NULL,
  interest        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  late_fee        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total_amount    DECIMAL(10,2) NOT NULL,
  
  -- Payment Status
  status          ENUM('pending', 'paid', 'overdue', 'partially_paid') NOT NULL DEFAULT 'pending',
  paid_amount     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  paid_date       DATE         NULL,
  
  notes           TEXT         NULL,
  
  PRIMARY KEY (id),
  INDEX idx_inst_plan (plan_id),
  INDEX idx_inst_due (due_date),
  INDEX idx_inst_status (status),
  
  CONSTRAINT fk_inst_plan
    FOREIGN KEY (plan_id) REFERENCES installment_plans(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Cuotas individuales con control de mora';

-- Pagos
CREATE TABLE payments (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  invoice_id      CHAR(36)     NOT NULL,
  installment_id  CHAR(36)     NULL,
  
  -- Payment Details
  payment_date    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount          DECIMAL(12,2) NOT NULL,
  
  payment_method  ENUM('cash', 'credit_card', 'debit_card', 'bank_transfer',
                       'check', 'digital_wallet', 'insurance', 'other')
                  NOT NULL,
  
  -- Reference
  reference_number VARCHAR(100) NULL,
  authorization_code VARCHAR(100) NULL,
  
  -- Card Info (masked)
  card_last_four  VARCHAR(4)   NULL,
  card_brand      VARCHAR(20)  NULL,
  
  -- Bank Info
  bank_name       VARCHAR(100) NULL,
  
  -- Status
  status          ENUM('pending', 'completed', 'failed', 'refunded', 'voided')
                  NOT NULL DEFAULT 'completed',
  
  -- Received by
  received_by     CHAR(36)     NOT NULL,
  
  -- Notes
  notes           TEXT         NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_pay_clinic (clinic_id),
  INDEX idx_pay_invoice (invoice_id),
  INDEX idx_pay_date (payment_date),
  INDEX idx_pay_method (payment_method),
  INDEX idx_pay_status (status),
  
  CONSTRAINT fk_pay_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_pay_invoice
    FOREIGN KEY (invoice_id) REFERENCES invoices(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_pay_installment
    FOREIGN KEY (installment_id) REFERENCES installments(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pay_receiver
    FOREIGN KEY (received_by) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Registro de pagos con múltiples métodos';`
  },
  {
    title: '11. Tabla: inventory (Inventario y Control de Materiales)',
    icon: '📦',
    description: 'Control de stock con alertas, movimientos, proveedores, SKU y fechas de vencimiento.',
    sql: `-- ============================================================
-- MÓDULO 10: INVENTARIO Y CONTROL DE MATERIALES
-- ============================================================

CREATE TABLE inventory_categories (
  id              INT          NOT NULL AUTO_INCREMENT,
  clinic_id       CHAR(36)     NOT NULL,
  name            VARCHAR(100) NOT NULL,
  description     VARCHAR(500) NULL,
  parent_id       INT          NULL,
  
  PRIMARY KEY (id),
  INDEX idx_ic_clinic (clinic_id),
  
  CONSTRAINT fk_ic_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_ic_parent
    FOREIGN KEY (parent_id) REFERENCES inventory_categories(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE inventory_items (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  category_id     INT          NULL,
  
  -- Product Info
  name            VARCHAR(200) NOT NULL,
  description     TEXT         NULL,
  sku             VARCHAR(50)  NOT NULL,
  barcode         VARCHAR(100) NULL,
  brand           VARCHAR(100) NULL,
  
  -- Stock
  current_stock   DECIMAL(10,2) NOT NULL DEFAULT 0,
  min_stock       DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Punto de reorden',
  max_stock       DECIMAL(10,2) NOT NULL DEFAULT 0,
  unit            VARCHAR(50)  NOT NULL COMMENT 'unidad, caja, litro, etc.',
  
  -- Pricing
  unit_cost       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  sale_price      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  
  -- Supplier
  supplier_name   VARCHAR(200) NULL,
  supplier_contact VARCHAR(200) NULL,
  supplier_email  VARCHAR(255) NULL,
  
  -- Location
  storage_location VARCHAR(100) NULL,
  
  -- Expiration
  expiration_date DATE         NULL,
  lot_number      VARCHAR(100) NULL,
  
  -- Status
  status          ENUM('active', 'discontinued', 'out_of_stock') NOT NULL DEFAULT 'active',
  is_controlled   BOOLEAN      NOT NULL DEFAULT FALSE COMMENT 'Material controlado/regulado',
  
  -- Last restock
  last_restocked  DATE         NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_inv_clinic (clinic_id),
  INDEX idx_inv_sku (sku),
  INDEX idx_inv_category (category_id),
  INDEX idx_inv_stock (current_stock, min_stock),
  INDEX idx_inv_expiry (expiration_date),
  INDEX idx_inv_status_item (status),
  
  CONSTRAINT fk_inv_item_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_inv_item_category
    FOREIGN KEY (category_id) REFERENCES inventory_categories(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Inventario de materiales con control de stock';

-- Movimientos de inventario
CREATE TABLE inventory_movements (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  item_id         CHAR(36)     NOT NULL,
  
  movement_type   ENUM('purchase', 'consumption', 'adjustment_in', 'adjustment_out',
                       'return', 'expired', 'transfer', 'initial')
                  NOT NULL,
  quantity        DECIMAL(10,2) NOT NULL COMMENT 'Positivo=entrada, Negativo=salida',
  previous_stock  DECIMAL(10,2) NOT NULL,
  new_stock       DECIMAL(10,2) NOT NULL,
  unit_cost       DECIMAL(10,2) NULL,
  
  -- Reference
  reference       VARCHAR(200) NULL COMMENT 'PO number, patient, etc.',
  reason          TEXT         NULL,
  
  -- For consumption
  patient_id      CHAR(36)     NULL,
  treatment_id    CHAR(36)     NULL,
  
  -- Performed by
  performed_by    CHAR(36)     NOT NULL,
  movement_date   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_im_item (item_id),
  INDEX idx_im_date (movement_date),
  INDEX idx_im_type (movement_type),
  
  CONSTRAINT fk_im_item
    FOREIGN KEY (item_id) REFERENCES inventory_items(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_im_user
    FOREIGN KEY (performed_by) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    title: '12. Tablas: audit_logs y notifications (Auditoría)',
    icon: '🔐',
    description: 'Log de auditoría completo y sistema de notificaciones con prioridades y tipos.',
    sql: `-- ============================================================
-- MÓDULO 11: AUDITORÍA, NOTIFICACIONES Y LOGS
-- ============================================================

CREATE TABLE audit_logs (
  id              BIGINT       NOT NULL AUTO_INCREMENT,
  clinic_id       CHAR(36)     NOT NULL,
  user_id         CHAR(36)     NULL,
  
  -- Action
  action          ENUM('CREATE', 'READ', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT',
                       'EXPORT', 'IMPORT', 'PRINT', 'SEND', 'APPROVE', 'REJECT')
                  NOT NULL,
  entity_type     VARCHAR(100) NOT NULL COMMENT 'patient, appointment, invoice, etc.',
  entity_id       VARCHAR(36)  NULL,
  
  -- Details
  description     TEXT         NOT NULL,
  old_values      JSON         NULL COMMENT 'Valores anteriores al cambio',
  new_values      JSON         NULL COMMENT 'Valores nuevos',
  
  -- Request Info
  ip_address      VARCHAR(45)  NULL,
  user_agent      VARCHAR(500) NULL,
  request_url     VARCHAR(500) NULL,
  
  -- Timestamp
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_audit_clinic (clinic_id),
  INDEX idx_audit_user (user_id),
  INDEX idx_audit_entity (entity_type, entity_id),
  INDEX idx_audit_action (action),
  INDEX idx_audit_date (created_at),
  INDEX idx_audit_clinic_date (clinic_id, created_at),
  
  CONSTRAINT fk_audit_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Log de auditoría completo para cumplimiento normativo'
  PARTITION BY RANGE (YEAR(created_at)) (
    PARTITION p2024 VALUES LESS THAN (2025),
    PARTITION p2025 VALUES LESS THAN (2026),
    PARTITION p2026 VALUES LESS THAN (2027),
    PARTITION p_future VALUES LESS THAN MAXVALUE
  );

CREATE TABLE notifications (
  id              CHAR(36)     NOT NULL DEFAULT (UUID()),
  clinic_id       CHAR(36)     NOT NULL,
  user_id         CHAR(36)     NULL COMMENT 'NULL = notificación global de clínica',
  
  -- Notification Data
  type            ENUM('appointment_reminder', 'appointment_confirmation',
                       'payment_due', 'payment_received', 'payment_overdue',
                       'low_stock', 'treatment_followup', 'birthday',
                       'marketing', 'system', 'alert')
                  NOT NULL,
  
  title           VARCHAR(200) NOT NULL,
  message         TEXT         NOT NULL,
  action_url      VARCHAR(500) NULL COMMENT 'Link para acción directa',
  
  -- Target
  channel         ENUM('in_app', 'email', 'sms', 'whatsapp', 'push') NOT NULL DEFAULT 'in_app',
  
  -- Status
  priority        ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  is_read         BOOLEAN      NOT NULL DEFAULT FALSE,
  read_at         DATETIME     NULL,
  is_sent         BOOLEAN      NOT NULL DEFAULT FALSE,
  sent_at         DATETIME     NULL,
  
  -- Related entity
  entity_type     VARCHAR(100) NULL,
  entity_id       VARCHAR(36)  NULL,
  
  -- Schedule
  scheduled_for   DATETIME     NULL COMMENT 'Para envío programado',
  expires_at      DATETIME     NULL,
  
  -- Audit
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (id),
  INDEX idx_notif_clinic (clinic_id),
  INDEX idx_notif_user (user_id),
  INDEX idx_notif_type (type),
  INDEX idx_notif_read (user_id, is_read),
  INDEX idx_notif_created (created_at),
  INDEX idx_notif_scheduled (scheduled_for),
  
  CONSTRAINT fk_notif_clinic
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_notif_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable FK checks
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DATOS INICIALES (Seed Data)
-- ============================================================

-- Permisos por defecto
INSERT INTO permissions (name, description, module) VALUES
  ('patients.create', 'Crear pacientes', 'patients'),
  ('patients.read', 'Ver pacientes', 'patients'),
  ('patients.update', 'Editar pacientes', 'patients'),
  ('patients.delete', 'Eliminar pacientes', 'patients'),
  ('appointments.create', 'Crear citas', 'appointments'),
  ('appointments.read', 'Ver citas', 'appointments'),
  ('appointments.update', 'Editar citas', 'appointments'),
  ('appointments.delete', 'Cancelar citas', 'appointments'),
  ('treatments.create', 'Crear tratamientos', 'treatments'),
  ('treatments.read', 'Ver tratamientos', 'treatments'),
  ('treatments.update', 'Editar tratamientos', 'treatments'),
  ('billing.create', 'Crear facturas', 'billing'),
  ('billing.read', 'Ver facturas', 'billing'),
  ('billing.update', 'Editar facturas', 'billing'),
  ('billing.payments', 'Registrar pagos', 'billing'),
  ('inventory.manage', 'Gestionar inventario', 'inventory'),
  ('reports.view', 'Ver reportes', 'reports'),
  ('settings.manage', 'Gestionar configuración', 'settings'),
  ('clinical_notes.create', 'Crear notas clínicas', 'clinical'),
  ('clinical_notes.read', 'Ver notas clínicas', 'clinical'),
  ('odontogram.manage', 'Gestionar odontograma', 'clinical'),
  ('audit.view', 'Ver logs de auditoría', 'system');`
  },
];

const ER_DIAGRAM = `
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DIAGRAMA ENTIDAD-RELACIÓN - YOURDENTIS                    │
│                         Sistema Multi-Clínica SaaS                          │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│   CLINICS    │────1:N──│    USERS     │────1:1──│   DENTISTS   │
│              │         │              │         │              │
│ PK: id      │         │ PK: id       │         │ PK: id       │
│ name        │         │ FK: clinic_id│         │ FK: clinic_id│
│ plan        │         │ role (ENUM)  │         │ FK: user_id  │
│ status      │         │ email        │         │ specialty    │
│ currency    │         │ password_hash│         │ license      │
└──────┬───────┘         └──────┬───────┘         └──────┬───────┘
       │                        │                         │
       │                        │                         │
       │         ┌──────────────┴──────────────┐         │
       │         │                             │         │
       ▼         ▼                             ▼         ▼
┌──────────────┐         ┌──────────────────────────────────┐
│   PATIENTS   │────1:N──│          APPOINTMENTS            │
│              │         │                                  │
│ PK: id      │         │ PK: id                           │
│ FK: clinic_id│        │ FK: clinic_id, patient_id        │
│ FK: user_id │         │ FK: dentist_id, room_id          │
│ first_name  │         │ date, start_time, end_time       │
│ last_name   │         │ status (ENUM)                    │
│ allergies[] │         │ reminder_sent                     │
│ blood_type  │         └──────────────────────────────────┘
│ balance     │                      │
└──────┬───────┘                     │
       │                             │
       ├────────1:N──────────────────┤
       │                             │
       ▼                             ▼
┌──────────────────────┐    ┌──────────────────────┐
│   CLINICAL_NOTES     │    │     TREATMENTS       │
│                      │    │                      │
│ PK: id              │    │ PK: id               │
│ FK: patient_id      │    │ FK: patient_id       │
│ FK: dentist_id      │    │ FK: dentist_id       │
│ FK: appointment_id  │    │ tooth_number         │
│ diagnosis           │    │ status (ENUM)        │
│ treatment_plan      │    │ cost, discount       │
│ evolution           │    │ warranty             │
└──────────────────────┘    └──────────┬───────────┘
                                       │
       ┌───────────────────────────────┤
       │                               │
       ▼                               ▼
┌──────────────────────┐    ┌──────────────────────┐
│  ODONTOGRAM_ENTRIES  │    │      INVOICES        │
│                      │    │                      │
│ PK: id              │    │ PK: id               │
│ FK: patient_id      │    │ FK: patient_id       │
│ FK: treatment_id    │    │ invoice_number       │
│ tooth_number (FDI)  │    │ total, amount_paid   │
│ condition (ENUM)    │    │ balance (GENERATED)  │
│ surfaces (BOOL×5)   │    │ status (ENUM)        │
│ is_current          │    └──────────┬───────────┘
└──────────────────────┘               │
                              ┌────────┼────────┐
                              │        │        │
                              ▼        ▼        ▼
                    ┌──────────┐ ┌──────────┐ ┌──────────────────┐
                    │ INVOICE  │ │ PAYMENTS │ │ INSTALLMENT_PLANS│
                    │ _ITEMS   │ │          │ │                  │
                    │          │ │ amount   │ │ interest_rate    │
                    │ qty,price│ │ method   │ │ late_fee         │
                    │ discount │ │ ref#     │ │ ──► INSTALLMENTS │
                    └──────────┘ └──────────┘ └──────────────────┘

┌──────────────────────┐    ┌──────────────────────┐
│   INVENTORY_ITEMS    │    │     AUDIT_LOGS       │
│                      │    │                      │
│ PK: id              │    │ PK: id (BIGINT)      │
│ FK: clinic_id       │    │ FK: clinic_id        │
│ sku, barcode        │    │ user_id, action      │
│ current_stock       │    │ entity, old/new JSON │
│ min_stock, max_stock│    │ ip_address           │
│ ──► MOVEMENTS       │    │ PARTITIONED by YEAR  │
└──────────────────────┘    └──────────────────────┘

┌──────────────────────┐    ┌──────────────────────┐
│    PERMISSIONS       │    │    NOTIFICATIONS      │
│                      │    │                      │
│ PK: id              │    │ PK: id               │
│ name (UNIQUE)       │    │ FK: clinic_id        │
│ module              │    │ FK: user_id          │
│ ──► ROLE_PERMISSIONS│    │ type, priority       │
└──────────────────────┘    │ channel, scheduled   │
                            └──────────────────────┘
`;

const OPTIMIZATION_TIPS = [
  { title: 'Particionamiento de audit_logs', desc: 'La tabla de auditoría usa PARTITION BY RANGE (YEAR) para gestionar millones de registros eficientemente. Agregar nuevas particiones anualmente.' },
  { title: 'Columna GENERATED para balance', desc: 'invoices.balance es una columna calculada STORED que se actualiza automáticamente, evitando inconsistencias.' },
  { title: 'Índices compuestos estratégicos', desc: 'Índices como (patient_id, status), (dentist_id, appointment_date) optimizan las consultas más frecuentes del sistema.' },
  { title: 'Soft Deletes', desc: 'Las tablas principales usan deleted_at para borrado lógico, manteniendo integridad referencial y capacidad de auditoría.' },
  { title: 'UUID como Primary Key', desc: 'UUIDs permiten generación distribuida de IDs, ideal para arquitectura multi-tenant y microservicios.' },
  { title: 'JSON para audit trails', desc: 'old_values y new_values en audit_logs usan JSON nativo de MySQL 8+, permitiendo consultas con JSON_EXTRACT.' },
];

const SCALING_TIPS = [
  'Implementar read replicas para consultas de reportes y analíticas',
  'Usar conexión pooling (ProxySQL o PgBouncer equivalente)',
  'Cache con Redis para sesiones, permisos y datos frecuentes',
  'CDN para archivos estáticos (radiografías, fotos)',
  'Sharding horizontal por clinic_id para miles de clínicas',
  'Migrar audit_logs a TimescaleDB o ClickHouse para volúmenes altos',
  'Event-driven architecture con RabbitMQ/Kafka para notificaciones',
  'Elasticsearch para búsqueda full-text de pacientes y notas clínicas',
  'Implementar rate limiting por tenant para protección de API',
  'Backups incrementales cada hora + completos diarios con replicación geográfica',
];

export function SQLSchema() {
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set([0]));
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'schema' | 'er' | 'optimization'>('schema');

  const toggleSection = (idx: number) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx); else next.add(idx);
      return next;
    });
  };

  const expandAll = () => setExpandedSections(new Set(SQL_SECTIONS.map((_, i) => i)));
  const collapseAll = () => setExpandedSections(new Set());

  const copySQL = (sql: string, idx: number) => {
    navigator.clipboard.writeText(sql);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const fullSQL = SQL_SECTIONS.map(s => s.sql).join('\n\n');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Database className="w-6 h-6 text-brand-500" /> Base de Datos YourDentis
          </h1>
          <p className="text-slate-500">Script SQL completo para MySQL 8+ — Listo para producción</p>
        </div>
        <button
          onClick={() => copySQL(fullSQL, -1)}
          className="flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-brand-200"
        >
          {copiedIdx === -1 ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copiedIdx === -1 ? 'Copiado!' : 'Copiar Todo el SQL'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={<Table2 className="w-4 h-4" />} label="Tablas" value="22" />
        <StatCard icon={<Key className="w-4 h-4" />} label="Foreign Keys" value="35+" />
        <StatCard icon={<Link2 className="w-4 h-4" />} label="Índices" value="60+" />
        <StatCard icon={<Layers className="w-4 h-4" />} label="Módulos" value="12" />
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-0">
        {[
          { id: 'schema' as const, label: 'Script SQL', icon: <Database className="w-4 h-4" /> },
          { id: 'er' as const, label: 'Diagrama ER', icon: <Layers className="w-4 h-4" /> },
          { id: 'optimization' as const, label: 'Optimización', icon: <Zap className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${
              activeTab === tab.id ? 'border-brand-500 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'schema' && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <button onClick={expandAll} className="text-xs text-brand-600 hover:underline">Expandir todo</button>
            <span className="text-slate-300">|</span>
            <button onClick={collapseAll} className="text-xs text-brand-600 hover:underline">Colapsar todo</button>
          </div>

          {SQL_SECTIONS.map((section, idx) => (
            <div key={idx} className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
              <button
                onClick={() => toggleSection(idx)}
                className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 transition-colors text-left"
              >
                {expandedSections.has(idx) ? <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
                <span className="text-xl">{section.icon}</span>
                <div className="flex-1">
                  <p className="font-semibold text-slate-800 text-sm">{section.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{section.description}</p>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); copySQL(section.sql, idx); }}
                  className="shrink-0 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                  title="Copiar SQL"
                >
                  {copiedIdx === idx ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-slate-400" />}
                </button>
              </button>
              {expandedSections.has(idx) && (
                <div className="border-t border-slate-100">
                  <pre className="p-4 text-xs text-slate-700 overflow-x-auto bg-slate-50 leading-relaxed font-mono max-h-96 overflow-y-auto">
                    {section.sql}
                  </pre>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'er' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-brand-500" /> Diagrama Entidad-Relación (Textual)
          </h3>
          <pre className="text-xs text-slate-700 overflow-x-auto bg-slate-50 rounded-xl p-6 leading-relaxed font-mono">
            {ER_DIAGRAM}
          </pre>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-brand-50 border border-brand-200">
              <h4 className="font-semibold text-brand-800 text-sm mb-2">📐 Relaciones Principales</h4>
              <ul className="text-xs text-brand-700 space-y-1">
                <li>• <strong>clinics → users</strong>: 1:N (multi-tenant)</li>
                <li>• <strong>users → dentists</strong>: 1:1 (perfil profesional)</li>
                <li>• <strong>patients → appointments</strong>: 1:N</li>
                <li>• <strong>patients → treatments</strong>: 1:N</li>
                <li>• <strong>patients → invoices</strong>: 1:N</li>
                <li>• <strong>treatments → odontogram_entries</strong>: 1:N</li>
                <li>• <strong>invoices → payments</strong>: 1:N</li>
                <li>• <strong>invoices → installment_plans → installments</strong>: 1:1:N</li>
              </ul>
            </div>
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
              <h4 className="font-semibold text-emerald-800 text-sm mb-2">🔑 Claves y Restricciones</h4>
              <ul className="text-xs text-emerald-700 space-y-1">
                <li>• Primary Keys: UUID (CHAR 36) para distribución</li>
                <li>• Foreign Keys: ON DELETE RESTRICT/CASCADE según contexto</li>
                <li>• CHECK constraints para validación de datos</li>
                <li>• UNIQUE indexes para email, invoice_number, sku</li>
                <li>• Columnas GENERATED para cálculos automáticos</li>
                <li>• ENUM para valores controlados y validación</li>
                <li>• Soft deletes con deleted_at</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'optimization' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" /> Recomendaciones de Optimización
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {OPTIMIZATION_TIPS.map((tip, i) => (
                <div key={i} className="p-4 rounded-xl bg-amber-50 border border-amber-100">
                  <p className="font-semibold text-amber-800 text-sm mb-1">⚡ {tip.title}</p>
                  <p className="text-xs text-amber-700">{tip.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              🚀 Estrategia de Escalado para Miles de Clínicas
            </h3>
            <div className="space-y-3">
              {SCALING_TIPS.map((tip, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-slate-50">
                  <span className="w-6 h-6 bg-brand-100 text-brand-700 rounded-full flex items-center justify-center text-xs font-bold shrink-0">{i + 1}</span>
                  <p className="text-sm text-slate-700">{tip}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-r from-brand-600 to-violet-600 rounded-2xl p-6 text-white">
            <h3 className="text-lg font-semibold mb-3">📊 Métricas de la Base de Datos</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
                <p className="text-2xl font-bold">22</p>
                <p className="text-xs text-white/80">Tablas</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
                <p className="text-2xl font-bold">3FN+</p>
                <p className="text-xs text-white/80">Normalización</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
                <p className="text-2xl font-bold">35+</p>
                <p className="text-xs text-white/80">Foreign Keys</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
                <p className="text-2xl font-bold">60+</p>
                <p className="text-xs text-white/80">Índices</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-3 flex items-center gap-3">
      <div className="text-brand-500">{icon}</div>
      <div>
        <p className="text-lg font-bold text-slate-800">{value}</p>
        <p className="text-xs text-slate-500">{label}</p>
      </div>
    </div>
  );
}
