import { useState } from 'react';
import { DollarSign, FileText, Search, TrendingUp, CheckCircle, Clock, Eye, CreditCard, X, Plus, Trash2 } from 'lucide-react';
import { useAppState } from '../store/context';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function Billing() {
  const { invoices, getPatientName, patients } = useAppState();
  const [filter, setFilter] = useState<'all' | 'pending' | 'partial' | 'paid' | 'overdue'>('all');
  const [search, setSearch] = useState('');
  const [showNewInvoice, setShowNewInvoice] = useState(false);

  const filtered = invoices.filter(inv => {
    const matchFilter = filter === 'all' || inv.status === filter;
    const matchSearch = getPatientName(inv.patientId).toLowerCase().includes(search.toLowerCase()) || inv.id.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const totalInvoiced = invoices.reduce((s, i) => s + i.total, 0);
  const totalCollected = invoices.reduce((s, i) => s + i.paid, 0);
  const totalPending = totalInvoiced - totalCollected;
  const collectionRate = totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0;

  const monthlyData = [
    { month: 'Sep', facturado: 5800, cobrado: 4200 },
    { month: 'Oct', facturado: 4900, cobrado: 4100 },
    { month: 'Nov', facturado: 6100, cobrado: 5000 },
    { month: 'Dic', facturado: 5300, cobrado: 4800 },
    { month: 'Ene', facturado: totalInvoiced, cobrado: totalCollected },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Facturación</h1>
          <p className="text-slate-500">Gestión de pagos y facturas</p>
        </div>
        <button onClick={() => setShowNewInvoice(true)} className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200">
          <FileText className="w-4 h-4" /> Nueva Factura
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-3">
            <div className="bg-sky-500 text-white p-2.5 rounded-xl"><DollarSign className="w-5 h-5" /></div>
            <div>
              <p className="text-sm text-slate-500">Total Facturado</p>
              <p className="text-2xl font-bold text-slate-800">${totalInvoiced.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-500 text-white p-2.5 rounded-xl"><CheckCircle className="w-5 h-5" /></div>
            <div>
              <p className="text-sm text-slate-500">Total Cobrado</p>
              <p className="text-2xl font-bold text-emerald-600">${totalCollected.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 text-white p-2.5 rounded-xl"><Clock className="w-5 h-5" /></div>
            <div>
              <p className="text-sm text-slate-500">Pendiente</p>
              <p className="text-2xl font-bold text-amber-600">${totalPending.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-3">
            <div className="bg-violet-500 text-white p-2.5 rounded-xl"><TrendingUp className="w-5 h-5" /></div>
            <div>
              <p className="text-sm text-slate-500">Tasa de Cobro</p>
              <p className="text-2xl font-bold text-violet-600">{collectionRate}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Facturación vs Cobros Mensuales</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
            <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={v => `$${v}`} />
            <Tooltip formatter={(v) => `$${Number(v).toLocaleString()}`} />
            <Bar dataKey="facturado" fill="#0EA5E9" radius={[6, 6, 0, 0]} name="Facturado" />
            <Bar dataKey="cobrado" fill="#10B981" radius={[6, 6, 0, 0]} name="Cobrado" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" placeholder="Buscar factura o paciente..." value={search} onChange={e => setSearch(e.target.value)} className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {(['all', 'pending', 'partial', 'paid', 'overdue'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-3 py-2 rounded-xl text-sm font-medium transition-colors ${filter === f ? 'bg-sky-500 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
              {f === 'all' ? 'Todas' : f === 'pending' ? 'Pendientes' : f === 'partial' ? 'Parciales' : f === 'paid' ? 'Pagadas' : 'Vencidas'}
            </button>
          ))}
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-slate-500">
                <th className="px-6 py-3 font-medium">Factura</th>
                <th className="px-6 py-3 font-medium">Paciente</th>
                <th className="px-6 py-3 font-medium">Fecha</th>
                <th className="px-6 py-3 font-medium">Vencimiento</th>
                <th className="px-6 py-3 font-medium">Total</th>
                <th className="px-6 py-3 font-medium">Pagado</th>
                <th className="px-6 py-3 font-medium">Saldo</th>
                <th className="px-6 py-3 font-medium">Estado</th>
                <th className="px-6 py-3 font-medium">Cuotas</th>
                <th className="px-6 py-3 font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(inv => (
                <tr key={inv.id} className="border-t border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer">
                  <td className="px-6 py-4 font-medium text-sky-600">#{inv.id.toUpperCase()}</td>
                  <td className="px-6 py-4 text-slate-800 font-medium">{getPatientName(inv.patientId)}</td>
                  <td className="px-6 py-4 text-slate-600">{inv.date}</td>
                  <td className="px-6 py-4 text-slate-600">{inv.dueDate}</td>
                  <td className="px-6 py-4 font-bold text-slate-800">${inv.total.toLocaleString()}</td>
                  <td className="px-6 py-4 text-emerald-600 font-medium">${inv.paid.toLocaleString()}</td>
                  <td className="px-6 py-4 text-amber-600 font-medium">${(inv.total - inv.paid).toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                      inv.status === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                      inv.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                      inv.status === 'overdue' ? 'bg-red-100 text-red-700' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {inv.status === 'paid' ? 'Pagada' : inv.status === 'partial' ? 'Parcial' : inv.status === 'overdue' ? 'Vencida' : 'Pendiente'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {inv.installmentPlan ? (
                      <span className="text-xs text-violet-600 font-medium">
                        {inv.installmentPlan.installments.filter(i => i.status === 'paid').length}/{inv.installmentPlan.totalInstallments}
                      </span>
                    ) : '-'}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors" title="Ver detalle">
                        <Eye className="w-3.5 h-3.5 text-slate-400" />
                      </button>
                      {inv.status !== 'paid' && (
                        <button className="p-1.5 rounded-lg hover:bg-emerald-50 transition-colors" title="Registrar pago">
                          <CreditCard className="w-3.5 h-3.5 text-emerald-500" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Invoice Modal */}
      {showNewInvoice && <NewInvoiceModal patients={patients} getPatientName={getPatientName} onClose={() => setShowNewInvoice(false)} />}
    </div>
  );
}

function NewInvoiceModal({ patients, getPatientName: _gpn, onClose }: { patients: ReturnType<typeof useAppState>['patients']; getPatientName: (id: string) => string; onClose: () => void }) {
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [items, setItems] = useState([{ id: '1', description: '', quantity: 1, unitPrice: 0 }]);
  const [taxRate, setTaxRate] = useState(18);
  const [submitted, setSubmitted] = useState(false);

  void _gpn;

  const addItem = () => {
    setItems(prev => [...prev, { id: Date.now().toString(), description: '', quantity: 1, unitPrice: 0 }]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) setItems(prev => prev.filter(i => i.id !== id));
  };

  const updateItem = (id: string, field: string, value: string | number) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const subtotal = items.reduce((s, i) => s + (i.quantity * i.unitPrice), 0);
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(onClose, 1500);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-8 text-center max-w-sm animate-slide-in" onClick={e => e.stopPropagation()}>
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800">¡Factura Creada!</h3>
          <p className="text-sm text-slate-500 mt-2">Total: ${total.toLocaleString()}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-slide-in" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-slate-100 p-5 flex items-center justify-between rounded-t-2xl z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Nueva Factura</h2>
            <p className="text-sm text-slate-500">Crear una nueva factura para un paciente</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100"><X className="w-5 h-5 text-slate-400" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Paciente *</label>
            <select value={patientId} onChange={e => setPatientId(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required>
              {patients.map(p => <option key={p.id} value={p.id}>{p.firstName} {p.lastName}</option>)}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-medium text-slate-600">Items de la factura</label>
              <button type="button" onClick={addItem} className="flex items-center gap-1 text-xs text-sky-600 hover:text-sky-700 font-medium">
                <Plus className="w-3 h-3" /> Agregar item
              </button>
            </div>
            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-5">
                    {idx === 0 && <span className="text-[10px] text-slate-400">Descripción</span>}
                    <input type="text" value={item.description} onChange={e => updateItem(item.id, 'description', e.target.value)} placeholder="Descripción..." className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
                  </div>
                  <div className="col-span-2">
                    {idx === 0 && <span className="text-[10px] text-slate-400">Cantidad</span>}
                    <input type="number" min={1} value={item.quantity} onChange={e => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)} className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-center focus:outline-none focus:ring-2 focus:ring-sky-500" />
                  </div>
                  <div className="col-span-3">
                    {idx === 0 && <span className="text-[10px] text-slate-400">Precio</span>}
                    <input type="number" min={0} step={0.01} value={item.unitPrice} onChange={e => updateItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)} placeholder="0.00" className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" required />
                  </div>
                  <div className="col-span-2 flex items-center gap-2">
                    {idx === 0 && <span className="text-[10px] text-slate-400 block">Total</span>}
                    <span className="text-sm font-medium text-slate-700">${(item.quantity * item.unitPrice).toFixed(2)}</span>
                    {items.length > 1 && (
                      <button type="button" onClick={() => removeItem(item.id)} className="p-1 rounded hover:bg-red-50 text-red-400 hover:text-red-600">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <label className="text-xs font-medium text-slate-600">ITBIS / IVA (%)</label>
            <input type="number" min={0} max={100} value={taxRate} onChange={e => setTaxRate(parseFloat(e.target.value) || 0)} className="w-20 px-3 py-2 rounded-lg border border-slate-200 text-sm text-center focus:outline-none focus:ring-2 focus:ring-sky-500" />
          </div>

          <div className="bg-slate-50 rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm"><span className="text-slate-500">Subtotal</span><span className="font-medium">${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-500">ITBIS ({taxRate}%)</span><span className="font-medium">${tax.toFixed(2)}</span></div>
            <div className="flex justify-between text-lg border-t border-slate-200 pt-2"><span className="font-bold text-slate-800">Total</span><span className="font-bold text-sky-600">${total.toFixed(2)}</span></div>
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-100">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50">Cancelar</button>
            <button type="submit" className="flex-1 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium shadow-lg shadow-sky-200">Crear Factura</button>
          </div>
        </form>
      </div>
    </div>
  );
}
