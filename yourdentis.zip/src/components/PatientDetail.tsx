import { ArrowLeft, Phone, Mail, MapPin, Calendar, Shield, AlertTriangle, FileText, DollarSign, Clock, Heart } from 'lucide-react';
import { useAppState } from '../store/context';

export function PatientDetail({ patientId, onBack }: { patientId: string; onBack: () => void }) {
  const { patients, treatments, appointments, invoices, clinicalNotes, getDentistName } = useAppState();
  const patient = patients.find(p => p.id === patientId);
  if (!patient) return null;

  const patientTreatments = treatments.filter(t => t.patientId === patientId);
  const patientAppointments = appointments.filter(a => a.patientId === patientId).sort((a, b) => b.date.localeCompare(a.date));
  const patientInvoices = invoices.filter(i => i.patientId === patientId);
  const patientNotes = clinicalNotes.filter(n => n.patientId === patientId);
  const totalPaid = patientInvoices.reduce((s, i) => s + i.paid, 0);
  const totalPending = patientInvoices.reduce((s, i) => s + (i.total - i.paid), 0);
  const initials = `${patient.firstName[0]}${patient.lastName[0]}`;
  const age = new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear();

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-sky-600 transition-colors text-sm">
        <ArrowLeft className="w-4 h-4" /> Volver a pacientes
      </button>

      {/* Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center text-white font-bold text-2xl shrink-0">
            {initials}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-slate-800">{patient.firstName} {patient.lastName}</h1>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${patient.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                {patient.status === 'active' ? 'Activo' : 'Inactivo'}
              </span>
            </div>
            <p className="text-slate-500 mt-1">{age} años • {patient.gender === 'M' ? 'Masculino' : 'Femenino'} • Registro: {patient.registeredAt}</p>
            <div className="flex flex-wrap gap-4 mt-3">
              <span className="flex items-center gap-1.5 text-sm text-slate-600"><Phone className="w-4 h-4 text-slate-400" />{patient.phone}</span>
              <span className="flex items-center gap-1.5 text-sm text-slate-600"><Mail className="w-4 h-4 text-slate-400" />{patient.email}</span>
              <span className="flex items-center gap-1.5 text-sm text-slate-600"><MapPin className="w-4 h-4 text-slate-400" />{patient.address}</span>
              {patient.insuranceProvider && <span className="flex items-center gap-1.5 text-sm text-emerald-600"><Shield className="w-4 h-4" />{patient.insuranceProvider} ({patient.insuranceNumber})</span>}
            </div>
          </div>
          <div className="flex gap-3 shrink-0">
            <div className="text-center p-3 rounded-xl bg-sky-50">
              <p className="text-2xl font-bold text-sky-600">${totalPaid.toLocaleString()}</p>
              <p className="text-xs text-sky-500">Pagado</p>
            </div>
            <div className="text-center p-3 rounded-xl bg-amber-50">
              <p className="text-2xl font-bold text-amber-600">${totalPending.toLocaleString()}</p>
              <p className="text-xs text-amber-500">Pendiente</p>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><Heart className="w-5 h-5 text-red-500" /> Historial Médico</h3>
          <div className="space-y-3">
            <InfoRow label="Antecedentes" value={patient.medicalHistory} />
            <InfoRow label="Alergias" value={patient.allergies.length > 0 ? patient.allergies.join(', ') : 'Ninguna'} alert={patient.allergies.length > 0} />
            <InfoRow label="Medicamentos" value={patient.medications.length > 0 ? patient.medications.join(', ') : 'Ninguno'} />
            <InfoRow label="Contacto emergencia" value={`${patient.emergencyContact} (${patient.emergencyPhone})`} />
            {patient.notes && <InfoRow label="Notas" value={patient.notes} />}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><FileText className="w-5 h-5 text-violet-500" /> Notas Clínicas</h3>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {patientNotes.length === 0 ? <p className="text-slate-400 text-sm">Sin notas clínicas</p> : patientNotes.map(note => (
              <div key={note.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-slate-500">{note.date}</span>
                  <span className="text-xs text-violet-600">{getDentistName(note.dentistId)}</span>
                </div>
                <p className="text-sm font-medium text-slate-700">{note.diagnosis}</p>
                <p className="text-xs text-slate-500 mt-1">{note.evolution}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Treatments */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><Calendar className="w-5 h-5 text-emerald-500" /> Tratamientos</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500 border-b border-slate-100">
                <th className="pb-3 font-medium">Fecha</th>
                <th className="pb-3 font-medium">Tipo</th>
                <th className="pb-3 font-medium">Descripción</th>
                <th className="pb-3 font-medium">Diente</th>
                <th className="pb-3 font-medium">Odontólogo</th>
                <th className="pb-3 font-medium">Costo</th>
                <th className="pb-3 font-medium">Estado</th>
              </tr>
            </thead>
            <tbody>
              {patientTreatments.map(t => (
                <tr key={t.id} className="border-b border-slate-50 hover:bg-slate-50">
                  <td className="py-3 text-slate-600">{t.date}</td>
                  <td className="py-3 font-medium text-slate-800">{t.type}</td>
                  <td className="py-3 text-slate-600">{t.description}</td>
                  <td className="py-3 text-slate-600">{t.toothNumber || '-'}</td>
                  <td className="py-3 text-slate-600">{getDentistName(t.dentistId)}</td>
                  <td className="py-3 font-medium text-slate-800">${t.cost}</td>
                  <td className="py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      t.status === 'completed' ? 'bg-emerald-100 text-emerald-700' :
                      t.status === 'in-progress' ? 'bg-sky-100 text-sky-700' : 'bg-amber-100 text-amber-700'
                    }`}>{t.status === 'completed' ? 'Completado' : t.status === 'in-progress' ? 'En progreso' : 'Planificado'}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Appointments & Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><Clock className="w-5 h-5 text-sky-500" /> Historial de Citas</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {patientAppointments.map(apt => (
              <div key={apt.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <div className="w-1 h-10 rounded-full" style={{ backgroundColor: apt.color }} />
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-700">{apt.type}</p>
                  <p className="text-xs text-slate-500">{apt.date} • {apt.startTime}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  apt.status === 'completed' ? 'bg-emerald-100 text-emerald-700' :
                  apt.status === 'confirmed' ? 'bg-sky-100 text-sky-700' :
                  apt.status === 'no-show' ? 'bg-red-100 text-red-700' :
                  'bg-amber-100 text-amber-700'
                }`}>{apt.status === 'completed' ? 'Completada' : apt.status === 'confirmed' ? 'Confirmada' : apt.status === 'no-show' ? 'No asistió' : 'Programada'}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><DollarSign className="w-5 h-5 text-amber-500" /> Facturas</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {patientInvoices.map(inv => (
              <div key={inv.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-700">Factura #{inv.id.toUpperCase()}</p>
                  <p className="text-xs text-slate-500">{inv.date} • {inv.items.length} items</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-800">${inv.total.toLocaleString()}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    inv.status === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                    inv.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>{inv.status === 'paid' ? 'Pagada' : inv.status === 'partial' ? 'Parcial' : 'Pendiente'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value, alert = false }: { label: string; value: string; alert?: boolean }) {
  return (
    <div className="flex gap-2">
      <span className="text-xs text-slate-400 w-28 shrink-0">{label}</span>
      <span className={`text-sm ${alert ? 'text-red-600 font-medium flex items-center gap-1' : 'text-slate-700'}`}>
        {alert && <AlertTriangle className="w-3 h-3" />}{value}
      </span>
    </div>
  );
}
