import React, { useState, useMemo } from 'react';
import { Download, RotateCcw, Info, UserCircle, History, ChevronDown, Save, Check } from 'lucide-react';
import { useAppState } from '../store/context';
import { OdontogramClassic } from './OdontogramClassic';

type ToothStatus = 'healthy' | 'cavity' | 'filling' | 'crown' | 'extraction' | 'root-canal' | 'implant' | 'sealant';

interface ToothData {
  number: number;
  status: ToothStatus;
  surfaces: { top: ToothStatus; bottom: ToothStatus; left: ToothStatus; right: ToothStatus; center: ToothStatus };
  notes: string;
  history: { date: string; condition: ToothStatus; surface?: string }[];
}

const STATUS_COLORS: Record<ToothStatus, string> = {
  healthy: '#FFFFFF',
  cavity: '#EF4444',
  filling: '#3B82F6',
  crown: '#F59E0B',
  extraction: '#6B7280',
  'root-canal': '#8B5CF6',
  implant: '#10B981',
  sealant: '#EC4899',
};

const STATUS_BG: Record<ToothStatus, string> = {
  healthy: '#f8fafc',
  cavity: '#fef2f2',
  filling: '#eff6ff',
  crown: '#fffbeb',
  extraction: '#f9fafb',
  'root-canal': '#f5f3ff',
  implant: '#ecfdf5',
  sealant: '#fdf2f8',
};

const STATUS_LABELS: Record<ToothStatus, string> = {
  healthy: 'Sano',
  cavity: 'Caries',
  filling: 'Obturación',
  crown: 'Corona',
  extraction: 'Extracción',
  'root-canal': 'Endodoncia',
  implant: 'Implante',
  sealant: 'Sellante',
};

const STATUS_ICONS: Record<ToothStatus, string> = {
  healthy: '✓',
  cavity: '●',
  filling: '◆',
  crown: '♛',
  extraction: '✕',
  'root-canal': '⊕',
  implant: '⬡',
  sealant: '◐',
};

const UPPER_TEETH = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const LOWER_TEETH = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

// Tooth type classification
function getToothType(num: number): 'molar' | 'premolar' | 'canine' | 'lateral' | 'central' {
  const n = num % 10;
  if (n >= 6) return 'molar';
  if (n >= 4) return 'premolar';
  if (n === 3) return 'canine';
  if (n === 2) return 'lateral';
  return 'central';
}

function getToothName(num: number): string {
  const type = getToothType(num);
  const names: Record<string, string> = {
    molar: 'Molar',
    premolar: 'Premolar',
    canine: 'Canino',
    lateral: 'Incisivo Lateral',
    central: 'Incisivo Central',
  };
  const quadrant = Math.floor(num / 10);
  const side = quadrant === 1 || quadrant === 4 ? 'Derecho' : 'Izquierdo';
  const arch = quadrant <= 2 ? 'Superior' : 'Inferior';
  return `${names[type]} ${arch} ${side}`;
}

const defaultSurfaces = (): ToothData['surfaces'] => ({
  top: 'healthy', bottom: 'healthy', left: 'healthy', right: 'healthy', center: 'healthy'
});

function createInitialTeeth(): Record<number, ToothData> {
  const teeth: Record<number, ToothData> = {};
  [...UPPER_TEETH, ...LOWER_TEETH].forEach(n => {
    teeth[n] = { number: n, status: 'healthy', surfaces: defaultSurfaces(), notes: '', history: [] };
  });
  teeth[16].surfaces.top = 'cavity';
  teeth[16].surfaces.center = 'cavity';
  teeth[16].history = [{ date: '2025-01-10', condition: 'cavity', surface: 'oclusal' }];
  teeth[26].surfaces.center = 'filling';
  teeth[26].history = [{ date: '2024-11-15', condition: 'filling', surface: 'centro' }];
  teeth[36].status = 'extraction';
  teeth[36].history = [{ date: '2024-12-15', condition: 'extraction' }];
  teeth[46].surfaces.center = 'root-canal';
  teeth[46].history = [{ date: '2025-01-08', condition: 'root-canal' }];
  teeth[11].status = 'crown';
  teeth[11].history = [{ date: '2024-10-20', condition: 'crown' }];
  teeth[37].surfaces.top = 'filling';
  teeth[37].surfaces.left = 'filling';
  teeth[24].surfaces.center = 'sealant';
  teeth[24].history = [{ date: '2024-09-05', condition: 'sealant', surface: 'oclusal' }];
  return teeth;
}

export function Odontogram() {
  const { settings } = useAppState();

  if (settings.odontogramView === 'classic') {
    return <OdontogramClassic />;
  }

  return <OdontogramRealistic />;
}

function OdontogramRealistic() {
  const { patients } = useAppState();
  const [teeth, setTeeth] = useState<Record<number, ToothData>>(createInitialTeeth);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [currentTool, setCurrentTool] = useState<ToothStatus>('cavity');
  const [selectedPatient, setSelectedPatient] = useState(patients[0]?.id || '');
  const [toothNotes, setToothNotes] = useState('');
  const [showHistory, setShowHistory] = useState(false);

  const patient = patients.find(p => p.id === selectedPatient);
  const [saveMessage, setSaveMessage] = useState('');

  const handleSave = () => {
    setSaveMessage('✓ Odontograma guardado exitosamente');
    setTimeout(() => setSaveMessage(''), 3000);
  };

  const handleExportPDF = () => {
    // Generate a text-based PDF-like download
    const toothData = Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy'));
    let content = '🦷 YOURDENTIS - ODONTOGRAMA DIGITAL\n';
    content += '═══════════════════════════════════════\n\n';
    content += `Paciente: ${patient ? `${patient.firstName} ${patient.lastName}` : 'N/A'}\n`;
    content += `Fecha: ${new Date().toLocaleDateString('es-DO')}\n`;
    content += `Hora: ${new Date().toLocaleTimeString('es-DO')}\n\n`;
    content += '─── ESTADO DE DIENTES ───\n\n';
    if (toothData.length === 0) {
      content += 'Todos los dientes en buen estado.\n';
    } else {
      toothData.forEach(t => {
        content += `Diente #${t.number} - ${getToothName(t.number)}\n`;
        content += `  Estado: ${STATUS_LABELS[t.status]}\n`;
        const surfaces = Object.entries(t.surfaces).filter(([, s]) => s !== 'healthy');
        if (surfaces.length > 0) {
          surfaces.forEach(([surf, status]) => {
            content += `  Superficie ${surf}: ${STATUS_LABELS[status]}\n`;
          });
        }
        if (t.notes) content += `  Notas: ${t.notes}\n`;
        content += '\n';
      });
    }
    content += '\n─── RESUMEN ───\n';
    content += `Total dientes: 32\n`;
    content += `Sanos: ${32 - toothData.length}\n`;
    content += `Con condición: ${toothData.length}\n`;
    content += `Extraídos: ${Object.values(teeth).filter(t => t.status === 'extraction').length}\n`;
    content += '\n\n© YourDentis - Sistema de Gestión Odontológica\n';

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `odontograma_${patient ? patient.lastName : 'paciente'}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleToothClick = (toothNum: number) => {
    const tooth = teeth[toothNum];
    if (currentTool === 'extraction' || currentTool === 'crown' || currentTool === 'implant') {
      setTeeth(prev => {
        const t = { ...prev[toothNum] };
        t.status = t.status === currentTool ? 'healthy' : currentTool;
        t.history = [...t.history, { date: new Date().toISOString().split('T')[0], condition: currentTool }];
        return { ...prev, [toothNum]: t };
      });
    } else {
      setTeeth(prev => {
        const t = { ...prev[toothNum] };
        const surfaces = { ...t.surfaces };
        surfaces.center = surfaces.center === currentTool ? 'healthy' : currentTool;
        t.surfaces = surfaces;
        t.history = [...t.history, { date: new Date().toISOString().split('T')[0], condition: currentTool, surface: 'centro' }];
        return { ...prev, [toothNum]: t };
      });
    }
    setSelectedTooth(toothNum);
    setToothNotes(tooth?.notes || '');
  };

  const handleSurfaceClick = (toothNum: number, surface: keyof ToothData['surfaces']) => {
    setTeeth(prev => {
      const t = { ...prev[toothNum] };
      const surfaces = { ...t.surfaces };
      if (currentTool === 'extraction' || currentTool === 'crown' || currentTool === 'implant') {
        t.status = t.status === currentTool ? 'healthy' : currentTool;
      } else {
        surfaces[surface] = surfaces[surface] === currentTool ? 'healthy' : currentTool;
        t.surfaces = surfaces;
      }
      t.history = [...t.history, { date: new Date().toISOString().split('T')[0], condition: currentTool, surface }];
      return { ...prev, [toothNum]: t };
    });
    setSelectedTooth(toothNum);
    setToothNotes(teeth[toothNum]?.notes || '');
  };

  const resetTooth = (num: number) => {
    setTeeth(prev => ({
      ...prev,
      [num]: { number: num, status: 'healthy', surfaces: defaultSurfaces(), notes: '', history: prev[num].history }
    }));
    setToothNotes('');
  };

  const resetAll = () => {
    setTeeth(createInitialTeeth());
    setSelectedTooth(null);
    setToothNotes('');
  };

  const saveNotes = (num: number, notes: string) => {
    setTeeth(prev => ({ ...prev, [num]: { ...prev[num], notes } }));
  };

  const tooth = selectedTooth ? teeth[selectedTooth] : null;

  const conditionCounts = useMemo(() => {
    return Object.values(teeth).reduce((acc, t) => {
      if (t.status !== 'healthy') acc[t.status] = (acc[t.status] || 0) + 1;
      Object.values(t.surfaces).forEach(s => {
        if (s !== 'healthy') acc[s] = (acc[s] || 0) + 1;
      });
      return acc;
    }, {} as Record<string, number>);
  }, [teeth]);

  const totalAffected = Object.keys(conditionCounts).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Odontograma Digital</h1>
          <p className="text-slate-500">Diagrama dental interactivo — Haga clic en cualquier diente para marcarlo</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {saveMessage && (
            <span className="flex items-center gap-1 text-sm text-emerald-600 font-medium animate-fade-in px-3 py-2">
              <Check className="w-4 h-4" /> {saveMessage}
            </span>
          )}
          <button onClick={resetAll} className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-medium transition-colors text-sm">
            <RotateCcw className="w-4 h-4" /> Resetear
          </button>
          <button onClick={handleExportPDF} className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-sky-200 text-sm">
            <Download className="w-4 h-4" /> Exportar PDF
          </button>
          <button onClick={handleSave} className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-emerald-200 text-sm">
            <Save className="w-4 h-4" /> Guardar
          </button>
        </div>
      </div>

      {/* Patient Selector */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-3 flex-1">
            <UserCircle className="w-5 h-5 text-brand-500 shrink-0" />
            <select
              value={selectedPatient}
              onChange={e => { setSelectedPatient(e.target.value); resetAll(); }}
              className="flex-1 px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>{p.firstName} {p.lastName} — {p.idNumber}</option>
              ))}
            </select>
          </div>
          {patient && (
            <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
              <span>Edad: {new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear()} años</span>
              <span>Última visita: {patient.lastVisit || 'N/A'}</span>
              {patient.allergies.length > 0 && (
                <span className="text-red-600 font-medium">⚠ Alergias: {patient.allergies.join(', ')}</span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Tool Palette */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <p className="text-sm font-medium text-slate-600 mb-3">🔧 Herramientas de marcado — Seleccione una condición y haga clic en el diente:</p>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(STATUS_COLORS) as ToothStatus[]).map(status => (
            <button
              key={status}
              onClick={() => setCurrentTool(status)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${
                currentTool === status
                  ? 'ring-2 ring-offset-2 ring-sky-500 shadow-lg scale-105 border-sky-300'
                  : 'hover:bg-slate-50 border-slate-200'
              }`}
              style={{
                backgroundColor: currentTool === status ? STATUS_BG[status] : 'white',
                color: STATUS_COLORS[status] === '#FFFFFF' ? '#64748b' : STATUS_COLORS[status]
              }}
            >
              <span className="text-base">{STATUS_ICONS[status]}</span>
              <span className="w-3 h-3 rounded-full border border-white shadow-sm" style={{ backgroundColor: STATUS_COLORS[status] === '#FFFFFF' ? '#e2e8f0' : STATUS_COLORS[status] }} />
              {STATUS_LABELS[status]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main Odontogram Area */}
        <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
          {/* Mouth Background Container */}
          <div className="relative" style={{
            background: 'linear-gradient(180deg, #fce4ec 0%, #f8bbd0 15%, #ef9a9a 30%, #e57373 50%, #ef9a9a 70%, #f8bbd0 85%, #fce4ec 100%)',
            minHeight: '600px',
          }}>
            {/* Inner mouth (tongue area) */}
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 mx-auto" style={{
              width: '75%',
              height: '35%',
              background: 'radial-gradient(ellipse at center, #c62828 0%, #b71c1c 40%, #d32f2f 70%, transparent 100%)',
              borderRadius: '50%',
              opacity: 0.4,
            }} />

            {/* Lip highlight top */}
            <div className="absolute top-0 left-0 right-0 h-16" style={{
              background: 'linear-gradient(to bottom, rgba(255,255,255,0.3), transparent)',
            }} />
            {/* Lip highlight bottom */}
            <div className="absolute bottom-0 left-0 right-0 h-16" style={{
              background: 'linear-gradient(to top, rgba(255,255,255,0.3), transparent)',
            }} />

            {/* Gum line top */}
            <div className="absolute top-0 left-0 right-0" style={{
              height: '42%',
              background: 'linear-gradient(to bottom, #ffab91 0%, #ff8a65 60%, transparent 100%)',
              borderRadius: '0 0 50% 50%',
              opacity: 0.6,
            }} />

            {/* Gum line bottom */}
            <div className="absolute bottom-0 left-0 right-0" style={{
              height: '42%',
              background: 'linear-gradient(to top, #ffab91 0%, #ff8a65 60%, transparent 100%)',
              borderRadius: '50% 50% 0 0',
              opacity: 0.6,
            }} />

            <div className="relative z-10 px-3 sm:px-6 py-6">
              {/* Title */}
              <div className="text-center mb-3">
                <span className="inline-block px-4 py-1 bg-white/80 backdrop-blur-sm rounded-full text-xs font-semibold text-slate-700 shadow-sm">
                  ARCADA SUPERIOR
                </span>
              </div>

              {/* Upper Teeth - arranged in arch */}
              <div className="flex justify-center items-end gap-0 sm:gap-0.5 mb-2">
                {UPPER_TEETH.map((num, idx) => (
                  <RealisticTooth
                    key={num}
                    tooth={teeth[num]}
                    isSelected={selectedTooth === num}
                    onClick={() => handleToothClick(num)}
                    onSurfaceClick={(surface) => handleSurfaceClick(num, surface)}
                    isUpper={true}
                    archPosition={idx}
                    totalInArch={16}
                  />
                ))}
              </div>

              {/* Center line */}
              <div className="relative my-5">
                <div className="border-t-2 border-dashed border-white/40 mx-8" />
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                  <span className="inline-block px-4 py-1 bg-white/90 backdrop-blur-sm rounded-full text-[10px] font-bold text-slate-500 shadow-sm tracking-wider">
                    LÍNEA MEDIA OCLUSAL
                  </span>
                </div>
              </div>

              {/* Lower Teeth - arranged in arch */}
              <div className="flex justify-center items-start gap-0 sm:gap-0.5 mt-2">
                {LOWER_TEETH.map((num, idx) => (
                  <RealisticTooth
                    key={num}
                    tooth={teeth[num]}
                    isSelected={selectedTooth === num}
                    onClick={() => handleToothClick(num)}
                    onSurfaceClick={(surface) => handleSurfaceClick(num, surface)}
                    isUpper={false}
                    archPosition={idx}
                    totalInArch={16}
                  />
                ))}
              </div>

              {/* Title */}
              <div className="text-center mt-3">
                <span className="inline-block px-4 py-1 bg-white/80 backdrop-blur-sm rounded-full text-xs font-semibold text-slate-700 shadow-sm">
                  ARCADA INFERIOR
                </span>
              </div>
            </div>
          </div>

          {/* Legend and summary */}
          <div className="p-4 bg-slate-50 border-t border-slate-200">
            <div className="flex flex-wrap gap-3 justify-center mb-3">
              {(Object.keys(STATUS_COLORS) as ToothStatus[]).map(s => (
                <span key={s} className="flex items-center gap-1.5 text-xs text-slate-600 bg-white px-2.5 py-1.5 rounded-lg border border-slate-100">
                  <span className="w-3 h-3 rounded-full border border-slate-200 shadow-sm"
                    style={{ backgroundColor: STATUS_COLORS[s] === '#FFFFFF' ? '#e2e8f0' : STATUS_COLORS[s] }} />
                  <span className="font-medium">{STATUS_LABELS[s]}</span>
                  {conditionCounts[s] ? <span className="text-slate-400 font-bold">({conditionCounts[s]})</span> : null}
                </span>
              ))}
            </div>
            <div className="text-center">
              <span className="text-xs text-slate-400">
                {totalAffected > 0
                  ? `${totalAffected} tipo(s) de condición detectada(s) · Haga clic en un diente para ver detalles`
                  : 'Todos los dientes en buen estado · Use las herramientas para marcar condiciones'
                }
              </span>
            </div>
          </div>
        </div>

        {/* Tooth Detail Panel */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Info className="w-5 h-5 text-sky-500" /> Detalle del Diente
            </h3>
            {tooth ? (
              <div className="space-y-4">
                {/* Tooth big preview */}
                <div className="text-center p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200">
                  <div className="mx-auto mb-3" style={{ width: 80, height: 100 }}>
                    <BigToothPreview tooth={tooth} />
                  </div>
                  <p className="text-3xl font-black text-slate-800">#{tooth.number}</p>
                  <p className="text-sm text-slate-500 mt-1">{getToothName(tooth.number)}</p>
                  <p className="text-xs mt-2 font-medium" style={{
                    color: tooth.status !== 'healthy' ? STATUS_COLORS[tooth.status] : '#10b981'
                  }}>
                    {tooth.status !== 'healthy' ? `⚠ ${STATUS_LABELS[tooth.status]}` : '✓ Estado general: Sano'}
                  </p>
                </div>

                {/* Surfaces detail */}
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-2">Superficies:</p>
                  <div className="space-y-1.5">
                    {([
                      ['top', 'Oclusal / Incisal'],
                      ['right', 'Distal'],
                      ['bottom', 'Cervical / Gingival'],
                      ['left', 'Mesial'],
                      ['center', 'Centro / Palatina'],
                    ] as const).map(([s, label]) => (
                      <div key={s} className="flex items-center justify-between text-sm p-2 rounded-lg hover:bg-slate-50 transition-colors">
                        <span className="text-slate-500 text-xs">{label}</span>
                        <span className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full border border-slate-200"
                            style={{ backgroundColor: STATUS_COLORS[tooth.surfaces[s]] === '#FFFFFF' ? '#e2e8f0' : STATUS_COLORS[tooth.surfaces[s]] }} />
                          <span className={`text-xs font-semibold ${tooth.surfaces[s] !== 'healthy' ? '' : 'text-slate-400'}`}
                            style={{ color: tooth.surfaces[s] !== 'healthy' ? STATUS_COLORS[tooth.surfaces[s]] : undefined }}>
                            {STATUS_LABELS[tooth.surfaces[s]]}
                          </span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Notas clínicas:</p>
                  <textarea
                    value={toothNotes}
                    onChange={e => setToothNotes(e.target.value)}
                    onBlur={() => selectedTooth && saveNotes(selectedTooth, toothNotes)}
                    placeholder="Agregar notas sobre este diente..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none h-20"
                  />
                </div>

                <button
                  onClick={() => resetTooth(tooth.number)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" /> Resetear Diente
                </button>
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="w-20 h-20 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-slate-100">
                  <span className="text-4xl">🦷</span>
                </div>
                <p className="text-slate-500 text-sm font-medium">Seleccione un diente</p>
                <p className="text-slate-400 text-xs mt-1">Haga clic en cualquier diente del diagrama para ver sus detalles y marcar condiciones</p>
              </div>
            )}
          </div>

          {/* Tooth History */}
          {tooth && tooth.history.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="w-full flex items-center justify-between"
              >
                <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                  <History className="w-4 h-4 text-violet-500" /> Historial del Diente #{tooth.number}
                </h4>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
              </button>
              {showHistory && (
                <div className="mt-3 space-y-2">
                  {tooth.history.map((h, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 text-xs">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: STATUS_COLORS[h.condition] === '#FFFFFF' ? '#94a3b8' : STATUS_COLORS[h.condition] }} />
                      <span className="text-slate-400 font-mono">{h.date}</span>
                      <span className="font-medium" style={{ color: STATUS_COLORS[h.condition] === '#FFFFFF' ? '#64748b' : STATUS_COLORS[h.condition] }}>
                        {STATUS_LABELS[h.condition]}
                      </span>
                      {h.surface && <span className="text-slate-400">({h.surface})</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-2xl border border-sky-200 p-5">
            <h4 className="text-sm font-semibold text-sky-800 mb-3">📊 Resumen del Odontograma</h4>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-slate-800">32</p>
                <p className="text-[10px] text-slate-500">Total dientes</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-emerald-600">
                  {32 - Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy')).length}
                </p>
                <p className="text-[10px] text-slate-500">Sanos</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-red-500">
                  {Object.values(teeth).filter(t => t.status !== 'healthy' || Object.values(t.surfaces).some(s => s !== 'healthy')).length}
                </p>
                <p className="text-[10px] text-slate-500">Con condición</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-slate-500">
                  {Object.values(teeth).filter(t => t.status === 'extraction').length}
                </p>
                <p className="text-[10px] text-slate-500">Extraídos</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ====================================================================
   REALISTIC TOOTH COMPONENT - SVG rendering with realistic shapes
   ==================================================================== */

function RealisticTooth({ tooth, isSelected, onClick, onSurfaceClick, isUpper, archPosition, totalInArch }: {
  tooth: ToothData;
  isSelected: boolean;
  onClick: () => void;
  onSurfaceClick: (surface: keyof ToothData['surfaces']) => void;
  isUpper: boolean;
  archPosition: number;
  totalInArch: number;
}) {
  const toothType = getToothType(tooth.number);
  const isExtracted = tooth.status === 'extraction';
  const isCrown = tooth.status === 'crown';
  const isImplant = tooth.status === 'implant';
  const hasCondition = tooth.status !== 'healthy' || Object.values(tooth.surfaces).some(s => s !== 'healthy');

  // Calculate slight rotation for arch effect
  const centerIdx = (totalInArch - 1) / 2;
  const offset = archPosition - centerIdx;
  const rotation = offset * 1.5;

  // Tooth dimensions based on type
  const dimensions = {
    molar: { w: 36, h: 48, crownH: 28 },
    premolar: { w: 30, h: 46, crownH: 26 },
    canine: { w: 26, h: 50, crownH: 28 },
    lateral: { w: 24, h: 44, crownH: 24 },
    central: { w: 26, h: 46, crownH: 26 },
  }[toothType];

  const getSurfaceColor = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#FAFAF9' : STATUS_COLORS[status];
  };

  return (
    <div
      className={`flex flex-col items-center cursor-pointer transition-all duration-200 group ${
        isSelected ? 'scale-110 z-20' : 'hover:scale-105 z-10'
      }`}
      style={{ transform: `rotate(${rotation}deg) ${isSelected ? 'scale(1.1)' : ''}` }}
      onClick={onClick}
    >
      {/* Tooth number (top for upper) */}
      {isUpper && (
        <span className={`text-[9px] font-bold mb-0.5 transition-colors ${
          isSelected ? 'text-sky-600' : hasCondition ? 'text-amber-600' : 'text-white/80'
        }`}>
          {tooth.number}
        </span>
      )}

      {/* Tooth SVG */}
      <div className={`relative ${isSelected ? 'filter drop-shadow-lg' : 'filter drop-shadow-sm group-hover:drop-shadow-md'}`}>
        <svg
          width={dimensions.w}
          height={dimensions.h}
          viewBox={`0 0 ${dimensions.w} ${dimensions.h}`}
          className="transition-all"
        >
          {isExtracted ? (
            // Extracted tooth - ghost outline with X
            <g opacity="0.4">
              {renderToothShape(toothType, dimensions, isUpper, '#e2e8f0', '#cbd5e1')}
              <line
                x1="4" y1={isUpper ? 4 : 4}
                x2={dimensions.w - 4} y2={dimensions.h - 4}
                stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round"
              />
              <line
                x1={dimensions.w - 4} y1={isUpper ? 4 : 4}
                x2="4" y2={dimensions.h - 4}
                stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round"
              />
            </g>
          ) : isCrown ? (
            // Crown - golden tooth
            <g>
              {renderToothShape(toothType, dimensions, isUpper, '#FCD34D', '#F59E0B')}
              <text
                x={dimensions.w / 2}
                y={isUpper ? dimensions.crownH / 2 + 2 : dimensions.h - dimensions.crownH / 2 + 2}
                textAnchor="middle" dominantBaseline="middle"
                fill="#92400E" fontSize="10" fontWeight="bold"
              >♛</text>
            </g>
          ) : isImplant ? (
            // Implant - metallic
            <g>
              {renderImplantShape(dimensions, isUpper)}
            </g>
          ) : (
            // Normal tooth with surface colors
            <g>
              {renderInteractiveToothShape(toothType, dimensions, isUpper, getSurfaceColor, onSurfaceClick)}
            </g>
          )}

          {/* Selection ring */}
          {isSelected && (
            <rect
              x="1" y="1"
              width={dimensions.w - 2} height={dimensions.h - 2}
              fill="none" stroke="#0ea5e9" strokeWidth="2" rx="6"
              strokeDasharray="4,2"
              className="animate-pulse"
            />
          )}
        </svg>

        {/* Condition indicator dot */}
        {hasCondition && !isExtracted && (
          <div
            className="absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-white shadow-sm z-10"
            style={{
              backgroundColor: tooth.status !== 'healthy'
                ? STATUS_COLORS[tooth.status]
                : STATUS_COLORS[Object.values(tooth.surfaces).find(s => s !== 'healthy') || 'healthy']
            }}
          />
        )}
      </div>

      {/* Tooth number (bottom for lower) */}
      {!isUpper && (
        <span className={`text-[9px] font-bold mt-0.5 transition-colors ${
          isSelected ? 'text-sky-600' : hasCondition ? 'text-amber-600' : 'text-white/80'
        }`}>
          {tooth.number}
        </span>
      )}
    </div>
  );
}

/* ====================================================================
   SVG TOOTH SHAPE RENDERERS
   ==================================================================== */

function renderToothShape(
  type: string,
  dim: { w: number; h: number; crownH: number },
  isUpper: boolean,
  fill: string,
  stroke: string
): React.JSX.Element {
  const { w, h, crownH } = dim;
  const rootH = h - crownH;

  if (isUpper) {
    // Upper teeth: crown on top, root pointing down
    return (
      <g>
        {/* Root(s) */}
        {type === 'molar' ? (
          // Multi-root molar
          <g>
            <path d={`M${w * 0.2},${crownH} C${w * 0.2},${crownH + rootH * 0.3} ${w * 0.1},${h - 4} ${w * 0.15},${h - 2}`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <path d={`M${w * 0.5},${crownH} C${w * 0.5},${crownH + rootH * 0.4} ${w * 0.5},${h - 4} ${w * 0.5},${h}`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <path d={`M${w * 0.8},${crownH} C${w * 0.8},${crownH + rootH * 0.3} ${w * 0.9},${h - 4} ${w * 0.85},${h - 2}`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <rect x={w * 0.15} y={crownH - 2} width={w * 0.7} height={rootH * 0.3} fill={fill} stroke="none" />
          </g>
        ) : type === 'premolar' ? (
          <g>
            <path d={`M${w * 0.3},${crownH} L${w * 0.35},${h - 2} Q${w * 0.5},${h + 1} ${w * 0.65},${h - 2} L${w * 0.7},${crownH}`}
              fill={fill} stroke={stroke} strokeWidth="1" />
          </g>
        ) : (
          // Single root
          <path d={`M${w * 0.3},${crownH} Q${w * 0.3},${h - 2} ${w * 0.5},${h} Q${w * 0.7},${h - 2} ${w * 0.7},${crownH}`}
            fill={fill} stroke={stroke} strokeWidth="1" />
        )}
        {/* Crown */}
        <rect x="3" y="3" width={w - 6} height={crownH - 3} rx="5" ry="5"
          fill={fill} stroke={stroke} strokeWidth="1.5" />
        {/* Enamel shine */}
        <rect x="5" y="5" width={w - 10} height={4} rx="2"
          fill="white" opacity="0.4" />
      </g>
    );
  } else {
    // Lower teeth: root on top, crown on bottom
    return (
      <g>
        {/* Root(s) */}
        {type === 'molar' ? (
          <g>
            <path d={`M${w * 0.2},${rootH} C${w * 0.2},${rootH * 0.7} ${w * 0.1},4 ${w * 0.15},2`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <path d={`M${w * 0.5},${rootH} C${w * 0.5},${rootH * 0.6} ${w * 0.5},4 ${w * 0.5},0`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <path d={`M${w * 0.8},${rootH} C${w * 0.8},${rootH * 0.7} ${w * 0.9},4 ${w * 0.85},2`}
              fill={fill} stroke={stroke} strokeWidth="1" />
            <rect x={w * 0.15} y={rootH - 2} width={w * 0.7} height={rootH * 0.3} fill={fill} stroke="none" />
          </g>
        ) : type === 'premolar' ? (
          <g>
            <path d={`M${w * 0.3},${rootH} L${w * 0.35},2 Q${w * 0.5},-1 ${w * 0.65},2 L${w * 0.7},${rootH}`}
              fill={fill} stroke={stroke} strokeWidth="1" />
          </g>
        ) : (
          <path d={`M${w * 0.3},${rootH} Q${w * 0.3},2 ${w * 0.5},0 Q${w * 0.7},2 ${w * 0.7},${rootH}`}
            fill={fill} stroke={stroke} strokeWidth="1" />
        )}
        {/* Crown */}
        <rect x="3" y={rootH} width={w - 6} height={crownH - 3} rx="5" ry="5"
          fill={fill} stroke={stroke} strokeWidth="1.5" />
        {/* Enamel shine */}
        <rect x="5" y={rootH + 2} width={w - 10} height={4} rx="2"
          fill="white" opacity="0.4" />
      </g>
    );
  }
}

function renderImplantShape(dim: { w: number; h: number; crownH: number }, isUpper: boolean): React.JSX.Element {
  const { w, h, crownH } = dim;
  const rootH = h - crownH;

  if (isUpper) {
    return (
      <g>
        {/* Implant screw */}
        <path d={`M${w * 0.4},${crownH} L${w * 0.45},${h - 2} L${w * 0.55},${h - 2} L${w * 0.6},${crownH}`}
          fill="#94a3b8" stroke="#64748b" strokeWidth="1" />
        {/* Thread lines */}
        {Array.from({ length: 4 }).map((_, i) => (
          <line key={i}
            x1={w * 0.35} y1={crownH + (rootH * (i + 1)) / 5}
            x2={w * 0.65} y2={crownH + (rootH * (i + 1)) / 5}
            stroke="#64748b" strokeWidth="0.5"
          />
        ))}
        {/* Crown */}
        <rect x="3" y="3" width={w - 6} height={crownH - 3} rx="5" ry="5"
          fill="#d1fae5" stroke="#10B981" strokeWidth="1.5" />
        <text x={w / 2} y={crownH / 2 + 2} textAnchor="middle" dominantBaseline="middle"
          fill="#059669" fontSize="9" fontWeight="bold">I</text>
      </g>
    );
  } else {
    return (
      <g>
        {/* Implant screw */}
        <path d={`M${w * 0.4},${rootH} L${w * 0.45},2 L${w * 0.55},2 L${w * 0.6},${rootH}`}
          fill="#94a3b8" stroke="#64748b" strokeWidth="1" />
        {Array.from({ length: 4 }).map((_, i) => (
          <line key={i}
            x1={w * 0.35} y1={rootH - (rootH * (i + 1)) / 5}
            x2={w * 0.65} y2={rootH - (rootH * (i + 1)) / 5}
            stroke="#64748b" strokeWidth="0.5"
          />
        ))}
        {/* Crown */}
        <rect x="3" y={rootH} width={w - 6} height={crownH - 3} rx="5" ry="5"
          fill="#d1fae5" stroke="#10B981" strokeWidth="1.5" />
        <text x={w / 2} y={rootH + crownH / 2} textAnchor="middle" dominantBaseline="middle"
          fill="#059669" fontSize="9" fontWeight="bold">I</text>
      </g>
    );
  }
}

function renderInteractiveToothShape(
  type: string,
  dim: { w: number; h: number; crownH: number },
  isUpper: boolean,
  getColor: (surface: keyof ToothData['surfaces']) => string,
  _onSurfaceClick: (surface: keyof ToothData['surfaces']) => void
): React.JSX.Element {
  const { w, h, crownH } = dim;
  const rootH = h - crownH;

  // Crown area positions
  const crownY = isUpper ? 3 : rootH;
  const cw = w - 6; // crown width
  const ch = crownH - 3; // crown height
  const cx = 3; // crown x

  const centerColor = getColor('center');
  const topColor = getColor('top');
  const bottomColor = getColor('bottom');
  const leftColor = getColor('left');
  const rightColor = getColor('right');

  return (
    <g>
      {/* Root(s) - always natural color */}
      {isUpper ? (
        type === 'molar' ? (
          <g>
            <path d={`M${w * 0.2},${crownH} C${w * 0.2},${crownH + rootH * 0.3} ${w * 0.1},${h - 4} ${w * 0.15},${h - 2}`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <path d={`M${w * 0.5},${crownH} C${w * 0.5},${crownH + rootH * 0.4} ${w * 0.5},${h - 4} ${w * 0.5},${h}`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <path d={`M${w * 0.8},${crownH} C${w * 0.8},${crownH + rootH * 0.3} ${w * 0.9},${h - 4} ${w * 0.85},${h - 2}`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <rect x={w * 0.15} y={crownH - 3} width={w * 0.7} height={rootH * 0.3 + 3} fill="#FFF5E6" stroke="none" />
          </g>
        ) : type === 'premolar' ? (
          <path d={`M${w * 0.3},${crownH} L${w * 0.35},${h - 2} Q${w * 0.5},${h + 1} ${w * 0.65},${h - 2} L${w * 0.7},${crownH}`}
            fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
        ) : (
          <path d={`M${w * 0.3},${crownH} Q${w * 0.3},${h - 2} ${w * 0.5},${h} Q${w * 0.7},${h - 2} ${w * 0.7},${crownH}`}
            fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
        )
      ) : (
        type === 'molar' ? (
          <g>
            <path d={`M${w * 0.2},${rootH} C${w * 0.2},${rootH * 0.7} ${w * 0.1},4 ${w * 0.15},2`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <path d={`M${w * 0.5},${rootH} C${w * 0.5},${rootH * 0.6} ${w * 0.5},4 ${w * 0.5},0`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <path d={`M${w * 0.8},${rootH} C${w * 0.8},${rootH * 0.7} ${w * 0.9},4 ${w * 0.85},2`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
            <rect x={w * 0.15} y={rootH - rootH * 0.3} width={w * 0.7} height={rootH * 0.3 + 3} fill="#FFF5E6" stroke="none" />
          </g>
        ) : type === 'premolar' ? (
          <path d={`M${w * 0.3},${rootH} L${w * 0.35},2 Q${w * 0.5},-1 ${w * 0.65},2 L${w * 0.7},${rootH}`}
            fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
        ) : (
          <path d={`M${w * 0.3},${rootH} Q${w * 0.3},2 ${w * 0.5},0 Q${w * 0.7},2 ${w * 0.7},${rootH}`}
            fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
        )
      )}

      {/* Crown - Interactive surfaces */}
      {/* Base crown shape */}
      <rect x={cx} y={crownY} width={cw} height={ch} rx="5" ry="5"
        fill="#FAFAF9" stroke="#D4C5A9" strokeWidth="1.2" />

      {/* Top surface (oclusal) */}
      <path
        d={`M${cx + 2},${crownY + 1} L${cx + cw - 2},${crownY + 1} L${cx + cw - 4},${crownY + ch * 0.25} L${cx + 4},${crownY + ch * 0.25} Z`}
        fill={topColor}
        stroke="#D4C5A9" strokeWidth="0.5"
        className="cursor-pointer hover:brightness-90 transition-all"
        onClick={e => { e.stopPropagation(); _onSurfaceClick('top'); }}
      />

      {/* Bottom surface (cervical) */}
      <path
        d={`M${cx + 4},${crownY + ch * 0.75} L${cx + cw - 4},${crownY + ch * 0.75} L${cx + cw - 2},${crownY + ch - 1} L${cx + 2},${crownY + ch - 1} Z`}
        fill={bottomColor}
        stroke="#D4C5A9" strokeWidth="0.5"
        className="cursor-pointer hover:brightness-90 transition-all"
        onClick={e => { e.stopPropagation(); _onSurfaceClick('bottom'); }}
      />

      {/* Left surface (mesial) */}
      <path
        d={`M${cx + 2},${crownY + 1} L${cx + 4},${crownY + ch * 0.25} L${cx + 4},${crownY + ch * 0.75} L${cx + 2},${crownY + ch - 1} Z`}
        fill={leftColor}
        stroke="#D4C5A9" strokeWidth="0.5"
        className="cursor-pointer hover:brightness-90 transition-all"
        onClick={e => { e.stopPropagation(); _onSurfaceClick('left'); }}
      />

      {/* Right surface (distal) */}
      <path
        d={`M${cx + cw - 2},${crownY + 1} L${cx + cw - 4},${crownY + ch * 0.25} L${cx + cw - 4},${crownY + ch * 0.75} L${cx + cw - 2},${crownY + ch - 1} Z`}
        fill={rightColor}
        stroke="#D4C5A9" strokeWidth="0.5"
        className="cursor-pointer hover:brightness-90 transition-all"
        onClick={e => { e.stopPropagation(); _onSurfaceClick('right'); }}
      />

      {/* Center surface */}
      <rect
        x={cx + 4} y={crownY + ch * 0.25}
        width={cw - 8} height={ch * 0.5}
        fill={centerColor}
        stroke="#D4C5A9" strokeWidth="0.5"
        rx="2"
        className="cursor-pointer hover:brightness-90 transition-all"
        onClick={e => { e.stopPropagation(); _onSurfaceClick('center'); }}
      />

      {/* Enamel shine highlight */}
      <rect x={cx + 3} y={crownY + 2} width={cw - 6} height={3} rx="1.5"
        fill="white" opacity="0.5" />
    </g>
  );
}

/* ====================================================================
   BIG TOOTH PREVIEW for detail panel
   ==================================================================== */

function BigToothPreview({ tooth }: { tooth: ToothData }) {
  const type = getToothType(tooth.number);
  const isExtracted = tooth.status === 'extraction';
  const isCrown = tooth.status === 'crown';
  const isImplant = tooth.status === 'implant';

  const w = 60;
  const h = 80;

  const getSurfaceColor = (surface: keyof ToothData['surfaces']): string => {
    const status = tooth.surfaces[surface];
    return status === 'healthy' ? '#FAFAF9' : STATUS_COLORS[status];
  };

  return (
    <svg width="100%" height="100%" viewBox={`0 0 ${w} ${h}`}>
      {isExtracted ? (
        <g opacity="0.4">
          <rect x="8" y="5" width={w - 16} height={40} rx="8" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1.5" />
          <path d={`M${w * 0.35},45 Q${w * 0.35},${h - 5} ${w * 0.5},${h} Q${w * 0.65},${h - 5} ${w * 0.65},45`}
            fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1" />
          <line x1="10" y1="10" x2={w - 10} y2={h - 10} stroke="#EF4444" strokeWidth="3" strokeLinecap="round" />
          <line x1={w - 10} y1="10" x2="10" y2={h - 10} stroke="#EF4444" strokeWidth="3" strokeLinecap="round" />
        </g>
      ) : isCrown ? (
        <g>
          <rect x="8" y="5" width={w - 16} height={40} rx="8" fill="#FCD34D" stroke="#F59E0B" strokeWidth="2" />
          <path d={`M${w * 0.35},45 Q${w * 0.35},${h - 5} ${w * 0.5},${h} Q${w * 0.65},${h - 5} ${w * 0.65},45`}
            fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
          <text x={w / 2} y="30" textAnchor="middle" dominantBaseline="middle" fill="#92400E" fontSize="16" fontWeight="bold">♛</text>
        </g>
      ) : isImplant ? (
        <g>
          <rect x="8" y="5" width={w - 16} height={38} rx="8" fill="#d1fae5" stroke="#10B981" strokeWidth="2" />
          <path d={`M${w * 0.4},43 L${w * 0.42},${h - 4} L${w * 0.58},${h - 4} L${w * 0.6},43`}
            fill="#94a3b8" stroke="#64748b" strokeWidth="1.5" />
          {Array.from({ length: 5 }).map((_, i) => (
            <line key={i} x1={w * 0.35} y1={43 + (i + 1) * 5} x2={w * 0.65} y2={43 + (i + 1) * 5}
              stroke="#64748b" strokeWidth="0.7" />
          ))}
          <text x={w / 2} y="28" textAnchor="middle" dominantBaseline="middle" fill="#059669" fontSize="14" fontWeight="bold">I</text>
        </g>
      ) : (
        <g>
          {/* Root */}
          {type === 'molar' ? (
            <g>
              <path d={`M${w * 0.25},45 C${w * 0.25},55 ${w * 0.15},${h - 5} ${w * 0.2},${h - 2}`} fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
              <path d={`M${w * 0.5},45 C${w * 0.5},60 ${w * 0.5},${h - 3} ${w * 0.5},${h}`} fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
              <path d={`M${w * 0.75},45 C${w * 0.75},55 ${w * 0.85},${h - 5} ${w * 0.8},${h - 2}`} fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
              <rect x={w * 0.2} y={42} width={w * 0.6} height={8} fill="#FFF5E6" stroke="none" />
            </g>
          ) : (
            <path d={`M${w * 0.35},45 Q${w * 0.35},${h - 5} ${w * 0.5},${h} Q${w * 0.65},${h - 5} ${w * 0.65},45`}
              fill="#FFF5E6" stroke="#E8D5B7" strokeWidth="1" />
          )}

          {/* Crown with surfaces */}
          <rect x="8" y="5" width={w - 16} height={40} rx="8" fill="#FAFAF9" stroke="#D4C5A9" strokeWidth="1.5" />

          {/* Top */}
          <path d={`M10,7 L${w - 10},7 L${w - 14},15 L14,15 Z`} fill={getSurfaceColor('top')} stroke="#D4C5A9" strokeWidth="0.5" />
          {/* Bottom */}
          <path d={`M14,35 L${w - 14},35 L${w - 10},43 L10,43 Z`} fill={getSurfaceColor('bottom')} stroke="#D4C5A9" strokeWidth="0.5" />
          {/* Left */}
          <path d={`M10,7 L14,15 L14,35 L10,43 Z`} fill={getSurfaceColor('left')} stroke="#D4C5A9" strokeWidth="0.5" />
          {/* Right */}
          <path d={`M${w - 10},7 L${w - 14},15 L${w - 14},35 L${w - 10},43 Z`} fill={getSurfaceColor('right')} stroke="#D4C5A9" strokeWidth="0.5" />
          {/* Center */}
          <rect x="14" y="15" width={w - 28} height="20" fill={getSurfaceColor('center')} stroke="#D4C5A9" strokeWidth="0.5" rx="3" />

          {/* Enamel shine */}
          <rect x="12" y="8" width={w - 24} height="4" rx="2" fill="white" opacity="0.5" />
        </g>
      )}
    </svg>
  );
}
