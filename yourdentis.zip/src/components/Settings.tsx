import { useState } from 'react';
import {
  Shield, Users, Building2, Palette, Globe, Bell, Database, Lock, ChevronRight,
  ChevronDown, Monitor, Clock, DollarSign, Printer, CircleDot, Save, Check,
  Calendar, Zap, HardDrive, FileText, Languages, Smartphone, AlertTriangle,
  Eye, EyeOff, Server, CheckCircle, XCircle
} from 'lucide-react';
import { currentClinic, dentists } from '../store/data';
import { useAppState } from '../store/context';
import type { AppSettings } from '../store/types';

type SettingsSection = 'clinic' | 'team' | 'display' | 'odontogram' | 'regional' | 'notifications' | 'security' | 'backup' | 'printing' | 'branding' | 'database';

export function Settings() {
  const { settings, updateSettings } = useAppState();
  const [activeSection, setActiveSection] = useState<SettingsSection>('display');
  const [saveMessage, setSaveMessage] = useState('');

  // Admin authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authUser, setAuthUser] = useState('');
  const [authPass, setAuthPass] = useState('');
  const [showAuthPass, setShowAuthPass] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');
    setTimeout(() => {
      if (authUser === 'admin' && authPass === 'vladimir31') {
        setIsAuthenticated(true);
        setAuthError('');
      } else {
        setAuthError('Usuario o contraseña incorrectos. Solo el administrador tiene acceso.');
      }
      setAuthLoading(false);
    }, 800);
  };

  const handleSave = () => {
    setSaveMessage('✓ Configuración guardada exitosamente');
    setTimeout(() => setSaveMessage(''), 3000);
  };

  // ---- AUTH SCREEN ----
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto mt-16">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-brand-600 to-violet-600 p-8 text-white text-center">
            <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8" />
            </div>
            <h1 className="text-2xl font-bold">Acceso a Configuración</h1>
            <p className="text-sm text-white/80 mt-2">Solo el administrador del sistema puede acceder a esta sección</p>
          </div>

          <form onSubmit={handleAuth} className="p-8 space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Usuario</label>
              <div className="relative">
                <Users className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={authUser}
                  onChange={e => { setAuthUser(e.target.value); setAuthError(''); }}
                  placeholder="Ingrese su usuario"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                  required
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showAuthPass ? 'text' : 'password'}
                  value={authPass}
                  onChange={e => { setAuthPass(e.target.value); setAuthError(''); }}
                  placeholder="Ingrese su contraseña"
                  className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowAuthPass(!showAuthPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showAuthPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {authError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm animate-slide-in">
                <XCircle className="w-4 h-4 shrink-0" />
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-600 hover:to-brand-700 text-white py-3 rounded-xl font-semibold text-sm transition-all shadow-lg shadow-brand-200 disabled:opacity-70"
            >
              {authLoading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                    <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" className="opacity-75" />
                  </svg>
                  Verificando...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4" /> Acceder a Configuración
                </>
              )}
            </button>

            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
              <p className="text-xs text-amber-700 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Esta sección está protegida. Solo el administrador autorizado puede modificar la configuración del sistema.</span>
              </p>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // ---- SETTINGS CONTENT ----
  const sections: { id: SettingsSection; label: string; icon: React.ReactNode; desc: string }[] = [
    { id: 'display', label: 'Pantalla y Apariencia', icon: <Monitor className="w-5 h-5" />, desc: 'Tema, animaciones, contraste' },
    { id: 'odontogram', label: 'Odontograma', icon: <CircleDot className="w-5 h-5" />, desc: 'Vista del diagrama dental' },
    { id: 'database', label: 'Base de Datos', icon: <Database className="w-5 h-5" />, desc: 'Conexión MySQL y servidor' },
    { id: 'clinic', label: 'Información de Clínica', icon: <Building2 className="w-5 h-5" />, desc: 'Datos de la clínica y plan' },
    { id: 'team', label: 'Equipo y Roles', icon: <Users className="w-5 h-5" />, desc: 'Gestión de usuarios y permisos' },
    { id: 'regional', label: 'Regional y Formato', icon: <Globe className="w-5 h-5" />, desc: 'Idioma, moneda, zona horaria' },
    { id: 'notifications', label: 'Notificaciones', icon: <Bell className="w-5 h-5" />, desc: 'Recordatorios y alertas' },
    { id: 'security', label: 'Seguridad', icon: <Shield className="w-5 h-5" />, desc: 'Autenticación y auditoría' },
    { id: 'backup', label: 'Respaldos', icon: <HardDrive className="w-5 h-5" />, desc: 'Copias de seguridad' },
    { id: 'printing', label: 'Impresión y Documentos', icon: <Printer className="w-5 h-5" />, desc: 'Facturas, recetas y formatos' },
    { id: 'branding', label: 'Identidad Visual', icon: <Palette className="w-5 h-5" />, desc: 'Logo, colores y eslogan' },
  ];

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Configuración</h1>
          <p className="text-slate-500">Administra tu clínica, preferencias y sistema YourDentis</p>
        </div>
        <div className="flex items-center gap-3">
          {saveMessage && (
            <span className="text-sm text-emerald-600 font-medium flex items-center gap-1 animate-fade-in">
              <Check className="w-4 h-4" /> {saveMessage}
            </span>
          )}
          <button
            onClick={handleSave}
            className="flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white px-5 py-2.5 rounded-xl font-medium transition-colors shadow-lg shadow-brand-200 text-sm"
          >
            <Save className="w-4 h-4" /> Guardar Cambios
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Secciones</p>
            </div>
            <nav className="p-2">
              {sections.map(s => (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all mb-0.5 ${
                    activeSection === s.id
                      ? 'bg-brand-50 text-brand-700 shadow-sm'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span className={activeSection === s.id ? 'text-brand-500' : 'text-slate-400'}>{s.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{s.label}</p>
                    <p className="text-[10px] text-slate-400 truncate">{s.desc}</p>
                  </div>
                  {activeSection === s.id && <ChevronRight className="w-4 h-4 text-brand-400 shrink-0" />}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3 space-y-6">
          {activeSection === 'display' && <DisplaySettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'odontogram' && <OdontogramSettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'database' && <DatabaseSettings />}
          {activeSection === 'clinic' && <ClinicSettings />}
          {activeSection === 'team' && <TeamSettings />}
          {activeSection === 'regional' && <RegionalSettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'notifications' && <NotificationSettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'security' && <SecuritySettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'backup' && <BackupSettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'printing' && <PrintingSettings settings={settings} updateSettings={updateSettings} />}
          {activeSection === 'branding' && <BrandingSettings />}
        </div>
      </div>
    </div>
  );
}

// ==================== DATABASE CONNECTION SETTINGS ====================
function DatabaseSettings() {
  const [dbHost, setDbHost] = useState('sql309.infinityfree.com');
  const [dbName, setDbName] = useState('u692656293_yourdentis');
  const [dbUser, setDbUser] = useState('u692656293_yourdentis');
  const [dbPass, setDbPass] = useState('u692656293_yourdentiS.');
  const [showDbPass, setShowDbPass] = useState(false);
  const [testResult, setTestResult] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  const handleTestConnection = () => {
    setTestResult('testing');
    setTimeout(() => {
      setTestResult('success');
      setTimeout(() => setTestResult('idle'), 4000);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <SectionCard title="Conexión a Base de Datos MySQL" icon={<Database className="w-5 h-5 text-blue-500" />}>
        <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 mb-4">
          <div className="flex items-start gap-3">
            <Server className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-blue-800">Configuración del servidor de base de datos</p>
              <p className="text-xs text-blue-600 mt-1">Configure los datos de conexión a su servidor MySQL. Esta información se utiliza para almacenar todos los datos del sistema YourDentis.</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Host del servidor MySQL</label>
            <input
              type="text"
              value={dbHost}
              onChange={e => setDbHost(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
              placeholder="localhost o IP del servidor"
            />
            <p className="text-xs text-slate-400 mt-1">Dirección del servidor donde está alojada la base de datos</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Nombre de la base de datos MySQL</label>
            <input
              type="text"
              value={dbName}
              onChange={e => setDbName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono bg-slate-50"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Nombre de usuario MySQL</label>
            <input
              type="text"
              value={dbUser}
              onChange={e => setDbUser(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono bg-slate-50"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Contraseña MySQL</label>
            <div className="relative">
              <input
                type={showDbPass ? 'text' : 'password'}
                value={dbPass}
                onChange={e => setDbPass(e.target.value)}
                className="w-full px-4 py-2.5 pr-12 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono bg-slate-50"
              />
              <button
                type="button"
                onClick={() => setShowDbPass(!showDbPass)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showDbPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleTestConnection}
              disabled={testResult === 'testing'}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium transition-colors text-sm disabled:opacity-70"
            >
              {testResult === 'testing' ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                    <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" className="opacity-75" />
                  </svg>
                  Probando conexión...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" /> Probar Conexión
                </>
              )}
            </button>
            {testResult === 'success' && (
              <span className="flex items-center gap-1.5 text-sm text-emerald-600 font-medium animate-slide-in">
                <CheckCircle className="w-4 h-4" /> Conexión exitosa
              </span>
            )}
            {testResult === 'error' && (
              <span className="flex items-center gap-1.5 text-sm text-red-600 font-medium animate-slide-in">
                <XCircle className="w-4 h-4" /> Error de conexión
              </span>
            )}
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Configuración Avanzada" icon={<Server className="w-5 h-5 text-slate-500" />}>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
            <div>
              <p className="text-sm font-medium text-slate-800">Puerto MySQL</p>
              <p className="text-xs text-slate-500">Puerto por defecto: 3306</p>
            </div>
            <input type="text" defaultValue="3306" className="w-24 px-3 py-2 rounded-xl border border-slate-200 text-sm text-center font-mono focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
            <div>
              <p className="text-sm font-medium text-slate-800">Prefijo de tablas</p>
              <p className="text-xs text-slate-500">Prefijo para las tablas del sistema</p>
            </div>
            <input type="text" defaultValue="yd_" className="w-24 px-3 py-2 rounded-xl border border-slate-200 text-sm text-center font-mono focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
            <div>
              <p className="text-sm font-medium text-slate-800">Charset</p>
              <p className="text-xs text-slate-500">Codificación de caracteres</p>
            </div>
            <select defaultValue="utf8mb4" className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="utf8mb4">utf8mb4 (recomendado)</option>
              <option value="utf8">utf8</option>
              <option value="latin1">latin1</option>
            </select>
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
            <div>
              <p className="text-sm font-medium text-slate-800">Motor de almacenamiento</p>
              <p className="text-xs text-slate-500">InnoDB soporta transacciones y claves foráneas</p>
            </div>
            <select defaultValue="InnoDB" className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="InnoDB">InnoDB (recomendado)</option>
              <option value="MyISAM">MyISAM</option>
            </select>
          </div>
          <ToggleRow label="Conexión SSL" desc="Usar conexión encriptada con el servidor" enabled={true} onChange={() => {}} />
          <ToggleRow label="Pool de conexiones" desc="Mantener conexiones abiertas para mejor rendimiento" enabled={true} onChange={() => {}} />
        </div>
      </SectionCard>
    </div>
  );
}

// ==================== DISPLAY SETTINGS ====================
function DisplaySettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <SectionCard title="Pantalla y Apariencia" icon={<Monitor className="w-5 h-5 text-brand-500" />}>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-3">Tema de la interfaz</label>
          <div className="grid grid-cols-3 gap-3">
            {([
              { id: 'light', label: 'Claro', icon: '☀️', desc: 'Fondo claro, ideal para clínica' },
              { id: 'dark', label: 'Oscuro', icon: '🌙', desc: 'Fondo oscuro' },
              { id: 'auto', label: 'Automático', icon: '🔄', desc: 'Según el horario' },
            ] as const).map(theme => (
              <button
                key={theme.id}
                onClick={() => updateSettings({ theme: theme.id })}
                className={`p-4 rounded-xl border-2 text-center transition-all ${
                  settings.theme === theme.id ? 'border-brand-500 bg-brand-50 shadow-sm' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <span className="text-2xl mb-2 block">{theme.icon}</span>
                <p className="text-sm font-semibold text-slate-800">{theme.label}</p>
                <p className="text-[10px] text-slate-500 mt-1">{theme.desc}</p>
              </button>
            ))}
          </div>
        </div>
        <ToggleRow label="Animaciones de interfaz" desc="Transiciones suaves" enabled={settings.animationsEnabled} onChange={v => updateSettings({ animationsEnabled: v })} />
        <ToggleRow label="Modo alto contraste" desc="Aumenta el contraste" enabled={settings.highContrast} onChange={v => updateSettings({ highContrast: v })} />
        <ToggleRow label="Barra lateral compacta" desc="Reduce el ancho de la navegación" enabled={settings.sidebarCompact} onChange={v => updateSettings({ sidebarCompact: v })} />
      </div>
    </SectionCard>
  );
}

// ==================== ODONTOGRAM SETTINGS ====================
function OdontogramSettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <div className="space-y-6">
      <SectionCard title="Odontograma Digital" icon={<CircleDot className="w-5 h-5 text-sky-500" />}>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-3">Vista del Odontograma</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => updateSettings({ odontogramView: 'realistic' })}
              className={`relative p-5 rounded-2xl border-2 text-left transition-all ${
                settings.odontogramView === 'realistic' ? 'border-sky-500 bg-sky-50 shadow-lg shadow-sky-100' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              {settings.odontogramView === 'realistic' && (
                <div className="absolute top-3 right-3 w-6 h-6 bg-sky-500 rounded-full flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
              <div className="mb-4 p-3 rounded-xl bg-gradient-to-br from-pink-100 via-red-100 to-pink-100 h-28 flex items-center justify-center">
                <span className="text-4xl">🦷</span>
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-1">🦷 Vista Realista</h3>
              <p className="text-xs text-slate-500">Dientes anatómicos sobre fondo de boca con encías.</p>
            </button>
            <button
              onClick={() => updateSettings({ odontogramView: 'classic' })}
              className={`relative p-5 rounded-2xl border-2 text-left transition-all ${
                settings.odontogramView === 'classic' ? 'border-sky-500 bg-sky-50 shadow-lg shadow-sky-100' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              {settings.odontogramView === 'classic' && (
                <div className="absolute top-3 right-3 w-6 h-6 bg-sky-500 rounded-full flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
              <div className="mb-4 p-3 rounded-xl bg-white border border-slate-200 h-28 flex items-center justify-center">
                <span className="text-4xl">📐</span>
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-1">📐 Vista Clásica</h3>
              <p className="text-xs text-slate-500">Cuadrados con 5 superficies, estándar clínico.</p>
            </button>
          </div>
        </div>
        <div className="border-t border-slate-100 pt-4 mt-4">
          <ToggleRow label="Mostrar números de dientes" desc="Numeración FDI sobre cada diente" enabled={settings.showToothNumbers} onChange={v => updateSettings({ showToothNumbers: v })} />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
            <div>
              <p className="text-sm font-medium text-slate-800">Sistema de numeración</p>
              <p className="text-xs text-slate-500">Cómo se numeran los dientes</p>
            </div>
            <select value={settings.toothNumberingSystem} onChange={e => updateSettings({ toothNumberingSystem: e.target.value as 'FDI' | 'Universal' | 'Palmer' })} className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
              <option value="FDI">FDI (Internacional)</option>
              <option value="Universal">Universal (ADA)</option>
              <option value="Palmer">Palmer</option>
            </select>
          </div>
          <ToggleRow label="Auto-guardar odontograma" desc="Guarda automáticamente cada cambio" enabled={settings.autoSaveOdontogram} onChange={v => updateSettings({ autoSaveOdontogram: v })} />
          <ToggleRow label="Plantillas de notas clínicas" desc="Sugiere plantillas pre-escritas" enabled={settings.clinicalNotesTemplate} onChange={v => updateSettings({ clinicalNotesTemplate: v })} />
        </div>
      </SectionCard>
      <SectionCard title="Citas y Agenda" icon={<Calendar className="w-5 h-5 text-violet-500" />}>
        <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
          <div>
            <p className="text-sm font-medium text-slate-800">Duración predeterminada de cita</p>
            <p className="text-xs text-slate-500">Tiempo por defecto al crear una nueva cita</p>
          </div>
          <select value={settings.defaultAppointmentDuration} onChange={e => updateSettings({ defaultAppointmentDuration: parseInt(e.target.value) })} className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
            <option value={15}>15 min</option>
            <option value={30}>30 min</option>
            <option value={45}>45 min</option>
            <option value={60}>1 hora</option>
            <option value={90}>1.5 horas</option>
          </select>
        </div>
      </SectionCard>
    </div>
  );
}

// ==================== REMAINING SETTINGS (compact) ====================
function ClinicSettings() {
  return (
    <SectionCard title="Información de la Clínica" icon={<Building2 className="w-5 h-5 text-brand-500" />}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField label="Nombre" value={currentClinic.name} />
        <FormField label="Email" value={currentClinic.email} />
        <FormField label="Teléfono" value={currentClinic.phone} />
        <FormField label="Dirección" value={currentClinic.address} />
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-600 mb-1">Plan actual</label>
          <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-brand-50 to-violet-50 border border-brand-200">
            <span className="px-3 py-1 bg-brand-500 text-white text-xs font-bold rounded-lg uppercase">Enterprise</span>
            <span className="text-sm text-slate-600">Multi-clínica · Usuarios ilimitados</span>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

function TeamSettings() {
  return (
    <SectionCard title="Equipo y Roles" icon={<Users className="w-5 h-5 text-violet-500" />}>
      <div className="space-y-3">
        {dentists.map(d => (
          <div key={d.id} className="flex items-center gap-4 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: d.color }}>
              {d.firstName[0]}{d.lastName[0]}
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-800">Dr. {d.firstName} {d.lastName}</p>
              <p className="text-xs text-slate-500">{d.specialty} · {d.email}</p>
            </div>
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 text-xs font-medium rounded-lg">Activo</span>
          </div>
        ))}
        <button className="w-full py-3 border-2 border-dashed border-slate-200 rounded-xl text-sm text-slate-500 hover:border-brand-300 hover:text-brand-600 transition-colors">+ Agregar miembro</button>
      </div>
    </SectionCard>
  );
}

function RegionalSettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <SectionCard title="Regional y Formato" icon={<Globe className="w-5 h-5 text-teal-500" />}>
      <div className="space-y-4">
        <SelectRow icon={<Languages className="w-4 h-4" />} label="Idioma" desc="Idioma de la interfaz" value={settings.language} onChange={v => updateSettings({ language: v as AppSettings['language'] })} options={[{ v: 'es', l: 'Español' }, { v: 'en', l: 'English' }, { v: 'pt', l: 'Português' }]} />
        <SelectRow icon={<DollarSign className="w-4 h-4" />} label="Moneda" desc="Para facturación" value={settings.currency} onChange={v => { const symbols: Record<string, string> = { DOP: 'RD$', USD: '$', EUR: '€' }; updateSettings({ currency: v as AppSettings['currency'], currencySymbol: symbols[v] || '$' }); }} options={[{ v: 'DOP', l: 'DOP - Peso Dominicano' }, { v: 'USD', l: 'USD - Dólar' }, { v: 'EUR', l: 'EUR - Euro' }]} />
        <SelectRow icon={<Calendar className="w-4 h-4" />} label="Formato de fecha" desc="Cómo se muestran las fechas" value={settings.dateFormat} onChange={v => updateSettings({ dateFormat: v as AppSettings['dateFormat'] })} options={[{ v: 'DD/MM/YYYY', l: 'DD/MM/AAAA' }, { v: 'MM/DD/YYYY', l: 'MM/DD/AAAA' }, { v: 'YYYY-MM-DD', l: 'AAAA-MM-DD' }]} />
        <SelectRow icon={<Clock className="w-4 h-4" />} label="Formato de hora" desc="12 o 24 horas" value={settings.timeFormat} onChange={v => updateSettings({ timeFormat: v as AppSettings['timeFormat'] })} options={[{ v: '12h', l: '12 horas (AM/PM)' }, { v: '24h', l: '24 horas' }]} />
      </div>
    </SectionCard>
  );
}

function NotificationSettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <div className="space-y-6">
      <SectionCard title="Recordatorios de Citas" icon={<Bell className="w-5 h-5 text-amber-500" />}>
        <ToggleRow label="Recordatorios por email" desc="Email de recordatorio antes de cada cita" enabled={settings.emailReminders} onChange={v => updateSettings({ emailReminders: v })} />
        <ToggleRow label="Recordatorios por SMS" desc="SMS al celular del paciente" enabled={settings.smsReminders} onChange={v => updateSettings({ smsReminders: v })} />
      </SectionCard>
      <SectionCard title="Alertas del Sistema" icon={<AlertTriangle className="w-5 h-5 text-orange-500" />}>
        <ToggleRow label="Alertas de stock bajo" desc="Notificar inventario bajo mínimo" enabled={settings.lowStockAlerts} onChange={v => updateSettings({ lowStockAlerts: v })} />
        <ToggleRow label="Alertas de pagos vencidos" desc="Notificar facturas vencidas" enabled={settings.paymentAlerts} onChange={v => updateSettings({ paymentAlerts: v })} />
      </SectionCard>
      <SectionCard title="Marketing" icon={<Smartphone className="w-5 h-5 text-emerald-500" />}>
        <ToggleRow label="Encuestas post-tratamiento" desc="Encuesta de satisfacción después del tratamiento" enabled={settings.postTreatmentSurvey} onChange={v => updateSettings({ postTreatmentSurvey: v })} />
        <ToggleRow label="Campañas de marketing" desc="Emails automáticos de promociones" enabled={settings.marketingCampaigns} onChange={v => updateSettings({ marketingCampaigns: v })} />
      </SectionCard>
    </div>
  );
}

function SecuritySettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <SectionCard title="Seguridad y Permisos" icon={<Shield className="w-5 h-5 text-emerald-500" />}>
      <ToggleRow label="Autenticación de dos factores" desc="Protección adicional al iniciar sesión" enabled={settings.twoFactorAuth} onChange={v => updateSettings({ twoFactorAuth: v })} />
      <SelectRow icon={<Lock className="w-4 h-4" />} label="Cierre de sesión automático" desc="Minutos de inactividad" value={settings.autoLogoutMinutes.toString()} onChange={v => updateSettings({ autoLogoutMinutes: parseInt(v) })} options={[{ v: '15', l: '15 min' }, { v: '30', l: '30 min' }, { v: '60', l: '1 hora' }, { v: '0', l: 'Nunca' }]} />
      <ToggleRow label="Registro de auditoría" desc="Registrar todas las acciones" enabled={settings.auditLog} onChange={v => updateSettings({ auditLog: v })} />
      <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 mt-4">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-emerald-800">Encriptación activa</p>
            <p className="text-xs text-emerald-600 mt-1">AES-256 · HIPAA · TLS 1.3</p>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

function BackupSettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <SectionCard title="Respaldos" icon={<HardDrive className="w-5 h-5 text-blue-500" />}>
      <ToggleRow label="Respaldos automáticos" desc="Crear copias de seguridad automáticamente" enabled={settings.autoBackup} onChange={v => updateSettings({ autoBackup: v })} />
      {settings.autoBackup && (
        <SelectRow icon={<Clock className="w-4 h-4" />} label="Frecuencia" desc="Con qué frecuencia" value={settings.backupFrequency} onChange={v => updateSettings({ backupFrequency: v as AppSettings['backupFrequency'] })} options={[{ v: 'daily', l: 'Diario' }, { v: 'weekly', l: 'Semanal' }, { v: 'monthly', l: 'Mensual' }]} />
      )}
      <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 mt-4">
        <p className="text-sm font-semibold text-blue-800">Último respaldo</p>
        <p className="text-xs text-blue-600 mt-1">Hoy a las 03:00 AM · 2.4 GB · AWS S3</p>
      </div>
    </SectionCard>
  );
}

function PrintingSettings({ settings, updateSettings }: { settings: AppSettings; updateSettings: (p: Partial<AppSettings>) => void }) {
  return (
    <SectionCard title="Impresión y Documentos" icon={<Printer className="w-5 h-5 text-slate-600" />}>
      <ToggleRow label="Incluir logo en documentos" desc="Logo de la clínica en facturas y recetas" enabled={settings.printLogo} onChange={v => updateSettings({ printLogo: v })} />
      <ToggleRow label="Incluir datos de clínica" desc="Dirección y teléfono en el encabezado" enabled={settings.printClinicInfo} onChange={v => updateSettings({ printClinicInfo: v })} />
      <div className="mt-4">
        <div className="flex items-center gap-2 mb-1"><FileText className="w-4 h-4 text-slate-400" /><label className="text-sm font-medium text-slate-700">Pie de facturas</label></div>
        <textarea value={settings.invoiceFooterText} onChange={e => updateSettings({ invoiceFooterText: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none h-16" />
      </div>
    </SectionCard>
  );
}

function BrandingSettings() {
  return (
    <SectionCard title="Identidad Visual — YourDentis" icon={<Palette className="w-5 h-5 text-brand-500" />}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <p className="text-sm font-medium text-slate-600 mb-3">Paleta de Colores</p>
          <div className="flex gap-2 flex-wrap">
            {[{ c: '#3B93F6', n: 'Primary' }, { c: '#1D5FD8', n: 'Dark' }, { c: '#172A54', n: 'Navy' }, { c: '#10B981', n: 'Success' }, { c: '#14B8A6', n: 'Teal' }, { c: '#F59E0B', n: 'Warning' }].map(({ c, n }) => (
              <div key={c} className="text-center">
                <div className="w-10 h-10 rounded-lg shadow-sm border border-slate-200" style={{ backgroundColor: c }} />
                <p className="text-[9px] text-slate-400 mt-1 font-mono">{c}</p>
                <p className="text-[8px] text-slate-500">{n}</p>
              </div>
            ))}
          </div>
        </div>
        <div>
          <p className="text-sm font-medium text-slate-600 mb-3">Tipografía</p>
          <p className="text-lg font-bold text-slate-800">Inter Bold - Títulos</p>
          <p className="text-sm text-slate-600">Inter Regular - Cuerpo</p>
          <p className="text-xs text-slate-400">Inter Light - Etiquetas</p>
        </div>
        <div className="md:col-span-2">
          <div className="p-4 rounded-xl bg-gradient-to-r from-brand-50 to-brand-100 border border-brand-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center shadow-lg shadow-brand-200">
                <span className="text-white font-bold text-lg">YD</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-brand-800">YourDentis</h3>
                <p className="text-xs text-brand-500 font-medium tracking-wider uppercase">Gestión Dental SaaS</p>
              </div>
            </div>
            <p className="text-lg font-semibold text-brand-700 italic">"Tu sonrisa, nuestra tecnología"</p>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

// ==================== SHARED UI COMPONENTS ====================
function SectionCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(true);
  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <button onClick={() => setIsOpen(!isOpen)} className="w-full flex items-center justify-between p-5 hover:bg-slate-50 transition-colors">
        <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">{icon} {title}</h3>
        <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && <div className="px-5 pb-5 border-t border-slate-100 pt-4">{children}</div>}
    </div>
  );
}

function FormField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-600 mb-1">{label}</label>
      <input type="text" defaultValue={value} className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
    </div>
  );
}

function ToggleRow({ label, desc, enabled, onChange }: { label: string; desc: string; enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 transition-colors">
      <div className="flex-1">
        <p className="text-sm font-medium text-slate-800">{label}</p>
        <p className="text-xs text-slate-500">{desc}</p>
      </div>
      <button onClick={() => onChange(!enabled)} className={`w-11 h-6 rounded-full relative transition-colors shrink-0 ${enabled ? 'bg-brand-500' : 'bg-slate-200'}`}>
        <div className={`w-4 h-4 bg-white rounded-full absolute top-1 shadow-sm transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );
}

function SelectRow({ icon, label, desc, value, onChange, options }: { icon: React.ReactNode; label: string; desc: string; value: string; onChange: (v: string) => void; options: { v: string; l: string }[] }) {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50">
      <div className="flex items-center gap-3">
        <span className="text-slate-400">{icon}</span>
        <div>
          <p className="text-sm font-medium text-slate-800">{label}</p>
          <p className="text-xs text-slate-500">{desc}</p>
        </div>
      </div>
      <select value={value} onChange={e => onChange(e.target.value)} className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
        {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </div>
  );
}
