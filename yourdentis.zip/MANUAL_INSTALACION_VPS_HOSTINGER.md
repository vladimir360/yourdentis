# 🦷 YourDentis - Manual de Instalación en VPS Hostinger

## Manual Completo Paso a Paso para Desplegar YourDentis en tu VPS de Hostinger

---

## 📋 ÍNDICE

1. [Requisitos Previos](#1-requisitos-previos)
2. [Acceder a tu VPS](#2-acceder-a-tu-vps)
3. [Preparar el Servidor](#3-preparar-el-servidor)
4. [Instalar Node.js](#4-instalar-nodejs)
5. [Instalar MySQL](#5-instalar-mysql)
6. [Configurar la Base de Datos](#6-configurar-la-base-de-datos)
7. [Subir el Proyecto al VPS](#7-subir-el-proyecto-al-vps)
8. [Configurar el Backend](#8-configurar-el-backend)
9. [Compilar el Frontend](#9-compilar-el-frontend)
10. [Instalar y Configurar Nginx](#10-instalar-y-configurar-nginx)
11. [Configurar SSL (HTTPS)](#11-configurar-ssl-https)
12. [Mantener el Backend Activo con PM2](#12-mantener-el-backend-activo-con-pm2)
13. [Configurar Firewall](#13-configurar-firewall)
14. [Configurar Dominio en Hostinger](#14-configurar-dominio-en-hostinger)
15. [Backups Automáticos](#15-backups-automaticos)
16. [Monitoreo y Mantenimiento](#16-monitoreo-y-mantenimiento)
17. [Solución de Problemas](#17-solucion-de-problemas)
18. [Comandos Útiles de Referencia](#18-comandos-utiles-de-referencia)

---

## 1. REQUISITOS PREVIOS

### Lo que necesitas antes de comenzar:

| Requisito | Detalle |
|-----------|---------|
| **VPS Hostinger** | Plan KVM 2 o superior recomendado |
| **Sistema Operativo** | Ubuntu 22.04 LTS (recomendado) |
| **RAM mínima** | 2 GB |
| **Almacenamiento** | 20 GB mínimo |
| **Dominio** | Tu dominio apuntando al VPS (ej: yourdentis.com) |
| **Cliente SSH** | Terminal (Mac/Linux) o PuTTY (Windows) |
| **FileZilla** | Para transferir archivos (opcional) |

### Datos que necesitarás de Hostinger:

- **IP del VPS**: La encuentras en hPanel → VPS → Panel de Control
- **Usuario root**: `root`
- **Contraseña root**: La que configuraste al crear el VPS
- **Puerto SSH**: `22` (por defecto)

---

## 2. ACCEDER A TU VPS

### Desde Windows (PuTTY):

1. Descarga PuTTY desde: https://www.putty.org/
2. Abre PuTTY
3. En **Host Name**: escribe la IP de tu VPS
4. **Port**: `22`
5. **Connection type**: SSH
6. Click en **Open**
7. Escribe `root` como usuario
8. Escribe tu contraseña

### Desde Mac o Linux (Terminal):

```bash
# Abrir terminal y conectar
ssh root@TU_IP_DEL_VPS

# Ejemplo:
ssh root@185.199.52.123
```

### Desde el Panel de Hostinger:

1. Inicia sesión en https://hpanel.hostinger.com
2. Ve a **VPS** → selecciona tu VPS
3. Click en **Acceso SSH** o **Terminal del navegador**

> 💡 **Tip**: Cuando escribas la contraseña en SSH, no se ve nada en pantalla (es normal, es por seguridad). Solo escríbela y presiona Enter.

---

## 3. PREPARAR EL SERVIDOR

### 3.1. Actualizar el sistema operativo

```bash
# Actualizar lista de paquetes
sudo apt update

# Actualizar paquetes instalados
sudo apt upgrade -y

# Instalar utilidades básicas
sudo apt install -y curl wget git unzip nano software-properties-common build-essential
```

### 3.2. Crear un usuario dedicado (NO usar root para todo)

```bash
# Crear usuario 'yourdentis'
sudo adduser yourdentis

# Te pedirá:
# - Contraseña: (escribe una contraseña segura y anótala)
# - Full Name: YourDentis Admin
# - Los demás campos: presiona Enter para dejar vacíos
# - Confirmar: Y

# Dar permisos de administrador
sudo usermod -aG sudo yourdentis

# Cambiar a ese usuario
su - yourdentis
```

### 3.3. Configurar zona horaria

```bash
# Configurar zona horaria de República Dominicana
sudo timedatectl set-timezone America/Santo_Domingo

# Verificar
date
```

---

## 4. INSTALAR NODE.JS

### 4.1. Instalar Node.js 20 LTS (versión recomendada)

```bash
# Agregar repositorio de NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Instalar Node.js
sudo apt install -y nodejs

# Verificar instalación
node --version
# Debe mostrar: v20.x.x

npm --version
# Debe mostrar: 10.x.x
```

### 4.2. Instalar PM2 (para mantener el backend activo)

```bash
# Instalar PM2 globalmente
sudo npm install -g pm2

# Verificar
pm2 --version
```

---

## 5. INSTALAR MYSQL

### 5.1. Instalar MySQL Server 8

```bash
# Instalar MySQL
sudo apt install -y mysql-server

# Iniciar MySQL
sudo systemctl start mysql

# Habilitar inicio automático
sudo systemctl enable mysql

# Verificar que está corriendo
sudo systemctl status mysql
# Debe decir: active (running)
```

### 5.2. Asegurar MySQL

```bash
# Ejecutar script de seguridad
sudo mysql_secure_installation

# Te preguntará:
# 1. VALIDATE PASSWORD component: Y
# 2. Password validation policy: 1 (MEDIUM)
# 3. New password for root: (escribe una contraseña segura)
# 4. Re-enter password: (repite la contraseña)
# 5. Remove anonymous users: Y
# 6. Disallow root login remotely: Y
# 7. Remove test database: Y
# 8. Reload privilege tables: Y
```

> ⚠️ **IMPORTANTE**: Anota la contraseña de root de MySQL. La necesitarás más adelante.

---

## 6. CONFIGURAR LA BASE DE DATOS

### 6.1. Conectar a MySQL

```bash
# Conectar como root
sudo mysql -u root -p
# Escribe la contraseña que configuraste
```

### 6.2. Crear la base de datos y usuario

```sql
-- Dentro de MySQL, ejecuta estos comandos:

-- Crear la base de datos
CREATE DATABASE u692656293_yourdentis CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear el usuario
CREATE USER 'u692656293_yourdentis'@'localhost' IDENTIFIED BY 'u692656293_yourdentiS.';

-- Dar todos los permisos al usuario sobre la base de datos
GRANT ALL PRIVILEGES ON u692656293_yourdentis.* TO 'u692656293_yourdentis'@'localhost';

-- Aplicar los permisos
FLUSH PRIVILEGES;

-- Verificar que se creó
SHOW DATABASES;

-- Salir de MySQL
EXIT;
```

### 6.3. Importar el esquema de la base de datos

```bash
# Importar las tablas (asegúrate de estar en el directorio del proyecto)
mysql -u u692656293_yourdentis -p u692656293_yourdentis < /home/yourdentis/yourdentis/backend/database/schema.sql

# Te pedirá la contraseña: u692656293_yourdentiS.
```

### 6.4. Verificar que las tablas se crearon

```bash
# Conectar a MySQL
mysql -u u692656293_yourdentis -p u692656293_yourdentis

# Ver las tablas
SHOW TABLES;

# Deberías ver algo como:
# +-------------------------------------+
# | Tables_in_u692656293_yourdentis     |
# +-------------------------------------+
# | appointments                        |
# | audit_logs                          |
# | clinical_attachments                |
# | clinical_evolutions                 |
# | clinical_histories                  |
# | clinics                             |
# | inventory_materials                 |
# | inventory_movements                 |
# | invoice_items                       |
# | invoices                            |
# | notifications                       |
# | patient_medical_history             |
# | patients                            |
# | payment_installments                |
# | payments                            |
# | settings                            |
# | treatment_procedures                |
# | treatments                          |
# | odontogram_entries                  |
# | user_clinics                        |
# | users                               |
# +-------------------------------------+

EXIT;
```

### 6.5. Crear el usuario administrador por defecto

```bash
# Conectar a MySQL
mysql -u u692656293_yourdentis -p u692656293_yourdentis
```

```sql
-- Insertar clínica por defecto
INSERT INTO clinics (id, name, email, phone, address, city, country, status) 
VALUES (
    UUID(), 
    'YourDentis - Clínica Principal', 
    'info@yourdentis.com', 
    '+1 (829) 630-3341', 
    'C/3ra número 3, Madrevieja Sur', 
    'San Cristóbal', 
    'República Dominicana', 
    'active'
);

-- Guardar el ID de la clínica
SET @clinic_id = (SELECT id FROM clinics LIMIT 1);

-- Insertar usuario administrador
-- La contraseña 'vladimir31' hasheada con bcrypt
-- NOTA: Este hash se debe generar con bcrypt. Por ahora usamos un placeholder
-- y lo actualizaremos cuando el backend esté corriendo
INSERT INTO users (id, clinic_id, first_name, last_name, email, password, role, status)
VALUES (
    UUID(),
    @clinic_id,
    'Vladimir',
    'Admin',
    'admin@yourdentis.com',
    '$2b$10$placeholder_temporal',
    'admin',
    'active'
);

EXIT;
```

> 📝 **NOTA**: La contraseña del admin se configurará correctamente cuando ejecutemos el backend por primera vez. Ver sección 8.5.

---

## 7. SUBIR EL PROYECTO AL VPS

### Opción A: Usando Git (RECOMENDADO)

#### 7A.1. Si tu proyecto está en GitHub/GitLab:

```bash
# Cambiar al usuario yourdentis
su - yourdentis

# Ir al directorio home
cd /home/yourdentis

# Clonar el repositorio
git clone https://github.com/TU_USUARIO/yourdentis.git

# Entrar al directorio
cd yourdentis
```

#### 7A.2. Si NO tienes repositorio Git:

Primero, en tu computadora local, inicializa Git:

```bash
# En tu computadora local, en la carpeta del proyecto:
cd tu-proyecto-yourdentis

git init
git add .
git commit -m "YourDentis - versión inicial"

# Crear repositorio en GitHub y subirlo
# Ve a github.com → New Repository → yourdentis
git remote add origin https://github.com/TU_USUARIO/yourdentis.git
git push -u origin main
```

Luego en el VPS:

```bash
git clone https://github.com/TU_USUARIO/yourdentis.git
cd yourdentis
```

### Opción B: Usando FileZilla (SFTP)

1. Descarga FileZilla: https://filezilla-project.org/
2. Abre FileZilla
3. Configura la conexión:
   - **Host**: `sftp://TU_IP_DEL_VPS`
   - **Usuario**: `yourdentis`
   - **Contraseña**: la contraseña del usuario yourdentis
   - **Puerto**: `22`
4. Click en **Conexión rápida**
5. En el panel izquierdo: navega a la carpeta del proyecto en tu PC
6. En el panel derecho: navega a `/home/yourdentis/`
7. Crea una carpeta `yourdentis` en el panel derecho
8. Arrastra todos los archivos del proyecto al panel derecho

### Opción C: Usando SCP desde tu computadora

```bash
# Desde tu computadora local:
scp -r ./tu-proyecto-yourdentis/* yourdentis@TU_IP_VPS:/home/yourdentis/yourdentis/
```

### Verificar que los archivos están en el VPS

```bash
# En el VPS
cd /home/yourdentis/yourdentis
ls -la

# Deberías ver:
# backend/
# src/
# public/
# index.html
# package.json
# vite.config.ts
# tailwind.config.js
# tsconfig.json
# ...
```

---

## 8. CONFIGURAR EL BACKEND

### 8.1. Entrar al directorio del backend

```bash
cd /home/yourdentis/yourdentis/backend
```

### 8.2. Instalar dependencias

```bash
npm install
```

### 8.3. Configurar variables de entorno

```bash
# Editar el archivo .env
nano .env
```

Cambia el contenido a:

```env
# ================================
# CONFIGURACIÓN DE PRODUCCIÓN
# YourDentis VPS Hostinger
# ================================

# Puerto del servidor
PORT=3001

# Base de datos MySQL
DB_HOST=localhost
DB_PORT=3306
DB_USER=u692656293_yourdentis
DB_PASSWORD=u692656293_yourdentiS.
DB_NAME=u692656293_yourdentis

# JWT - Cambia esta clave secreta por una propia
JWT_SECRET=YourDentis_JWT_2024_CambiaEstaClaveSecreta_$(date +%s)
JWT_EXPIRES_IN=24h

# Entorno
NODE_ENV=production

# Correo electrónico (para notificaciones)
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=info@yourdentis.com
SMTP_PASS=TU_CONTRASEÑA_EMAIL

# URL del frontend
FRONTEND_URL=https://yourdentis.com
CORS_ORIGIN=https://yourdentis.com
```

**Para guardar en nano**: `Ctrl + O` → `Enter` → `Ctrl + X`

### 8.4. Generar un JWT Secret seguro

```bash
# Generar una clave secreta aleatoria
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# Copia el resultado y ponlo como JWT_SECRET en .env
```

### 8.5. Crear el usuario administrador correctamente

```bash
# Crear un script temporal para hashear la contraseña
cd /home/yourdentis/yourdentis/backend

cat > create_admin.js << 'EOF'
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function createAdmin() {
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    try {
        // Hashear la contraseña
        const password = await bcrypt.hash('vladimir31', 10);
        
        // Verificar si ya existe un admin
        const [existing] = await connection.execute(
            'SELECT id FROM users WHERE email = ?', 
            ['admin@yourdentis.com']
        );

        if (existing.length > 0) {
            // Actualizar contraseña
            await connection.execute(
                'UPDATE users SET password = ? WHERE email = ?',
                [password, 'admin@yourdentis.com']
            );
            console.log('✅ Contraseña del administrador actualizada correctamente');
        } else {
            // Verificar si existe una clínica
            let [clinics] = await connection.execute('SELECT id FROM clinics LIMIT 1');
            
            let clinicId;
            if (clinics.length === 0) {
                // Crear clínica
                const { v4: uuidv4 } = require('uuid');
                clinicId = uuidv4();
                await connection.execute(
                    `INSERT INTO clinics (id, name, email, phone, address, city, country, status) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        clinicId,
                        'YourDentis - Clínica Principal',
                        'info@yourdentis.com',
                        '+1 (829) 630-3341',
                        'C/3ra número 3, Madrevieja Sur',
                        'San Cristóbal',
                        'República Dominicana',
                        'active'
                    ]
                );
                console.log('✅ Clínica creada correctamente');
            } else {
                clinicId = clinics[0].id;
            }

            // Crear admin
            const { v4: uuidv4 } = require('uuid');
            await connection.execute(
                `INSERT INTO users (id, clinic_id, first_name, last_name, email, password, role, status) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    uuidv4(),
                    clinicId,
                    'Vladimir',
                    'Administrador',
                    'admin@yourdentis.com',
                    password,
                    'admin',
                    'active'
                ]
            );
            console.log('✅ Usuario administrador creado correctamente');
        }

        console.log('');
        console.log('📧 Email: admin@yourdentis.com');
        console.log('🔑 Contraseña: vladimir31');
        console.log('');
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    } finally {
        await connection.end();
    }
}

createAdmin();
EOF

# Ejecutar el script
node create_admin.js

# Eliminar el script temporal
rm create_admin.js
```

### 8.6. Probar que el backend funciona

```bash
# Probar el backend
cd /home/yourdentis/yourdentis/backend
node server.js

# Deberías ver:
# 🦷 YourDentis API Server running on port 3001
# ✅ Database connected successfully

# Presiona Ctrl + C para detenerlo (lo iniciaremos con PM2 después)
```

---

## 9. COMPILAR EL FRONTEND

### 9.1. Instalar dependencias del frontend

```bash
cd /home/yourdentis/yourdentis
npm install
```

### 9.2. Configurar la URL del API en el frontend

Si necesitas que el frontend apunte al backend, crea un archivo de configuración:

```bash
# Crear archivo de configuración del API
cat > src/config.ts << 'EOF'
// Configuración del API
export const API_URL = import.meta.env.VITE_API_URL || 'https://yourdentis.com/api';
export const APP_NAME = 'YourDentis';
export const APP_VERSION = '1.0.0';
EOF
```

### 9.3. Compilar el frontend para producción

```bash
cd /home/yourdentis/yourdentis
npm run build

# Esto creará la carpeta 'dist/' con los archivos optimizados
# Deberías ver:
# dist/
#   index.html
#   assets/
#     index-xxxxx.js
#     index-xxxxx.css
```

### 9.4. Verificar que se compiló correctamente

```bash
ls -la dist/
# Debe mostrar index.html y la carpeta assets/
```

---

## 10. INSTALAR Y CONFIGURAR NGINX

### 10.1. Instalar Nginx

```bash
sudo apt install -y nginx

# Iniciar Nginx
sudo systemctl start nginx

# Habilitar inicio automático
sudo systemctl enable nginx

# Verificar que funciona
sudo systemctl status nginx
# Debe decir: active (running)
```

### 10.2. Configurar Nginx para YourDentis

```bash
# Crear configuración del sitio
sudo nano /etc/nginx/sites-available/yourdentis
```

Pega este contenido:

```nginx
# ================================
# YourDentis - Configuración Nginx
# ================================

server {
    listen 80;
    listen [::]:80;
    
    # CAMBIA ESTO por tu dominio real
    server_name yourdentis.com www.yourdentis.com;

    # Redirigir HTTP a HTTPS (se activará después de configurar SSL)
    # return 301 https://$server_name$request_uri;

    # ---- Frontend (React/Vite) ----
    root /home/yourdentis/yourdentis/dist;
    index index.html;

    # Manejar rutas de React (SPA)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # ---- Backend API ----
    location /api/ {
        proxy_pass http://127.0.0.1:3001/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
    }

    # ---- Archivos estáticos (cache) ----
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # ---- Seguridad ----
    # Ocultar versión de Nginx
    server_tokens off;

    # Headers de seguridad
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Bloquear acceso a archivos ocultos
    location ~ /\. {
        deny all;
    }

    # Tamaño máximo de subida (para radiografías y fotos)
    client_max_body_size 50M;

    # Logs
    access_log /var/log/nginx/yourdentis_access.log;
    error_log /var/log/nginx/yourdentis_error.log;
}
```

**Para guardar**: `Ctrl + O` → `Enter` → `Ctrl + X`

### 10.3. Activar el sitio

```bash
# Crear enlace simbólico
sudo ln -s /etc/nginx/sites-available/yourdentis /etc/nginx/sites-enabled/

# Eliminar configuración por defecto (opcional)
sudo rm /etc/nginx/sites-enabled/default

# Verificar que la configuración es correcta
sudo nginx -t
# Debe decir: syntax is ok / test is successful

# Reiniciar Nginx
sudo systemctl restart nginx
```

### 10.4. Dar permisos correctos

```bash
# Dar permisos de lectura a Nginx sobre los archivos
sudo chown -R yourdentis:www-data /home/yourdentis/yourdentis/dist
sudo chmod -R 755 /home/yourdentis/yourdentis/dist
sudo chmod 755 /home/yourdentis
```

### 10.5. Probar que funciona

Abre tu navegador y ve a: `http://TU_IP_DEL_VPS`

Deberías ver la página de inicio de YourDentis.

---

## 11. CONFIGURAR SSL (HTTPS)

### 11.1. Instalar Certbot (Let's Encrypt)

```bash
# Instalar Certbot para Nginx
sudo apt install -y certbot python3-certbot-nginx
```

### 11.2. Obtener certificado SSL gratuito

```bash
# IMPORTANTE: Tu dominio debe estar apuntando al VPS primero (ver sección 14)
sudo certbot --nginx -d yourdentis.com -d www.yourdentis.com

# Te pedirá:
# 1. Email: tu@email.com (para avisos de renovación)
# 2. Aceptar términos: A
# 3. Compartir email con EFF: N (opcional)
# 4. Redirigir HTTP a HTTPS: 2 (Redirect)
```

### 11.3. Verificar renovación automática

```bash
# Probar renovación
sudo certbot renew --dry-run

# Debe decir: Congratulations, all simulated renewals succeeded
```

### 11.4. Configurar renovación automática

```bash
# Certbot ya configura un timer automático, verificarlo:
sudo systemctl status certbot.timer

# Si no está activo:
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

> 🔒 El certificado SSL se renueva automáticamente cada 60-90 días.

---

## 12. MANTENER EL BACKEND ACTIVO CON PM2

### 12.1. Iniciar el backend con PM2

```bash
cd /home/yourdentis/yourdentis/backend

# Iniciar con PM2
pm2 start server.js --name "yourdentis-api" --env production

# Verificar que está corriendo
pm2 status

# Deberías ver:
# ┌─────┬────────────────────┬──────┬───────┬────────┬─────────┬────────┐
# │ id  │ name               │ mode │ pid   │ status │ restart │ cpu    │
# ├─────┼────────────────────┼──────┼───────┼────────┼─────────┼────────┤
# │ 0   │ yourdentis-api     │ fork │ 12345 │ online │ 0       │ 0%     │
# └─────┴────────────────────┴──────┴───────┴────────┴─────────┴────────┘
```

### 12.2. Configurar inicio automático al reiniciar el VPS

```bash
# Generar script de inicio
pm2 startup systemd

# PM2 te mostrará un comando, cópialo y ejecútalo. Ejemplo:
# sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u yourdentis --hp /home/yourdentis

# Guardar la lista de procesos actual
pm2 save
```

### 12.3. Comandos útiles de PM2

```bash
# Ver estado
pm2 status

# Ver logs en tiempo real
pm2 logs yourdentis-api

# Ver últimas 100 líneas de logs
pm2 logs yourdentis-api --lines 100

# Reiniciar
pm2 restart yourdentis-api

# Detener
pm2 stop yourdentis-api

# Eliminar
pm2 delete yourdentis-api

# Monitor en tiempo real (CPU, RAM)
pm2 monit
```

---

## 13. CONFIGURAR FIREWALL

### 13.1. Configurar UFW (Uncomplicated Firewall)

```bash
# Habilitar UFW
sudo ufw enable

# Permitir SSH (¡¡¡MUY IMPORTANTE!!! Si no haces esto, perderás acceso)
sudo ufw allow ssh
sudo ufw allow 22

# Permitir HTTP y HTTPS
sudo ufw allow 80
sudo ufw allow 443

# Permitir el puerto del backend (solo local, Nginx hace proxy)
# NO abrir el 3001 al público
# sudo ufw allow 3001  ← NO HAGAS ESTO

# Verificar reglas
sudo ufw status verbose

# Deberías ver:
# Status: active
# To                         Action      From
# --                         ------      ----
# 22/tcp                     ALLOW       Anywhere
# 80/tcp                     ALLOW       Anywhere
# 443/tcp                    ALLOW       Anywhere
```

### 13.2. Proteger SSH (opcional pero recomendado)

```bash
# Editar configuración SSH
sudo nano /etc/ssh/sshd_config

# Busca y cambia estas líneas:
# PermitRootLogin no          ← Desactivar login como root
# PasswordAuthentication yes  ← Mantener por ahora
# MaxAuthTries 3              ← Máximo 3 intentos

# Guardar y reiniciar SSH
sudo systemctl restart sshd
```

### 13.3. Instalar Fail2Ban (protección contra fuerza bruta)

```bash
# Instalar
sudo apt install -y fail2ban

# Crear configuración local
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo nano /etc/fail2ban/jail.local

# Busca la sección [sshd] y asegura que tenga:
# [sshd]
# enabled = true
# port = ssh
# maxretry = 5
# bantime = 3600

# Reiniciar Fail2Ban
sudo systemctl restart fail2ban
sudo systemctl enable fail2ban

# Ver IPs baneadas
sudo fail2ban-client status sshd
```

---

## 14. CONFIGURAR DOMINIO EN HOSTINGER

### 14.1. Si tu dominio está en Hostinger:

1. Inicia sesión en https://hpanel.hostinger.com
2. Ve a **Dominios** → selecciona tu dominio
3. Ve a **DNS / Nameservers** → **Zona DNS**
4. Configura los registros DNS:

| Tipo | Nombre | Contenido | TTL |
|------|--------|-----------|-----|
| **A** | `@` | `TU_IP_DEL_VPS` | 14400 |
| **A** | `www` | `TU_IP_DEL_VPS` | 14400 |
| **CNAME** | `www` | `yourdentis.com` | 14400 |

5. Click en **Guardar**
6. Espera 5-30 minutos para que se propague

### 14.2. Si tu dominio está en otro registrador:

1. Ve al panel de tu registrador (GoDaddy, Namecheap, etc.)
2. Busca **DNS Settings** o **Zone Editor**
3. Agrega los mismos registros A de arriba
4. Espera hasta 48 horas para propagación completa

### 14.3. Verificar que el dominio apunta al VPS

```bash
# Desde tu computadora o el VPS:
ping yourdentis.com

# Debe responder con la IP de tu VPS
# PING yourdentis.com (185.199.52.123): 56 data bytes
# 64 bytes from 185.199.52.123: ...

# También puedes verificar con:
nslookup yourdentis.com
dig yourdentis.com
```

---

## 15. BACKUPS AUTOMÁTICOS

### 15.1. Crear script de backup

```bash
# Crear directorio para backups
sudo mkdir -p /home/yourdentis/backups
sudo chown yourdentis:yourdentis /home/yourdentis/backups

# Crear script de backup
cat > /home/yourdentis/backup.sh << 'SCRIPT'
#!/bin/bash
# ================================
# YourDentis - Backup Automático
# ================================

FECHA=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/home/yourdentis/backups"
DB_USER="u692656293_yourdentis"
DB_PASS="u692656293_yourdentiS."
DB_NAME="u692656293_yourdentis"

echo "🦷 YourDentis Backup - $FECHA"
echo "================================"

# 1. Backup de la base de datos
echo "📦 Creando backup de la base de datos..."
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_$FECHA.sql

# 2. Comprimir el backup
echo "🗜️ Comprimiendo..."
gzip $BACKUP_DIR/db_$FECHA.sql

# 3. Backup de archivos del proyecto
echo "📁 Backup de archivos..."
tar -czf $BACKUP_DIR/files_$FECHA.tar.gz /home/yourdentis/yourdentis/backend/.env /home/yourdentis/yourdentis/backend/uploads 2>/dev/null

# 4. Eliminar backups de más de 30 días
echo "🧹 Limpiando backups antiguos..."
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete

echo "✅ Backup completado: $BACKUP_DIR/db_$FECHA.sql.gz"
echo ""

# Mostrar espacio usado por backups
echo "📊 Espacio usado por backups:"
du -sh $BACKUP_DIR
echo ""
ls -lh $BACKUP_DIR | tail -5
SCRIPT

# Hacer ejecutable
chmod +x /home/yourdentis/backup.sh
```

### 15.2. Programar backup automático (cada día a las 2 AM)

```bash
# Editar crontab
crontab -e

# Si te pregunta qué editor usar, elige nano (opción 1)

# Agrega esta línea al final:
0 2 * * * /home/yourdentis/backup.sh >> /home/yourdentis/backups/backup.log 2>&1

# Guardar y salir: Ctrl + O → Enter → Ctrl + X
```

### 15.3. Probar el backup manualmente

```bash
# Ejecutar backup ahora
/home/yourdentis/backup.sh

# Verificar que se creó
ls -lh /home/yourdentis/backups/
```

### 15.4. Restaurar un backup (en caso de emergencia)

```bash
# Descomprimir
gunzip /home/yourdentis/backups/db_20240101_020000.sql.gz

# Restaurar
mysql -u u692656293_yourdentis -p u692656293_yourdentis < /home/yourdentis/backups/db_20240101_020000.sql
```

---

## 16. MONITOREO Y MANTENIMIENTO

### 16.1. Monitorear el servidor

```bash
# Ver uso de CPU y RAM
htop
# (Instalar si no existe: sudo apt install htop)

# Ver espacio en disco
df -h

# Ver uso de memoria
free -h

# Ver procesos de PM2
pm2 monit

# Ver logs del backend
pm2 logs yourdentis-api --lines 50

# Ver logs de Nginx
sudo tail -f /var/log/nginx/yourdentis_access.log
sudo tail -f /var/log/nginx/yourdentis_error.log

# Ver logs de MySQL
sudo tail -f /var/log/mysql/error.log
```

### 16.2. Actualizar el proyecto

Cuando hagas cambios al código:

```bash
# Conectar al VPS
ssh yourdentis@TU_IP_VPS

# Ir al directorio del proyecto
cd /home/yourdentis/yourdentis

# Traer cambios de Git
git pull origin main

# Actualizar dependencias del frontend
npm install

# Recompilar frontend
npm run build

# Actualizar dependencias del backend
cd backend
npm install

# Reiniciar backend
pm2 restart yourdentis-api

# Verificar que todo funciona
pm2 status
```

### 16.3. Actualizar el sistema operativo (mensualmente)

```bash
sudo apt update
sudo apt upgrade -y
sudo apt autoremove -y
```

### 16.4. Monitorear espacio en disco

```bash
# Ver espacio general
df -h

# Ver qué carpetas ocupan más espacio
du -sh /home/yourdentis/* | sort -rh | head -10

# Limpiar paquetes innecesarios
sudo apt autoremove -y
sudo apt autoclean
```

---

## 17. SOLUCIÓN DE PROBLEMAS

### ❌ "No puedo acceder por SSH"

```bash
# Verifica que el VPS esté encendido en el panel de Hostinger
# Verifica la IP correcta
# Intenta desde el terminal web de Hostinger

# Si cambiaste el puerto SSH:
ssh -p NUEVO_PUERTO yourdentis@TU_IP_VPS
```

### ❌ "La página no carga"

```bash
# 1. Verificar Nginx
sudo systemctl status nginx
sudo nginx -t
sudo systemctl restart nginx

# 2. Verificar que los archivos del frontend existen
ls -la /home/yourdentis/yourdentis/dist/

# 3. Verificar permisos
sudo chown -R yourdentis:www-data /home/yourdentis/yourdentis/dist
sudo chmod -R 755 /home/yourdentis/yourdentis/dist

# 4. Revisar logs de Nginx
sudo tail -20 /var/log/nginx/yourdentis_error.log
```

### ❌ "El API no responde"

```bash
# 1. Verificar PM2
pm2 status
pm2 logs yourdentis-api --lines 30

# 2. Si está detenido, reiniciar
pm2 restart yourdentis-api

# 3. Probar directamente
curl http://localhost:3001/api/health

# 4. Verificar puerto
sudo netstat -tlnp | grep 3001
# o
sudo ss -tlnp | grep 3001
```

### ❌ "Error de base de datos"

```bash
# 1. Verificar MySQL
sudo systemctl status mysql

# 2. Si no está corriendo
sudo systemctl start mysql

# 3. Verificar conexión
mysql -u u692656293_yourdentis -p u692656293_yourdentis -e "SELECT 1;"

# 4. Ver logs de MySQL
sudo tail -20 /var/log/mysql/error.log

# 5. Verificar espacio en disco (MySQL necesita espacio)
df -h
```

### ❌ "Error 502 Bad Gateway"

```bash
# Significa que Nginx no puede comunicarse con el backend

# 1. Verificar que el backend esté corriendo
pm2 status

# 2. Si no está corriendo
cd /home/yourdentis/yourdentis/backend
pm2 start server.js --name "yourdentis-api"

# 3. Verificar el puerto
curl http://localhost:3001/api/health
```

### ❌ "El certificado SSL no funciona"

```bash
# 1. Verificar que el dominio apunta al VPS
dig yourdentis.com

# 2. Renovar certificado
sudo certbot renew

# 3. Si falla, obtener uno nuevo
sudo certbot --nginx -d yourdentis.com -d www.yourdentis.com

# 4. Reiniciar Nginx
sudo systemctl restart nginx
```

### ❌ "Se quedó sin espacio el disco"

```bash
# Ver espacio
df -h

# Limpiar logs antiguos
sudo journalctl --vacuum-time=7d

# Limpiar backups antiguos
find /home/yourdentis/backups -mtime +15 -delete

# Limpiar paquetes
sudo apt autoremove -y
sudo apt autoclean
```

### ❌ "El VPS está lento"

```bash
# 1. Ver qué consume más recursos
htop

# 2. Ver memoria
free -h

# 3. Reiniciar servicios
pm2 restart yourdentis-api
sudo systemctl restart nginx
sudo systemctl restart mysql

# 4. Si persiste, considerar aumentar el plan del VPS en Hostinger
```

---

## 18. COMANDOS ÚTILES DE REFERENCIA

### Comandos de gestión del proyecto

```bash
# ========== CONEXIÓN ==========
ssh yourdentis@TU_IP_VPS                 # Conectar al VPS

# ========== NAVEGACIÓN ==========
cd /home/yourdentis/yourdentis           # Ir al proyecto
cd /home/yourdentis/yourdentis/backend   # Ir al backend
cd /home/yourdentis/yourdentis/dist      # Ir al frontend compilado

# ========== FRONTEND ==========
cd /home/yourdentis/yourdentis
npm install                              # Instalar dependencias
npm run build                            # Compilar para producción

# ========== BACKEND ==========
cd /home/yourdentis/yourdentis/backend
npm install                              # Instalar dependencias
pm2 start server.js --name yourdentis-api  # Iniciar
pm2 restart yourdentis-api               # Reiniciar
pm2 stop yourdentis-api                  # Detener
pm2 logs yourdentis-api                  # Ver logs
pm2 monit                               # Monitor

# ========== NGINX ==========
sudo systemctl start nginx               # Iniciar
sudo systemctl stop nginx                # Detener
sudo systemctl restart nginx             # Reiniciar
sudo systemctl reload nginx              # Recargar config
sudo nginx -t                            # Verificar config
sudo nano /etc/nginx/sites-available/yourdentis  # Editar config

# ========== MYSQL ==========
sudo systemctl start mysql               # Iniciar
sudo systemctl stop mysql                # Detener
sudo systemctl restart mysql             # Reiniciar
mysql -u u692656293_yourdentis -p u692656293_yourdentis  # Conectar

# ========== SSL ==========
sudo certbot renew                       # Renovar SSL
sudo certbot --nginx -d yourdentis.com   # Obtener nuevo SSL

# ========== BACKUPS ==========
/home/yourdentis/backup.sh               # Backup manual
ls -lh /home/yourdentis/backups/         # Ver backups

# ========== SISTEMA ==========
sudo apt update && sudo apt upgrade -y   # Actualizar OS
df -h                                    # Ver espacio disco
free -h                                  # Ver memoria RAM
htop                                     # Monitor de recursos
sudo reboot                              # Reiniciar VPS

# ========== FIREWALL ==========
sudo ufw status                          # Ver reglas
sudo ufw allow 80                        # Permitir HTTP
sudo ufw allow 443                       # Permitir HTTPS

# ========== LOGS ==========
pm2 logs yourdentis-api --lines 100      # Logs del backend
sudo tail -f /var/log/nginx/yourdentis_access.log   # Logs de acceso
sudo tail -f /var/log/nginx/yourdentis_error.log    # Logs de error
sudo tail -f /var/log/mysql/error.log    # Logs de MySQL
```

---

## 📝 RESUMEN DE CREDENCIALES

> ⚠️ **GUARDA ESTA INFORMACIÓN EN UN LUGAR SEGURO**

| Servicio | Usuario | Contraseña |
|----------|---------|------------|
| **VPS SSH** | `yourdentis` | (la que configuraste) |
| **MySQL** | `u692656293_yourdentis` | `u692656293_yourdentiS.` |
| **YourDentis Admin** | `admin@yourdentis.com` | `vladimir31` |
| **Settings** | `admin` | `vladimir31` |
| **MySQL Root** | `root` | (la que configuraste) |

---

## 📞 SOPORTE

Si necesitas ayuda con la instalación:

- **Teléfono**: +1 (829) 630-3341
- **WhatsApp**: +1 (829) 630-3341
- **Ubicación**: C/3ra número 3, Madrevieja Sur, San Cristóbal, República Dominicana

---

## ✅ CHECKLIST FINAL DE INSTALACIÓN

Marca cada paso completado:

- [ ] Acceder al VPS por SSH
- [ ] Actualizar el sistema operativo
- [ ] Crear usuario `yourdentis`
- [ ] Configurar zona horaria
- [ ] Instalar Node.js 20
- [ ] Instalar PM2
- [ ] Instalar MySQL 8
- [ ] Asegurar MySQL
- [ ] Crear base de datos y usuario
- [ ] Importar esquema SQL
- [ ] Crear usuario administrador
- [ ] Subir el proyecto al VPS
- [ ] Instalar dependencias del backend
- [ ] Configurar archivo .env
- [ ] Probar el backend
- [ ] Instalar dependencias del frontend
- [ ] Compilar el frontend
- [ ] Instalar Nginx
- [ ] Configurar sitio en Nginx
- [ ] Configurar dominio DNS
- [ ] Instalar SSL con Certbot
- [ ] Iniciar backend con PM2
- [ ] Configurar inicio automático
- [ ] Configurar firewall UFW
- [ ] Instalar Fail2Ban
- [ ] Configurar backups automáticos
- [ ] Probar backup manual
- [ ] Verificar todo funciona correctamente
- [ ] ¡Celebrar! 🎉

---

**🦷 YourDentis** — Tu sonrisa, nuestra tecnología

*Manual creado para la instalación en VPS Hostinger con Ubuntu 22.04 LTS*
*Versión 1.0 — 2024*
